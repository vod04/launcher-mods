function RenderCallback()
    if Launcher.Game.Paused() then
		local BatteryLevel = Launcher.XInput.BatteryLevel(0,BATTERY_DEVTYPE_GAMEPAD)
        if BatteryLevel ~= nil and BatteryLevel > -1 then
            Launcher.Sprite.Clip(BatterySprite,BatteryLevel*32,0,32,42)
			Launcher.Sprite.Draw(BatterySprite,0,0)
        end
    end
end
function Timeout()
    Launcher.XInput.SetVibration(0,0,0)
end
function ShotAwayCallback()
    if Launcher.Game.ControllerTeam(0) == 1 then
        Launcher.XInput.SetVibration(0,0,65530)
        Launcher.Timer.SetTimeout(200,Timeout)
    end
end
function ShotHomeCallback()
    if Launcher.Game.ControllerTeam(0) == 0 then
        Launcher.XInput.SetVibration(0,0,65530)
        Launcher.Timer.SetTimeout(200,Timeout)
    end
end
function LoadAssets()
    BatterySprite = Launcher.Sprite.Load("launcher/media/textures/xinput/Battery.png")
	if BatterySprite ~= nil then
		Launcher.Callback.Register("Render",RenderCallback)
	end
end
function DeviceCreatedCallback()
    LoadAssets()
end
function ReloadedCallback()
    LoadAssets()
end

ControllerState = Launcher.XInput.State(0)
if ControllerState ~= nil then
    Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
	Launcher.Callback.Register("Reloaded",ReloadedCallback)
    Launcher.Callback.Register("ShotHome",ShotHomeCallback)
    Launcher.Callback.Register("ShotAway",ShotAwayCallback)
  

   
end






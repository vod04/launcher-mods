ControllerState = Launcher.XInput.State(0)

function RenderCallback()
    local BatteryLevel
    if Launcher.Game.Paused() then
        BatteryLevel = Launcher.XInput.BatteryLevel(0,BATTERY_DEVTYPE_GAMEPAD)
        if BatteryLevel ~= nil then
            Launcher.Sprite.Clip(BatterySprite,BatteryLevel*32,0,32,42)
            Launcher.Sprite.Draw(BatterySprite,0,0)
        end
    end
end
function Timeout()
    Launcher.XInput.SetVibration(0,0,0)
end
function ShotAwayCallback()
    if Launcher.Game.ControllerTeam(0) == 1 then
        Launcher.XInput.SetVibration(0,0,65530)
        Launcher.Timer.SetTimeout(100,Timeout)
    end
end
function ShotHomeCallback()
    if Launcher.Game.ControllerTeam(0) == 0 then
        Launcher.XInput.SetVibration(0,0,65530)
        Launcher.Timer.SetTimeout(100,Timeout)
    end
end
function DeviceCreatedCallback()
    BatterySprite = Launcher.Sprite.Load("launcher/media/textures/xinput/Battery.png")
    Launcher.Callback.Register("ShotHome",ShotHomeCallback)
    Launcher.Callback.Register("ShotAway",ShotAwayCallback)
end

if ControllerState ~= nil then
    Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
    Launcher.Callback.Register("Render",RenderCallback)
end
-- drgullen's StatClock - v1.4.0 - released November 23, 2021

-- Starting Values
assists = {}
for loopcount=0, 39 do
	assists[loopcount] = 0
end
AwayGoalsX = 423
AwayIcings = 0
AwayOffsides = 0
AwayPoss = 0
AwayPPShots = 0
AwayShotSpeed = 0
ClockMessage = " "
CountSinceSOG = 0
CountSincePlayerStats = 0
FontColor1 = 0xee000000
FontColor2 = 0xeeffffff
FontFamily = "Tahoma"
FontSize = 50
FontSize2 = 60
FontSize3 = 25
FontSize4 = 35
FontSize5 = 50
FontSize6 = 24
FontWeight = 760
FontWeight2 = 730
goals = {}
for loopcount=0, 39 do
	goals[loopcount] = 0
end
GoalJustScored = 0
HomeGoalsX = 687
HomeIcings = 0
HomeOffsides = 0
HomePoss = 0
HomePPShots = 0
Launcher.Override.DisableOverlay()
MessageTimerOn = 9999
NativeResolutionX = 1920 
NativeResolutionY = 1080
NativeResolutionAspect = NativeResolutionY/NativeResolutionX
PauseRandomizer = 0
PauseSprite = 0
PenaltyPending = 0
PowerPlayTime = 0
RandomStat = 0
SetStat = 1
ShowAwayShotSpeed = 1
ShowHomeShotSpeed = 1
ShowShots = 0
HomeShotSpeed = 0
SpriteinEffect = 0
SurfaceSprite = 0
TimeX = 780
TotalAwayShots = 0
TotalHomeShots = 0
TrackShots = 0
UseSmallDisplay = 0

-- Functions
function CutsceneStartedCallback()
	UseSmallDisplay = 0
	AltClockTime = Launcher.Game.Time()
	AltClockTime = AltClockTime - 12
	if AltClockTime > 1184 or AltClockTime < 0 then
		SetStat = 1
	elseif PenaltyPending == 1 then
		PenaltyPending = 2
		SetStat = 0
 	elseif PenaltyPending == 5 then
 		SetStat = 2
	elseif GoalJustScored == 1 then
		GoalJustScored = 2
		SetStat = 0
	else
		SetStat = 0
	end
	ClockMessage = "STATCLOCK v1.4"
end
function DeviceCreatedCallback()
	math.randomseed(os.time())
	LoadAssets()
end
function LoadAssets()
-- Sprites
    IcingSprite = Launcher.Sprite.Load("launcher/media/textures/icing.png")
    OffsideSprite = Launcher.Sprite.Load("launcher/media/textures/offside.png")	
    PauseSprite = Launcher.Sprite.Load("launcher/media/textures/pause.jpg")
	PenaltySprite = Launcher.Sprite.Load("launcher/media/textures/penalty.png")
	PowerPlaySprite = Launcher.Sprite.Load("launcher/media/textures/pp.png")	
	SurfaceSprite = Launcher.Sprite.Create(NativeResolutionX, NativeResolutionY,1)

-- Other Assets
    local Width, Height
    AwayAbbreviation = Launcher.Game.AwayNameAbbreviation()
    AwayPog = Launcher.Sprite.Load("launcher/media/textures/logos/"..AwayAbbreviation..".png")
    ClockFont = Launcher.Font.Load(FontFamily,FontSize,FontWeight)
	ClockFontMessage = Launcher.Font.Load(FontFamily,FontSize4,FontWeight)
	ClockFontMessageSmall = Launcher.Font.Load(FontFamily,FontSize6,FontWeight)
	ClockFontPP = Launcher.Font.Load(FontFamily,FontSize3,FontWeight)
	ClockFontPPDisplay = Launcher.Font.Load(FontFamily,FontSize5,FontWeight)
	ClockFontS = Launcher.Font.Load(FontFamily,FontSize2,FontWeight2)
    ClockSprite = Launcher.Sprite.Load("launcher/media/textures/clock.png")
    ClockX = 448
    ClockY = 0
    Height = Launcher.Sprite.Height(PauseSprite)
    HomeAbbreviation = Launcher.Game.HomeNameAbbreviation()
    HomePog = Launcher.Sprite.Load("launcher/media/textures/logos/"..HomeAbbreviation..".png")
    Width = Launcher.Sprite.Width(PauseSprite)

-- Setting Screen Scale
    Launcher.Sprite.Scale(PauseSprite,(Launcher.Screen.Height()*(Width/Height))/Width,Launcher.Screen.Height()/Height)
	Launcher.Sprite.Scale(SurfaceSprite,Launcher.Screen.Width()/NativeResolutionX, (Launcher.Screen.Width()*NativeResolutionAspect)/NativeResolutionY)
end
function PenaltyCallback()
-- This keeps track of shots taken during Power Plays
	TrackHomeShots = Launcher.Stats.HomeShots()
	TrackAwayShots = Launcher.Stats.AwayShots()
end
function PeriodStartedCallback()
-- These values are reset to start each new period
	GoalJustScored = 0
	IcinginEffect = 0
	OffsidesinEffect = 0
	PenaltyPending = 0
	SetStat = 1
	TrackShots = 0
	MessageTimerOn = 9999
end
function PlayStoppedCallback(Reason)
-- This decides what the background will be when the game is paused
	PauseRandomizer = math.random ()
	if PauseRandomizer > 0.75 then
		SpriteinEffect = 1
		PausePic = math.random (1,9)
		if PausePic == 1 then
			PauseSprite = Launcher.Sprite.Load("launcher/media/textures/pause.jpg")
		else
			PauseSprite = Launcher.Sprite.Load("launcher/media/textures/pause" .. PausePic .. ".jpg")
		end
	else
		SpriteinEffect = 0
	end
-- This resets certain display situations
	SetStat = 1
	ShowShots = 0
	if GoalJustScored == 2 then
		GoalJustScored = 0
	end
	if PenaltyPending == 3 and PowerPlayTime > 0 then
		PenaltyPending = 4
	end
	if PenaltyPending >= 3 and PowerPlayTime == 0 then
		PenaltyPending = 0
	end
-- This keeps track of icings
	if Reason == LauncherPlayStoppedIcing then
		if Launcher.Game.TeamWithPuck() == 0 then
			HomeIcings = HomeIcings + 1
		else
			AwayIcings = AwayIcings + 1
		end
	end
-- This keeps track of offsides
	if Reason == LauncherPlayStoppedOffside then
		if Launcher.Game.TeamWithPuck() == 0 then
			HomeOffsides = HomeOffsides + 1
		else
			AwayOffsides = AwayOffsides + 1
		end
	end
-- This logs all goals and assists to use for displays later
	if Reason == LauncherPlayStoppedGoalHome or Reason == LauncherPlayStoppedGoalAway then
		GoalJustScored = 1
		TOG = 1200 - Launcher.Game.Time()
		TOGMinutes = math.floor(TOG/60)
		if TOGMinutes == 0 then
			TOGMinutes = ""
		end
		TOGSeconds = TOG % 60
		if TOGSeconds < 10 then
			TOGSeconds = "0"..TOGSeconds
		end
		TimeofGoal = TOGMinutes .. ":" .. TOGSeconds
		MessageTimerOn = 9999
		for loopcount=0, 39 do
			if loopcount ~= 18 and loopcount ~= 19 and loopcount ~= 38 and loopcount ~= 39 then
				if Launcher.Player.Goals(loopcount) ~= goals [loopcount] then
					GoalScorerID = loopcount
					goals [loopcount] =	goals [loopcount] + 1
				end
			end
		end
		Assist1ID = -1
		for loopcount=0, 39 do
			if loopcount ~= 18 and loopcount ~= 19 and loopcount ~= 38 and loopcount ~= 39 then
				if Launcher.Player.Assists(loopcount) ~= assists [loopcount] then		
					Assist1ID = loopcount
					assists [loopcount] = assists [loopcount] + 1
					break
				end
			end
		end
		Assist2ID = -1
		if Assist1ID ~= -1 then
			for loopcount=0, 39 do
				if loopcount ~= 18 and loopcount ~= 19 and loopcount ~= 38 and loopcount ~= 39 then
					if Launcher.Player.Assists(loopcount) ~= assists [loopcount] then		
						Assist2ID = loopcount
						assists [loopcount] = assists [loopcount] + 1
						break
					end
				end
			end
		end
	end
end
function ReloadedCallback()
	LoadAssets()
end
function RenderCallback()
	local X, Y
-- This triggers when and when not to show the clock
	if Launcher.Game.IsShootout() or Launcher.Game.InReplay() then
		return
	elseif Launcher.Game.Paused() then
		if SpriteinEffect == 1 then
			X = Launcher.Screen.Width()*0.5-Launcher.Sprite.Width(PauseSprite)*0.5
			Y = Launcher.Screen.Height()*0.5-Launcher.Sprite.Height(PauseSprite)*0.5
			Launcher.Sprite.Draw(PauseSprite,X,Y)
			return
		end
	end
	if not Launcher.Game.InCutscene() then
		Launcher.Sprite.Draw(SurfaceSprite,0,0) 
	end
end
function ShotAwayCallback()
	ShowShots = 0
-- This keeps track of all total shot attempts made by the visiting team (on goal, blocked and missed)
	TotalAwayShots = TotalAwayShots + 1
	x, y, z = Launcher.Game.PuckPosition()
	if Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3 or Launcher.Game.Period() == 4 then
		if z < -1650 and Launcher.Game.TeamWithPuck() == 1 then
			TotalAwayShots = TotalAwayShots - 1
		elseif z > 1650 and Launcher.Game.TeamWithPuck() == 0 then
			TotalAwayShots = TotalAwayShots - 1
		elseif Launcher.Game.PuckZone() == 1 and PowerPlayTime == 0 then
			ShowAwayShotSpeed = math.random (1, 100)
			if ShowAwayShotSpeed < 25 and PowerPlayTime == 0 then
				AwayShotSpeed = Launcher.Game.ShotSpeed()
				SetStat = 0
				ShowShots = 1
			end
		end
	elseif Launcher.Game.Period() == 2 then
		if z < -1650 and Launcher.Game.TeamWithPuck() == 0 then
			TotalAwayShots = TotalAwayShots - 1
		elseif z > 1650 and Launcher.Game.TeamWithPuck() == 1 then
			TotalAwayShots = TotalAwayShots - 1
		elseif Launcher.Game.PuckZone() == -1 then
			ShowAwayShotSpeed = math.random (1, 100)
			if ShowAwayShotSpeed < 25 and PowerPlayTime == 0 then
				AwayShotSpeed = Launcher.Game.ShotSpeed()
				SetStat = 0
				ShowShots = 1
			end

		end
	end
end
function ShotHomeCallback()
	ShowShots = 0
-- This keeps track of all total shot attempts made by the home team (on goal, blocked and missed)
	TotalHomeShots = TotalHomeShots + 1
	x, y, z = Launcher.Game.PuckPosition()
	if Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3 or Launcher.Game.Period() == 4 then
		if z < -1650 and Launcher.Game.TeamWithPuck() == 1 then
			TotalHomeShots = TotalHomeShots - 1
		elseif z > 1650 and Launcher.Game.TeamWithPuck() == 0 then
			TotalHomeShots = TotalHomeShots - 1
		elseif Launcher.Game.PuckZone() == -1 then
			ShowHomeShotSpeed = math.random (1, 100)
			if ShowHomeShotSpeed < 25 and PowerPlayTime == 0 then
				HomeShotSpeed = Launcher.Game.ShotSpeed()
				SetStat = 0
				ShowShots = 2
			end
		end
	elseif Launcher.Game.Period() == 2 then
		if z < -1650 and Launcher.Game.TeamWithPuck() == 0 then
			TotalHomeShots = TotalHomeShots - 1
		elseif z > 1650 and Launcher.Game.TeamWithPuck() == 1 then
			TotalHomeShots = TotalHomeShots - 1
		elseif Launcher.Game.PuckZone() == 1 then
			ShowHomeShotSpeed = math.random (1, 100)
			if ShowHomeShotSpeed < 25 and PowerPlayTime == 0 then
				HomeShotSpeed = Launcher.Game.ShotSpeed()
				SetStat = 0
				ShowShots = 2
			end
		end
	end
end
function TickCallback()
-- This sets everything up to draw the clock in various states
	Launcher.Screen.SetRenderTarget(1,SurfaceSprite)
	if (Launcher.Game.InCutscene() or Launcher.Game.IsShootout() or Launcher.Game.InReplay()) then
		return
	end
	if Launcher.Screen.BeginScene() then
		Launcher.Screen.Clear(0)
		Launcher.Sprite.Clip(ClockSprite,0,0,1024,128)
		Launcher.Sprite.Draw(ClockSprite, ClockX, ClockY)
		Launcher.Sprite.Draw(HomePog, ClockX+414, ClockY)
		Launcher.Sprite.Draw(AwayPog, ClockX+150, ClockY)
		Period = Launcher.Game.Period()
		if Period == 0 then
			Period = "SHOOTOUT"
		elseif Period == 1 then
			Period = "1ST"
		elseif Period == 2 then
			Period = "2ND"
		elseif Period == 3 then
			Period = "3RD"
		elseif Period == 4 then
			Period = "OT"
		elseif Period == 5 then
			Period = "OT2"
		elseif Period == 6 then
			Period = "OT3"
		elseif Period == 7 then
			Period = "OT4"
		elseif Period == 8 then
			Period = "OT5"
		elseif Period == 9 then
			Period = "OT6"
		elseif Period > 9 then
			Period = "OT"
		end
-- This sets up the offside and icing warnings
		if Launcher.Game.Warning() == 1 then
			Launcher.Sprite.Clip(IcingSprite,0,0,265,32)
			Launcher.Sprite.Draw(IcingSprite, ClockX + 715, ClockY + 128)
		elseif Launcher.Game.Warning() == 2 then
			Launcher.Sprite.Clip(OffsideSprite,0,0,265,32)
			Launcher.Sprite.Draw(OffsideSprite, ClockX + 715, ClockY + 128)
		end
-- This sets up clock displays related to Penalties and Power Plays
		if Launcher.Game.PenaltyPending() then
			PenaltyPending = 1
		 	PenaltyPendingTeam = Launcher.Game.PenaltyPendingTeam()
			Launcher.Sprite.Clip(PenaltySprite,0,0,265,32)
			Launcher.Sprite.Draw(PenaltySprite, ClockX + 715, ClockY + 128)
		end
		if PenaltyPending == 1 then
			PenaltyTeam = Launcher.Game.PenaltyPendingTeam()
			PenaltyPlayer = Launcher.Game.PenaltyPendingPlayer()
			PenaltyPlayerName = Launcher.Player.FirstName(PenaltyPlayer) .. " " .. Launcher.Player.LastName(PenaltyPlayer)
			PenaltyTime = Launcher.Mem.Byte(0x79b3f7)
			if PenaltyTime == 8 then
				PenaltyTime = 5
			end
			if PenaltyTime <= 5 then
				Suffix = "(" .. PenaltyTime .. ":00)"
			else
				Suffix = "(GAME MISCONDUCT)"
			end
			if Launcher.Game.PenaltyPendingID() == 21 then
				PenaltyInfo = "CHARGING"
			elseif Launcher.Game.PenaltyPendingID() == 22 then
				PenaltyInfo = "SLASHING"
			elseif Launcher.Game.PenaltyPendingID() == 23 then
				PenaltyInfo = "ROUGHING"
			elseif Launcher.Game.PenaltyPendingID() == 24 then
				PenaltyInfo = "CROSS-CHECKING"
			elseif Launcher.Game.PenaltyPendingID() == 25 then
				PenaltyInfo = "HOOKING"
			elseif Launcher.Game.PenaltyPendingID() == 26 then
				PenaltyInfo = "TRIPPING"
			elseif Launcher.Game.PenaltyPendingID() == 27 then
				PenaltyInfo = "INTERFERENCE"
			elseif Launcher.Game.PenaltyPendingID() == 28 then
				PenaltyInfo = "HIGH STICKING"
			elseif Launcher.Game.PenaltyPendingID() == 29 then
				PenaltyInfo = "ELBOWING"
			elseif Launcher.Game.PenaltyPendingID() == 30 then
				PenaltyInfo = "CHECKING FROM BEHIND"
			elseif Launcher.Game.PenaltyPendingID() == 31 then
				PenaltyInfo = "BOARDING"
			elseif Launcher.Game.PenaltyPendingID() == 32 then
				PenaltyInfo = "HOLDING"
			elseif Launcher.Game.PenaltyPendingID() == 34 then
				PenaltyInfo = "HOOKING"
			elseif Launcher.Game.PenaltyPendingID() == 35 then
				PenaltyInfo = "HOLDING"
			elseif Launcher.Game.PenaltyPendingID() == 36 then
				PenaltyInfo = "TRIPPING"
			elseif Launcher.Game.PenaltyPendingID() == 37 then
				PenaltyInfo = "ROUGHING"
			elseif Launcher.Game.PenaltyPendingID() == 38 then
				PenaltyInfo = "FIGHTING"
			elseif Launcher.Game.PenaltyPendingID() == 39 then
				PenaltyInfo = "FIGHT INSTIGATOR"
			elseif Launcher.Game.PenaltyPendingID() == 40 then
				PenaltyInfo = "ABUSE OF OFFICIAL"
			elseif Launcher.Game.PenaltyPendingID() == 41 then
				PenaltyInfo = "ATTEMPT TO INJURE"
			elseif Launcher.Game.PenaltyPendingID() == 42 then
				PenaltyInfo = "DELAY OF GAME"
			elseif Launcher.Game.PenaltyPendingID() == 43 then
				PenaltyInfo = "HOLDING THE STICK"
			elseif Launcher.Game.PenaltyPendingID() == 44 then
				PenaltyInfo = "DIVING"
			elseif Launcher.Game.PenaltyPendingID() == 45 then
				PenaltyInfo = "SPEARING"
			end
		end
		PowerPlayTime = Launcher.Game.PowerplayTime()
		if PowerPlayTime > 0 then
			TrackShots = 1
			PowerPlayTeam = Launcher.Game.PowerplayTeam()
			if Launcher.Game.PenaltyPendingTeam() == 1 then
				Launcher.Sprite.Clip(PowerPlaySprite,0,0,258,32)
				Launcher.Sprite.Draw(PowerPlaySprite, ClockX + 413, ClockY + 128)
			else
				Launcher.Sprite.Clip(PowerPlaySprite,0,0,258,32)
				Launcher.Sprite.Draw(PowerPlaySprite, ClockX + 149, ClockY + 128)
			end
			Minutes = math.floor(PowerPlayTime/60)
			if Minutes == 0 then
				Minutes = ""
			end
			Seconds = PowerPlayTime % 60
			if Seconds < 10 then
				Seconds = "0"..Seconds
			end 
			if Launcher.Game.PenaltyPendingTeam() == 0 then
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 346,ClockY + 130,FontColor2)
			else
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 608,ClockY + 130,FontColor2)
			end
		end
-- This sets up the main time on the clock
		Time = Launcher.Game.Time()
		Minutes = math.floor(Time/60)
		if Minutes == 0 then
			Minutes = ""
		end
		Seconds = Time % 60
		if Seconds < 10 then
			Seconds = "0"..Seconds
		end
-- This decides when to display the tracked Power Play shots
		if TrackShots == 2 then
			TrackShots = 3
			SetStat = 1
		end
		if TrackShots == 1 and PowerPlayTime == 0 then
			TrackShots = 2
			HomeShotsAfterPP = Launcher.Stats.HomeShots()
			AwayShotsAfterPP = Launcher.Stats.AwayShots()
		end
-- This is used to show the "Saves" statistic
		AwaySaves = Launcher.Stats.HomeShots() - Launcher.Stats.HomeGoals()
		HomeSaves = Launcher.Stats.AwayShots() - Launcher.Stats.AwayGoals()
-- These are all the options for statistics that can be displayed on the clock
		if SetStat == 0 then
			SetStat = 1
			MessageTimerOn = Launcher.Game.Time()
			RandomStat = math.random (1, 25)
			CountSincePlayerStats = CountSincePlayerStats + 1
			if GoalJustScored == 2 and ShowShots == 0 then
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()	
				GoalScorerName = Launcher.Player.FirstName(GoalScorerID) .. " " .. Launcher.Player.LastName(GoalScorerID)
				ClockMessage1 = "G: " .. GoalScorerName
				if Assist1ID ~= -1 then
					Assist1Name = Launcher.Player.FirstName(Assist1ID) .. " " .. Launcher.Player.LastName(Assist1ID)
					ClockMessage2 = "A: " .. Assist1Name
				else
					ClockMessage2 = "UNASSISTED"
				end
				if Assist2ID ~= -1 then
					Assist2Name = Launcher.Player.FirstName(Assist2ID) .. " " .. Launcher.Player.LastName(Assist2ID)
					ClockMessage3 = "A: " .. Assist2Name
				else
					ClockMessage3 = " "
				end
				ClockMessage4 = TimeofGoal
			elseif PowerPlayTime == 0 and TrackShots == 3 then	
				TrackShots = 0
				HomeGoals = HomeShotsAfterPP - TrackHomeShots
				HomePPShots = HomePPShots + HomeGoals
				AwayGoals = AwayShotsAfterPP - TrackAwayShots
				AwayPPShots = AwayPPShots + AwayGoals
				ClockMessage = "SHOTS LAST PP"
			elseif ShowShots == 1 then
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()	
				ClockMessage = "SHOT: " .. AwayShotSpeed
			elseif ShowShots == 2 then
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()	
				ClockMessage = "SHOT:  " .. HomeShotSpeed
			elseif (Launcher.Stats.HomeGoals() > 0 or Launcher.Stats.AwayGoals() > 0 or Launcher.Stats.HomeShots() > 0 or Launcher.Stats.AwayShots() > 0) and RandomStat < 6 and PenaltyPending == 0 and ShowShots == 0 then
				CountSincePlayerStats = 0
				IceTimePlayerSet = 0
				repeat
					IceTimePlayerID = math.random (0, 39)
					if IceTimePlayerID ~= 18 and IceTimePlayerID ~= 19 and IceTimePlayerID ~= 38 and IceTimePlayerID ~= 39 then
						if Launcher.Player.Goals(IceTimePlayerID) > 0 or Launcher.Player.Assists(IceTimePlayerID) > 0 or Launcher.Player.Shots(IceTimePlayerID) > 0 then
							IceTimePlayerSet = 1
						end
					end
				until IceTimePlayerSet == 1
				IceTimePlayerName = Launcher.Player.FirstName(IceTimePlayerID) .. " " .. Launcher.Player.LastName(IceTimePlayerID)
				IceTimePlayerMins = math.floor(Launcher.Player.Time(IceTimePlayerID) / 60)
				IceTimePlayerSecs = Launcher.Player.Time(IceTimePlayerID) % 60
				if IceTimePlayerSecs < 10 then
					IceTimePlayerSecs = "0" .. IceTimePlayerSecs
				end
				IceTimePlayerTOI = IceTimePlayerMins .. ":" .. IceTimePlayerSecs
				IceTimePlayerG = Launcher.Player.Goals(IceTimePlayerID)
				IceTimePlayerA = Launcher.Player.Assists(IceTimePlayerID)
				IceTimePlayerPlusMinus = Launcher.Player.PlusMinus(IceTimePlayerID)
				IceTimePlayerShots = Launcher.Player.Shots(IceTimePlayerID)
				ShowShotsStat = math.random(1, 100)
				if ShowShotsStat > 50 then
					IceTimePlayerPlusMinus = " SHOTS: " .. IceTimePlayerShots
				else
					if IceTimePlayerPlusMinus >= 0 then
						IceTimePlayerPlusMinus = "+" .. IceTimePlayerPlusMinus
					end
				end
				UseSmallDisplay = 1
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()	
				ClockMessage1 = IceTimePlayerName
				ClockMessage2 = IceTimePlayerG .. "G, " .. IceTimePlayerA .. "A, " .. IceTimePlayerPlusMinus .. ", " .. IceTimePlayerTOI .. " TOI"
			elseif (PenaltyPending == 1 or PenaltyPending == 2) and PowerPlayTime > 0 then
				PenaltyPending = 3
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()	
				ClockMessage1 = PenaltyPlayerName
				ClockMessage2 = PenaltyInfo
				ClockMessage3 = Suffix
			elseif PenaltyPending == 4 or (RandomStat == 19 and (Launcher.Stats.HomePowerPlays() > 0 or Launcher.Stats.AwayPowerPlays() > 0)) then
				PenaltyPending = 5
				HomeGoals = Launcher.Stats.HomePowerPlayGoals() .. "/" .. Launcher.Stats.HomePowerPlays()
				AwayGoals = Launcher.Stats.AwayPowerPlayGoals() .. "/" .. Launcher.Stats.AwayPowerPlays()
				ClockMessage = " POWER PLAYS"
			elseif RandomStat == 7 then
				IcinginEffect = 0
				HomeGoals = HomeIcings
				AwayGoals = AwayIcings
				ClockMessage = "       ICINGS"
			elseif RandomStat == 8 then
				OffsidesinEffect = 0
				HomeGoals = HomeOffsides
				AwayGoals = AwayOffsides
				ClockMessage = "    OFFSIDES"
			elseif RandomStat == 9 and (Launcher.Stats.HomeHits() > 0 or Launcher.Stats.AwayHits() > 0) then
				HomeGoals = Launcher.Stats.HomeHits()
				AwayGoals = Launcher.Stats.AwayHits()
				ClockMessage = "     BIG HITS"
			elseif RandomStat == 10 then
				HomeGoals = math.floor((Launcher.Stats.HomePasses() / Launcher.Stats.HomePassAttempts()) * 100)
				AwayGoals = math.floor((Launcher.Stats.AwayPasses() / Launcher.Stats.AwayPassAttempts()) * 100)
				ClockMessage = "   PASSING %"
			elseif RandomStat == 11 then
				HomeGoals = Launcher.Stats.HomeFaceoffsWon()
				AwayGoals = Launcher.Stats.AwayFaceoffsWon()
				ClockMessage = "FACEOFFS WON"
			elseif RandomStat == 12 then
				HomeGoals = Launcher.Stats.HomeOneTimers()
				AwayGoals = Launcher.Stats.AwayOneTimers()
				ClockMessage = "  ONE TIMERS"
			elseif RandomStat == 13 and (Launcher.Stats.HomeShortHandedGoals() > 0 or Launcher.Stats.AwayShortHandedGoals() > 0) then
				HomeGoals = Launcher.Stats.HomeShortHandedGoals()
				AwayGoals = Launcher.Stats.AwayShortHandedGoals()
				ClockMessage = "    SHORTIES"
			elseif RandomStat == 14 and (Launcher.Stats.HomePenalties() > 0 or Launcher.Stats.AwayPenalties() > 0) then
				HomeGoals = Launcher.Stats.HomePenalties()
				AwayGoals = Launcher.Stats.AwayPenalties()
				ClockMessage = "    PENALTIES"
			elseif RandomStat == 15 and (Launcher.Stats.HomePIM() > 0 or Launcher.Stats.AwayPIM() > 0) then
				HomeGoals = math.floor(Launcher.Stats.HomePIM() / 60)
				AwayGoals = math.floor(Launcher.Stats.AwayPIM() / 60)
				ClockMessage = "PENALTY MINS"
			elseif RandomStat == 16 and (HomeSaves > 0 or AwaySaves > 0) then
				HomeGoals = HomeSaves
				AwayGoals = AwaySaves
				ClockMessage = "        SAVES"
			elseif RandomStat == 17 and (Launcher.Stats.HomePowerPlays() > 0 or Launcher.Stats.AwayPowerPlays() > 0) then
				HomeGoals = HomePPShots
				AwayGoals = AwayPPShots
				ClockMessage = " ALL PP SHOTS"
			elseif RandomStat == 18 then
				HomeGoals = math.floor(Launcher.Stats.HomeFaceoffsWon() / (Launcher.Stats.HomeFaceoffsWon() + Launcher.Stats.AwayFaceoffsWon()) * 100)
				AwayGoals = math.ceil(Launcher.Stats.AwayFaceoffsWon() / (Launcher.Stats.HomeFaceoffsWon() + Launcher.Stats.AwayFaceoffsWon()) * 100)
				ClockMessage = "FACEOFF WIN %"
			elseif RandomStat == 20 then
				HomeGoals = Launcher.Stats.HomePasses()
				AwayGoals = Launcher.Stats.AwayPasses()
				ClockMessage = "      PASSES"
			elseif (RandomStat == 21 or RandomStat == 22) and Launcher.Game.Period() < 4 then
				HomeGoals = TotalHomeShots
				AwayGoals = TotalAwayShots
				ClockMessage = "SHOT ATTEMPTS"
			elseif RandomStat == 23 or RandomStat == 24 then
				HomeGoals = math.floor(HomePoss / (HomePoss + AwayPoss) * 100)
				AwayGoals = math.ceil(AwayPoss / (HomePoss + AwayPoss) * 100)
				ClockMessage = "  PUCK POSS %"
			else
				HomeGoals = Launcher.Stats.HomeShots()
				AwayGoals = Launcher.Stats.AwayShots()
				ClockMessage = "SHOTS ON GOAL"
			end
		end
-- This decides how and what to display in regards to statistics
		MessageTimerOff = Launcher.Game.Time()
		MessageTimerDiff = MessageTimerOn - MessageTimerOff
		if MessageTimerDiff < 13 and SetStat == 1 then
			if Launcher.Game.Period() == 3 and Launcher.Game.Time() == 0 and Launcher.Stats.HomeGoals() ~= Launcher.Stats.AwayGoals() then
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()
				ClockMessage = "         FINAL"
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontMessage,ClockMessage,ClockX + TimeX - 58,ClockY + 51,FontColor2)
			elseif Launcher.Game.Period() >= 4 and Launcher.Stats.HomeGoals() ~= Launcher.Stats.AwayGoals() then
				HomeGoals = Launcher.Stats.HomeGoals()
				AwayGoals = Launcher.Stats.AwayGoals()
				ClockMessage = "      FINAL/OT"
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontMessage,ClockMessage,ClockX + TimeX - 58,ClockY + 51,FontColor2)
			elseif UseSmallDisplay == 1 then
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage1,ClockX + TimeX - 64,ClockY + 45,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage2,ClockX + TimeX - 64,ClockY + 66,FontColor2)
			elseif PenaltyPending == 3 then
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage1,ClockX + TimeX - 64,ClockY + 38,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage2,ClockX + TimeX - 64,ClockY + 59,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage3,ClockX + TimeX - 64,ClockY + 80,FontColor2)
			elseif GoalJustScored == 2 then
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage1,ClockX + TimeX - 64,ClockY + 23,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage2,ClockX + TimeX - 64,ClockY + 44,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage3,ClockX + TimeX - 64,ClockY + 65,FontColor2)
				Launcher.Font.DrawText(ClockFontMessageSmall,ClockMessage4,ClockX + TimeX - 64,ClockY + 86,FontColor2)
			else
				Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 115,ClockY + 36,FontColor1)
				Launcher.Font.DrawText(ClockFontMessage,ClockMessage,ClockX + TimeX - 50,ClockY + 46,FontColor2)
			end
		else
			HomeGoals = Launcher.Stats.HomeGoals()
			AwayGoals = Launcher.Stats.AwayGoals()
			Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX - 115,ClockY + 36,FontColor1)
			Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX - 115,ClockY + 36,FontColor1)
			if Launcher.Game.Period() == 0 then
				Launcher.Font.DrawText(ClockFont,Period,ClockX + TimeX - 55,ClockY + 42,FontColor2)
			else
				Launcher.Font.DrawText(ClockFont,Period.."   "..Minutes..":"..Seconds,ClockX + TimeX - 55,ClockY + 42,FontColor2)
			end
		end
        Launcher.Screen.EndScene()		
	end
	Launcher.Screen.ResetRenderTarget()	
end
function ZoneChangedCallback()
-- This is used to show the "Puck Possession" statistic
		if Launcher.Game.TeamWithPuck() == 0 then
			HomePoss = HomePoss + 1
		else
			AwayPoss = AwayPoss + 1
		end
-- This resets certain flags for display purposes
	if Launcher.Game.PuckZone() ~= 0 then
		GoalJustScored = 0
	end

	if ShowShots > 0 and Launcher.Game.PuckZone() == 0 then
		ShowShots = 0
		SetStat = 1
	end

	if UseSmallDisplay == 1 and Launcher.Game.PuckZone() == 0 then
		UseSmallDisplay = 0
		SetStat = 1
	end
end
-- Callback Definitions
Launcher.Callback.Register("CutsceneStarted",CutsceneStartedCallback)
Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("Penalty",PenaltyCallback)
Launcher.Callback.Register("PeriodStarted",PeriodStartedCallback)
Launcher.Callback.Register("PlayStopped",PlayStoppedCallback)
Launcher.Callback.Register("RenderBackground",RenderCallback)
Launcher.Callback.Register("Reloaded",ReloadedCallback)
Launcher.Callback.Register("ShotAway",ShotAwayCallback)
Launcher.Callback.Register("ShotHome",ShotHomeCallback)
Launcher.Callback.Register("Tick",TickCallback)
Launcher.Callback.Register("ZoneChanged",ZoneChangedCallback)
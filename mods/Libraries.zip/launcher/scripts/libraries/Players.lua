--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]

Launcher.Player = {}
Launcher.Player.Photo = function (PlayerID, NewValue)
	local Address
	local Team = 0
	if PlayerID == -1 then
		return nil
	end
	if PlayerID > 19 then
		Team = 1
	end
	Address = 0x7a8768 + 0xA0 + (0x6A8*Team) + (0x4C * (PlayerID-(Team*20)))
	if NewValue == nil then
        return Launcher.Mem.Long(Address)
    else
        Launcher.Mem.WriteLong(Address,NewValue)
    end
end
Launcher.Player.PBP = function (PlayerID)
	local Address
	local Team = 0
	if PlayerID == -1 then
		return nil
	end
	if PlayerID > 19 then
		Team = 1
	end
	Address = 0x7a8768 + 0xA0 + (0x6A8*Team) + (0x4C * (PlayerID-(Team*20))) + 0x4
	return Launcher.Mem.Long(Address)
end
Launcher.Player.FirstName = function (PlayerID, NewValue)
	local Address
	local Team = 0
	if PlayerID == -1 then
		return nil
	end
	if PlayerID > 19 then
		Team = 1
	end
	Address = 0x7a8768 + 0xA0 + (0x6A8*Team) + (0x4C * (PlayerID-(Team*20))) + 0x8
	if NewValue == nil then
        return Launcher.Mem.String(Address)
    else
        Launcher.Mem.WriteString(Address, NewValue)
    end
end
Launcher.Player.LastName = function (PlayerID, NewValue)
	local Address
	local Team = 0
	if PlayerID == -1 then
		return nil
	end
	if PlayerID > 19 then
		Team = 1
	end
	Address = 0x7a8768 + 0xA0 + (0x6A8*Team) + (0x4C * (PlayerID-(Team*20))) + 0x18
	if NewValue == nil then
        return Launcher.Mem.String(Address)
    else
        Launcher.Mem.WriteString(Address, NewValue)
    end
end

-- -----------------------------
Launcher.Player.Speed = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer)
    else
        Launcher.Mem.WriteByte(Pointer, NewValue)
    end
end
Launcher.Player.Acceleration = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+1)
    else
        Launcher.Mem.WriteByte(Pointer+1, NewValue)
    end
end
Launcher.Player.Agility = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+2)
    else
        Launcher.Mem.WriteByte(Pointer+2, NewValue)
    end
end
Launcher.Player.Balance = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+3)
    else
        Launcher.Mem.WriteByte(Pointer+3, NewValue)
    end
end
Launcher.Player.ShotPower = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+4)
    else
        Launcher.Mem.WriteByte(Pointer+4, NewValue)
    end
end
Launcher.Player.ShotAccuracy = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+5)
    else
        Launcher.Mem.WriteByte(Pointer+5, NewValue)
    end
end
Launcher.Player.Passing = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+6)
    else
        Launcher.Mem.WriteByte(Pointer+6, NewValue)
    end
end
Launcher.Player.Deking = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+7)
    else
        Launcher.Mem.WriteByte(Pointer+7, NewValue)
    end
end
Launcher.Player.PuckControl = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+8)
    else
        Launcher.Mem.WriteByte(Pointer+8, NewValue)
    end
end
Launcher.Player.Faceoffs = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+9)
    else
        Launcher.Mem.WriteByte(Pointer+9, NewValue)
    end
end
Launcher.Player.Aggression = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+10)
    else
        Launcher.Mem.WriteByte(Pointer+10, NewValue)
    end
end
Launcher.Player.Checking = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+11)
    else
        Launcher.Mem.WriteByte(Pointer+11, NewValue)
    end
end
Launcher.Player.Endurance = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+12)
    else
        Launcher.Mem.WriteByte(Pointer+12, NewValue)
    end
end
Launcher.Player.Fight = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+13)
    else
        Launcher.Mem.WriteByte(Pointer+13, NewValue)
    end
end
Launcher.Player.Penalty = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+14)
    else
        Launcher.Mem.WriteByte(Pointer+14, NewValue)
    end
end
Launcher.Player.Toughness = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+15)
    else
        Launcher.Mem.WriteByte(Pointer+15, NewValue)
    end
end
Launcher.Player.Injury = function (PlayerID, NewValue)
    local Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C
    if NewValue == nil then
        return Launcher.Mem.Byte(Pointer+16)
    else
        Launcher.Mem.WriteByte(Pointer+16, NewValue)
    end
end
Launcher.Player.AllSetAttribute = function(Attribute, NewValue, Team, NoGoalie) 
    local Pointer, Min, Max, PlayerID
    if Team == nil then
        Min = 0
        if NoGoalie == true then
            Max = 37
        else
            Max = 39
        end
    elseif Team == 0 then
        Min = 0
        if NoGoalie == true then
            Max = 17
        else
            Max = 19
        end
    else
        Min = 20
        if NoGoalie == true then
            Max = 37
        else
            Max = 39
        end
    end
    for PlayerID = Min,Max do
        Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C + Attribute
        Launcher.Mem.WriteByte(Pointer, NewValue)
    end
end
Launcher.Player.AllSetAttributeMultiplier = function(Attribute, Multiplier, Team, NoGoalie) 
    local Pointer, Min, Max, PlayerID, Value
    if Team == nil then
        Min = 0
        if NoGoalie == true then
            Max = 37
        else
            Max = 39
        end
    elseif Team == 0 then
        Min = 0
        if NoGoalie == true then
            Max = 17
        else
            Max = 19
        end
    else
        Min = 20
        if NoGoalie == true then
            Max = 37
        else
            Max = 39
        end
    end
    for PlayerID = Min,Max do
        Pointer = Launcher.Mem.Long(0x79C310+PlayerID*4) + 0x7C + Attribute
		Value = Launcher.Mem.Byte(Pointer)
		Value = math.floor(Value * Multiplier)
		if Value > 255 then
			Value = 255
		elseif Value < 0 then
			Value = 0
		end
        Launcher.Mem.WriteByte(Pointer, Value)
    end
end

-- -----------------------------

Launcher.Player.Time = function(PlayerID)
    local Team
    local Offset = 0x7A9690 + (0x14 * PlayerID)
    return Launcher.Mem.Short(Offset)
end
Launcher.Player.Goals = function(PlayerID)
    local Offset = 0x7A9690 + (0x14 * PlayerID)
    return Launcher.Mem.Byte(Offset+2)
end
Launcher.Player.Assists = function(PlayerID)
    local Offset = 0x7A9690 + (0x14 * PlayerID)
    return Launcher.Mem.Byte(Offset+3)
end
Launcher.Player.PIM = function(PlayerID)
    local Offset = 0x7A9690 + (0x14 * PlayerID)
    return Launcher.Mem.Byte(Offset+4)
end
Launcher.Player.PlusMinus = function(PlayerID)
    local Offset = 0x7A9690 + (0x14 * PlayerID)
    return Launcher.Mem.Byte(Offset+5)
end
Launcher.Player.PPG = function(PlayerID)
    local Offset = 0x7A9690 + (0x14 * PlayerID)
    return Launcher.Mem.Byte(Offset+6)
end
Launcher.Player.SHG = function(PlayerID)
    local Offset = 0x7A9690 + (0x14 * PlayerID)
    return Launcher.Mem.Byte(Offset+7)
end
Launcher.Player.Hits = function(PlayerID)
    local Offset = 0x7A9690 + (0x14 * PlayerID)
    return Launcher.Mem.Byte(Offset+13)
end
Launcher.Player.Shots = function(PlayerID)
    local Offset = 0x7A9690 + (0x14 * PlayerID)
    return Launcher.Mem.Byte(Offset+12)
end
Launcher.Player.Points = function(PlayerID)
    return Launcher.Player.Goals(PlayerID) + Launcher.Player.Assists(PlayerID)
end
Launcher.Player.GoalPercent = function(PlayerID)
    local Goals = Launcher.Player.Goals(PlayerID)
    local Shots = Launcher.Player.Shots(PlayerID)
    if Goals > 0 then
        if Shots == 0 then
            return 100
        end
        return math.floor(100 / (Shots/Goals))
    else
        return 0
    end
end
-- Goalie
Launcher.Player.ShotsAgainst = function(PlayerID)
    return Launcher.Player.Goals(PlayerID)
end
Launcher.Player.Saves = function(PlayerID)
    return Launcher.Player.Shots(PlayerID)
end

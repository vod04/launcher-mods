--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]
Launcher.Line = {}

LINESC1 = 0
LINESC2 = 3
LINECK3 = 6
LINECK4 = 9
LINEDP1 = 12
LINEDP2 = 14
LINEDP3 = 16
LINE5PP1 = 18
LINE5PP2 = 23
LINE4PP1= 28
LINE4PP2 = 32
LINE4PK1 = 36
LINE4PK2 = 40
LINE3PK1 = 44
LINE3PK2 = 47
LINEEXAT = 50
SetLineASMPointer = 0
SetLineTeamBuffer = 0
SetLineLineBuffer = 0
Launcher.Line.HomePlayer = function(Line, Position, PlayerID)
    if PlayerID == nil then
        Launcher.Mem.Byte(0x7A87BC+Line+Position)
    else
        Launcher.Mem.WriteByte(0x7A87BC+Line+Position, PlayerID)
    end
end
Launcher.Line.AwayPlayer = function(Line, Position, PlayerID)
    if PlayerID == nil then
        Launcher.Mem.Byte(0x7A8E64+Line+Position)
    else
        Launcher.Mem.WriteByte(0x7A8E64+Line+Position, PlayerID)
    end
end
Launcher.Line.Set = function(Team, Line)
	if SetLineASMPointer == 0 then
		SetLineTeamBuffer = Launcher.Mem.Alloc(4)
		SetLineLineBuffer = Launcher.Mem.Alloc(4)
		local ASM = [[ 
			push 1
			push dword []] .. tostring(SetLineTeamBuffer).. [[] 
			mov eax,0x4A6800
			call eax
			add esp, 4
			push dword []] .. tostring(SetLineLineBuffer) .. [[] 
			push dword []] .. tostring(SetLineTeamBuffer) .. [[] 
			mov eax, 0x4A6B40
			call eax
			add esp, 0x0c
			ret
		]]
		SetLineASMPointer = Launcher.Mem.AssembleString(ASM)
	end
	Launcher.Mem.WriteLong(SetLineTeamBuffer,Team)
	Launcher.Mem.WriteLong(SetLineLineBuffer,Line)
	Launcher.Mem.Call(SetLineASMPointer)
end

--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]


Launcher.Camera.FOVModifier = function()
    return Launcher.Env.Number("fovmod")
end
Launcher.Camera.SetFOVModifier = function(FOV)
    Launcher.Env.SetNumber("fovmod",FOV)
end
Launcher.Camera.TargetX = function()
    return Launcher.Mem.Float(0x7bd618)
end
Launcher.Camera.TargetY = function()
    return Launcher.Mem.Float(0x7bd61c)
end
Launcher.Camera.TargetZ = function()
    return Launcher.Mem.Float(0x7bd620)
end
Launcher.Camera.Target = function()
    return Launcher.Mem.Float(0x7bd618), Launcher.Mem.Float(0x7bd61C),Launcher.Mem.Float(0x7bd620)
end
Launcher.Camera.SetTarget = function(X, Y)
    Launcher.Mem.WriteFloat(0x7bd618,X)
    Launcher.Mem.WriteFloat(0x7bd620,Y)
end
Launcher.Camera.SetType = function(Type)
    Launcher.Mem.WriteByte(0x7AC9FC, Type)
end
Launcher.Camera.Type = function()
    return Launcher.Mem.Byte(0x7AC9FC)
end
Launcher.Camera.SetPosition = function(X,Y,Z)
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		Launcher.Mem.WriteFloat(Camera,X)
		Launcher.Mem.WriteFloat(Camera+0x4,Y)
		Launcher.Mem.WriteFloat(Camera+0x8,Z)
	end
end
Launcher.Camera.X = function()
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		return Launcher.Mem.Float(Camera)
	else
		return -1
	end
end
Launcher.Camera.Y = function()
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		return Launcher.Mem.Float(Camera+0x4)
	else
		return -1
	end
end
Launcher.Camera.Z = function()
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		return Launcher.Mem.Float(Camera+0x8)
	else
		return -1
	end
end
Launcher.Camera.Position = function()
	Camera = Launcher.Mem.Long(0x7ACA04)
    return Launcher.Mem.Float(Camera), Launcher.Mem.Float(Camera+0x4), Launcher.Mem.Float(Camera+0x8)    
end
Launcher.Camera.Tilt = function ()
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		return Launcher.Mem.Float(Camera+0xC)
	else
		return -1
	end
end
Launcher.Camera.SetTilt = function (Tilt)
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		return Launcher.Mem.WriteFloat(Camera+0xC,Tilt)
	else
		return -1
	end
end
Launcher.Camera.Rotation = function ()
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		return Launcher.Mem.Float(Camera+0x10)
	else
		return -1
	end
end
Launcher.Camera.SetRotation = function (Rotation)
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		Launcher.Mem.WriteFloat(Camera+0x10,Rotation)
	end
end
Launcher.Camera.Roll = function ()
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		return Launcher.Mem.Float(Camera+0x14)
	else
		return -1
	end
end
Launcher.Camera.SetRoll = function (Roll)
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		Launcher.Mem.WriteFloat(Camera+0x14,Roll)
	end
end
Launcher.Camera.Zoom = function ()
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		return Launcher.Mem.Float(Camera+0x18)
	else
		return -1
	end
end
Launcher.Camera.SetZoom = function (Zoom)
    local Camera = Launcher.Mem.Long(0x7ACA04)
	if Camera > 0 then
		Launcher.Mem.WriteFloat(Camera+0x18,Zoom)
	end
end
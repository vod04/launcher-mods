--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]


Launcher.Camera.Rotation = function ()
    return Launcher.Mem.Float(0x7BD610)
end
Launcher.Camera.SetRotation = function (Rotation)
    Launcher.Mem.WriteFloat(0x7BD610,Rotation)
end
Launcher.Camera.Roll = function ()
    return Launcher.Mem.Float(0x7BD614)
end
Launcher.Camera.SetRoll = function (Roll)
    Launcher.Mem.WriteFloat(0x7BD614,Roll)
end
Launcher.Camera.Tilt = function ()
    return Launcher.Mem.Float(0x7BD60C)
end
Launcher.Camera.SetTilt = function (Tilt)
    Launcher.Mem.WriteFloat(0x7BD60C,Tilt)
end
Launcher.Camera.Speed = function ()
    return Launcher.Mem.Float(0x7bd580)
end
Launcher.Camera.SetSpeed = function (Speed)
    Launcher.Mem.WriteFloat(0x7bd580,Speed)
end
Launcher.Camera.FOVModifier = function()
    return Launcher.Env.Number("fovmod")
end
Launcher.Camera.SetFOVModifier = function(FOV)
    Launcher.Env.SetNumber("fovmod",FOV)
end
Launcher.Camera.TargetX = function()
    return Launcher.Mem.WriteFloat(0x7bd618)
end
Launcher.Camera.TargetY = function()
    return Launcher.Mem.WriteFloat(0x7bd620)
end
Launcher.Camera.Target = function()
    return Launcher.Mem.Float(0x7bd618),Launcher.Mem.Float(0x7bd620)
end
Launcher.Camera.SetTarget = function(X, Y)
    Launcher.Mem.WriteFloat(0x7bd618,X)
    Launcher.Mem.WriteFloat(0x7bd620,Y)
end
Launcher.Camera.SetMode = function(Camera)
    Launcher.Mem.WriteByte(0x7AC9FC, Camera)
end
Launcher.Camera.Mode = function()
    Launcher.Mem.Byte(0x7AC9FC)
end
Launcher.Camera.SetPosition = function(X,Y,Z)
    local Camera = Launcher.Mem.Long(0x7bd554)
    Launcher.Mem.WriteFloat(Camera+28,X)
    Launcher.Mem.WriteFloat(Camera+32,Z)
    Launcher.Mem.WriteFloat(Camera+36,Y)
end
Launcher.Camera.X = function()
    local Camera = Launcher.Mem.Long(0x7bd554)
    return Launcher.Mem.Float(Camera+28)
end
Launcher.Camera.Y = function()
    local Camera = Launcher.Mem.Long(0x7bd554)
    return Launcher.Mem.Float(Camera+36)
end
Launcher.Camera.Z = function()
    local Camera = Launcher.Mem.Long(0x7bd554)
    return Launcher.Mem.Float(Camera+32)
end
Launcher.Camera.Position = function()
    return Launcher.Mem.Float(Camera+28), Launcher.Mem.Float(Camera+32), Launcher.Mem.Float(Camera+36)    
end
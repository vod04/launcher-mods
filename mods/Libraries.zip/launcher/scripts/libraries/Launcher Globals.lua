--priority=1.0
LauncherGlobal = {}
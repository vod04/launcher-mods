--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]

Launcher.Stats = {}

Launcher.Stats.Fights = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Byte(0x79BA4B)
    else
        Launcher.Mem.WriteByte(0x79BA4B,NewValue)
    end
end

-- -----------------------------

Launcher.Stats.HomeGoals = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7a95da)
    else
        Launcher.Mem.WriteShort(0x7A4AC8,NewValue)
        Launcher.Mem.WriteShort(0x7a95da,NewValue)
    end
end
Launcher.Stats.HomeShots = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7A95D8)
    else
        Launcher.Mem.WriteShort(0x7A95D8, NewValue)
    end
end
Launcher.Stats.HomeHits = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7A9608)
    else
        Launcher.Mem.WriteShort(0x7A9608, NewValue)
    end
end
Launcher.Stats.HomePasses = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7A960C)
    else
        Launcher.Mem.WriteShort(0x7A960C, NewValue)
    end
end
Launcher.Stats.HomePassAttempts = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7A960A)
    else
        Launcher.Mem.WriteShort(0x7A970A, NewValue)
    end
end
Launcher.Stats.HomeFaceoffsWon = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7A95E8)
    else
        Launcher.Mem.WriteShort(0x7A95E8, NewValue)
    end
end
Launcher.Stats.HomeOneTimers = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7A95FC)
    else
        Launcher.Mem.WriteShort(0x7A95FC, NewValue)
    end
end
Launcher.Stats.HomePowerPlays = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7A95EC)
    else
        Launcher.Mem.WriteShort(0x7A95EC, NewValue)
    end
end
Launcher.Stats.HomePowerPlayGoals = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7A95EE)
    else
        Launcher.Mem.WriteShort(0x7A95EE, NewValue)
    end
end
Launcher.Stats.HomeShortHandedGoals = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7A95E0)
    else
        Launcher.Mem.WriteShort(0x7A95E0, NewValue)
    end
end
Launcher.Stats.HomeEmptyNetGoals = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7A95E4)
    else
        Launcher.Mem.WriteShort(0x7A95E4, NewValue)
    end
end
Launcher.Stats.HomePIM = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A95F6)
    else
        Launcher.Mem.WriteShort(0x7A95F6, NewValue)
    end
end
Launcher.Stats.HomePenalties = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A95F4)
    else
        Launcher.Mem.WriteShort(0x7A95F4, NewValue)
    end
end
-- ------------------------------

Launcher.Stats.AwayShots = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A9634)
    else
    end
end
Launcher.Stats.AwayGoals = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7a9636)
    else
        Launcher.Mem.WriteShort(0x7A4ACC,NewValue)
        Launcher.Mem.WriteShort(0x7a9636,NewValue)
    end
end
Launcher.Stats.AwayHits = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A9664)
    else
        Launcher.Mem.WriteShort(0x7A9664, NewValue)
    end
end
Launcher.Stats.AwayPasses = function (NewValue)
    if NewValue == nil then
        return Launcher.Mem.Short(0x7A9668)
    else
        Launcher.Mem.WriteShort(0x7A9668, NewValue)
    end
end
Launcher.Stats.AwayPassAttempts = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A9666)
    else
        Launcher.Mem.WriteShort(0x7A9666, NewValue)
    end
end
Launcher.Stats.AwayFaceoffsWon = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A9644)
    else
        Launcher.Mem.WriteShort(0x7A9644, NewValue)
    end
end
Launcher.Stats.AwayOneTimers = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A9658)
    else
        Launcher.Mem.WriteShort(0x7A9658, NewValue)
    end
end
Launcher.Stats.AwayPowerPlays = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A9648)
    else
        Launcher.Mem.WriteShort(0x7A9648, NewValue)
    end
end
Launcher.Stats.AwayPowerPlayGoals = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A964A)
    else
        Launcher.Mem.WriteShort(0x7A964A, NewValue)
    end
end
Launcher.Stats.AwayShortHandedGoals = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A963C)
    else
        Launcher.Mem.WriteShort(0x7A963C, NewValue)
    end
end
Launcher.Stats.AwayEmptyNetGoals = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A9640)
    else
        Launcher.Mem.WriteShort(0x7A9640, NewValue)
    end
end
Launcher.Stats.AwayPIM = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A9652)
    else
        Launcher.Mem.WriteShort(0x7A9652, NewValue)
    end
end
Launcher.Stats.AwayPenalties = function (NewValue)
	if NewValue == nil then
        return Launcher.Mem.Short(0x7A9650)
    else
        Launcher.Mem.WriteShort(0x7A9650, NewValue)
    end
end

-- -----------------------------
Launcher.PeriodStats = {}
Launcher.PeriodStats.ShotsHome = function(Period, NewValue)
    if NewValue == nil then
        return Launcher.Mem.Byte(0x7A960E + Period)
    else
        Launcher.Mem.WriteByte(0x7A960E + Period,NewValue)
    end
end
Launcher.PeriodStats.GoalsHome = function(Period, NewValue)
    if NewValue == nil then
        return Launcher.Mem.Byte(0x7A9612 + Period)
    else
        Launcher.Mem.WriteByte(0x7A9612 + Period,NewValue)
    end
end
Launcher.PeriodStats.ShotsAway = function(Period, NewValue)
    if NewValue == nil then
        return Launcher.Mem.Byte(0x7A966A + Period)
    else
        Launcher.Mem.WriteByte(0x7A966a + Period,NewValue)
    end
end
Launcher.PeriodStats.GoalsAway = function(Period, NewValue)
    if NewValue == nil then
        return Launcher.Mem.Byte(0x7A966E + Period)
    else
        Launcher.Mem.WriteByte(0x7A966E + Period,NewValue)
    end
end
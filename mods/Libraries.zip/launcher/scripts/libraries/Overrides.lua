--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]

Launcher.Override = {}
Launcher.Override.DisableGameClock = function ()
    Launcher.Mem.WriteByte(0x7bd8bc,1)
    Launcher.Mem.WriteASM(0x415d01,[[
        nop 
        nop 
        nop 
        nop 
        nop 
        nop
    ]])

end
Launcher.Override.EnableGameClock = function ()
    Launcher.Mem.WriteASM(0x415d01,[[
        mov [0x7BD8BC],esi
    ]])

end
Launcher.Override.DisableTimer = function ()
	Launcher.Mem.WriteASM(0x4a1916,[[
        nop
        nop
    ]])
	Launcher.Mem.WriteASM(0x4a1919,[[
        nop
        nop
        nop
        nop
        nop
        nop
        nop
    ]])
end
Launcher.Override.EnableOverlay = function ()
	Launcher.Mem.WriteASM(0x54fb20,[[
        push esi
    ]])
end
Launcher.Override.DisableOverlay = function ()
	Launcher.Mem.WriteASM(0x54fb20,[[
        retn
    ]])
end
Launcher.Override.DisableWindowFocusCheck = function ()
	Launcher.Mem.WriteASM(0x653788,[[
        nop 
        nop 
        nop 
        nop 
        nop
     ]])
end
Launcher.Override.DisableMusic = function ()
	Launcher.Mem.WriteFloat(0x752EB4,0.0)
	--Launcher.Mem.WriteByte(0x78D568,0)

    local Address = Launcher.Mem.Alloc(4)
    Launcher.Mem.WriteLong(Address,0)
    --Launcher.Mem.WriteASM(0x41a0e3,[[ -- Menu
    --    mov ecx,[]]..Address..[[]
    --]])
    Launcher.Mem.WriteASM(0x415f42,[[
       fild dword []]..Address..[[]
    ]])
	Launcher.Mem.WriteASM(0x513C7E,[[
        fild dword []]..Address..[[]
    ]])
	Launcher.Mem.WriteASM(0x51a517,[[
        mov ecx,[]]..Address..[[]
    ]])
	Launcher.Mem.WriteASM(0x51a6cd,[[
        fild dword []]..Address..[[]
    ]])
	Launcher.Mem.WriteASM(0x51ac96,[[
        mov ecx,[]]..Address..[[]
    ]])
	Launcher.Mem.WriteASM(0x51b1bf,[[
        mov ecx,[]]..Address..[[]
    ]])
	Launcher.Mem.WriteASM(0x525710,[[
        xor eax, eax
        ret
    ]])
    Launcher.Mem.WriteASM(0x525c47,[[
        fild dword []]..Address..[[]
    ]])
    Launcher.Mem.WriteASM(0x525e11,[[
        fild dword []]..Address..[[]
    ]])
	Launcher.Mem.WriteASM(0x6af8d5,[[
        mov edx,[]]..Address..[[]
    ]])
    Launcher.Mem.WriteByte(0x70bb47,0)
    Launcher.Mem.WriteByte(0x70bb41,0)
    Launcher.Mem.WriteByte(0x6f6049,0)
	Launcher.Mem.WriteASM(0x42aff0,[[
        ret
    ]])    

end
Launcher.Override.DisableHorn = function()
    Launcher.Mem.WriteByte(0x70ccb0,0x49)
    Launcher.Mem.WriteByte(0x70cd03,0x49)
end
Launcher.Override.DisablePoints = function()
    Launcher.Mem.WriteASM(0x56F780,"ret")
end
Launcher.Override.DisableScreenshot = function()
    Launcher.Mem.WriteASM(0x40E304,"ret")
end
Launcher.Override.DisableCameraTarget = function()
    Launcher.Mem.WriteASM(0x588F6E,[[
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
    ]])
    Launcher.Mem.WriteASM(0x588F7A,[[
        NOP
        NOP
        NOP
        NOP
        NOP
    ]])
    Launcher.Mem.WriteASM(0x588F9B,[[
        NOP
        NOP
        NOP
        NOP
        NOP
    ]])
    Launcher.Mem.WriteASM(0x588FA6,[[
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
    ]])

end
Launcher.Override.EnableCameraTarget = function()
    Launcher.Mem.WriteASM(0x588F6E,"mov [007BD618],ecx")
    Launcher.Mem.WriteASM(0x588F7A,"mov [007BD620],eax")
    Launcher.Mem.WriteASM(0x588F9B,"mov [007BD618],eax")
    Launcher.Mem.WriteASM(0x588FA6,"mov [007BD620],edx")
end

Launcher.Override.DisableCameraTilt = function()
    Launcher.Mem.WriteASM(0x58930E,[[
        NOP
        NOP
        NOP
        NOP
        NOP
    ]])
end
Launcher.Override.EnableCameraTilt = function()
    Launcher.Mem.WriteASM(0x58930E,"mov [007BD60C],eax")
end
Launcher.Override.DisableCameraRotation = function()
    Launcher.Mem.WriteASM(0x589316,[[
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
    ]])
end
Launcher.Override.EnableCameraRotation = function()
    Launcher.Mem.WriteASM(0x589316,"mov [007BD610],ecx")
end

Launcher.Override.DisableCameraRoll = function()
    Launcher.Mem.WriteASM(0x58931f,[[
        NOP
        NOP
        NOP
        NOP
        NOP
        NOP
    ]])
end
Launcher.Override.EnableCameraRoll = function()
    Launcher.Mem.WriteASM(0x58931f,"mov [007BD614],edx")
end
Launcher.Override.DisableCameraMove = function() 
    Launcher.Mem.WriteASM(0x58920f,[[
        NOP
        NOP
    ]])
    Launcher.Mem.WriteASM(0x589214,[[
        NOP
        NOP
        NOP
    ]])
    Launcher.Mem.WriteASM(0x58921a,[[
        NOP
        NOP
        NOP
    ]])
end
Launcher.Override.DisableCamera = function()
	Launcher.Mem.WriteASM(0x6077c6,[[
        NOP
        NOP
	]])
end
Launcher.Override.EnableCamera = function()
	Launcher.Mem.WriteASM(0x6077c6,[[
		repe movsd 
	]])
end
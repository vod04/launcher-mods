dofile("launcher/scripts/language/"..Launcher.Config.String("language","EN")..".lua")

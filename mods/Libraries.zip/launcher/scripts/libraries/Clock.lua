Launcher.Clock = {}

Launcher.Clock.SetHideDuration = function(Time)
    Launcher.Mem.WriteByte(0x58f639,Time)
end
Launcher.Clock.HideDuration = function()
    Launcher.Mem.Byte(0x58f639)
end

Launcher.Clock.SetDisplayDuration = function(Time)
    Launcher.Mem.WriteByte(0x58f6a2,Time)
end
Launcher.Clock.DisplayDuration = function()
    Launcher.Mem.Byte(0x58f6a2)
end
Launcher.Clock.SetDisplayPowerPlaySeconds = function()
    Launcher.Mem.Byte(0x58F651)
end
Launcher.Clock.DisplayPowerPlaySeconds = function()
    Launcher.Mem.Byte(0x58F651)
end
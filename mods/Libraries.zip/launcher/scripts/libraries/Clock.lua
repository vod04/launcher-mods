Launcher.Clock = {}

Launcher.Clock.SetHideDuration = function(Time)
    Launcher.Mem.WriteByte(0x58f639,Time)
end
Launcher.Clock.HideDuration = function()
    return Launcher.Mem.Byte(0x58f639)
end

Launcher.Clock.SetDisplayDuration = function(Time)
    Launcher.Mem.WriteByte(0x58f6a2,Time)
end
Launcher.Clock.DisplayDuration = function()
    return Launcher.Mem.Byte(0x58f6a2)
end
Launcher.Clock.SetDisplayPowerPlaySeconds = function()
    return Launcher.Mem.Byte(0x58F651)
end
Launcher.Clock.DisplayPowerPlaySeconds = function()
    return Launcher.Mem.Byte(0x58F651)
end
Launcher.Clock.Shown = function()
	if Launcher.Mem.Byte(0x7bd8a4) == 1 then
		return true
	else
		return false
	end
end
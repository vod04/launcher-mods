-- Lines that start with "--" are comments. They are not executed 
-- Let's define some basic global variables to make it easier to adjust things

ClockWidth = 768
ClockHeight = 64

FontSize = 40
FontSize2 = 48
FontSize3 = 22
FontSizeTime = 32
FontSizeTime_NOT = 24
FontSizeShots = 16

FontWeight = 550
FontWeight2 = 500
FontWeightClock = 400
FontWeight3 = 800
FontWeight4 = 1000

-- Colors are ARGB
FontColor1 = 0xeeffffff
FontColor2 = 0xee000000
AwayGoalsX = 290.3682
AwayGoalsX_1 = 294.9043
AwayGoalsX_N = 292
HomeGoalsX = 365.3682
HomeGoalsX_1 = 369.9043
HomeGoalsX_N = 367
Goals_Y = 12

Time_X = 672.3223
Time_X_1N = 680
Time_X_N = 688
Time_X_1 = 693
Period_X_1 = 625
Period_X = 618
Period_X_OT = 624.2178
Period_X_NOT = 619.5566
Period_Y = 18.3062
Period_Y_NOT = 18.5479

ShotsAX = 174.1489
ShotsAX_1 = 175.4722
ShotsAX_N = 174.5
ShotsAX_1N = 170.7471
ShotsAX_NN = 170.1309
ShotsHX = 78.1489
ShotsHX_1 = 79.4722
ShotsHX_N = 78.5
ShotsHX_1N = 74.7471
ShotsHX_NN = 74.1309
Shots_Y = 43.188

HomeX = 415	
AwayX = 80 

HomeGoalPogX = 574
HomeGoalColourX = 80
AwayGoalPogX = 80
AwayGoalColourX = 280

GoalTimer_Max=1100
GoalTimer=1099

-- The following is the ideal screen resolution. Anything higher or lower will result in scaling of the surface
NativeResolutionX = 1920 
NativeResolutionY = 1080
NativeResolutionAspect = NativeResolutionY/NativeResolutionX	

-- First, Let's disable the default gameclock (this function is bugged in beta 4, so leave it commented for now)
-- The code at the very bottom fixes this bug
-- Launcher.Override.DisableGameClock()

Launcher.Override.DisableOverlay()

-- Jump down to see the callback definitions

--OFFSIDES and ICINGS
function Launcher.Game.PowerplayTime()
   return Launcher.Mem.Short(0x7BD8B0)
end
function Launcher.Game.Warning()
   return Launcher.Mem.Byte(0x79BB05)
end


-- ************ CALLBACK FUNCTIONS ************ 

-- The following callback function is called as soon as the D3D device is created, right before the game loading screen.
-- It is only called once, so this is where we load things like fonts, textures and sprites

function LoadAssets()
    
    -- First, let's load the background image of our gameclock. The image dimensions should be pow2. 
    -- 2D images drawn to the screen are called "sprites". Sprites can be scaled, rotated, faded etc.
    -- After the sprite is loaded, the handle is stored in the BGSprite variable
    Font_RSN = Launcher.Font.AddFile("launcher/media/fonts/RSN_Soin_Sans.otf")
    Font_RSN_Bold = Launcher.Font.AddFile("launcher/media/fonts/RSN_Soin_Sans_Bold.otf")
	FontFamily = "Soin Sans Neue Medium"
	FontFamily2 = "Soin Sans Neue Bold"

	SurfaceSprite = Launcher.Sprite.Create(NativeResolutionX, NativeResolutionY,1)
	Launcher.Sprite.Scale(SurfaceSprite,Launcher.Screen.Width()/NativeResolutionX, (Launcher.Screen.Width()*NativeResolutionAspect)/NativeResolutionY)
	
    -- Next, let's load a font that we can use later to draw text
    -- The font handle will then be stored in the global variable, ClockFont
    FontTime = Launcher.Font.Load(FontFamily,FontSizeTime,FontWeight2)
    FontTime_NOT = Launcher.Font.Load(FontFamily,FontSizeTime_NOT,FontWeight2)
	FontGoal = Launcher.Font.Load(FontFamily2,FontSize2,FontWeight4)
	FontPP = Launcher.Font.Load(FontFamily,FontSize3,FontWeight2)
	FontShot = Launcher.Font.Load(FontFamily,FontSizeShots,FontWeight2)
	ClockSprite = Launcher.Sprite.Load("launcher/media/textures/Sportsnet/Clock.png")		
	ClockSpriteGoalFULL = Launcher.Sprite.Load("launcher/media/textures/Sportsnet/Anim/Anim121.png")		
	ClockSpriteGoalStatic = Launcher.Sprite.Load("launcher/media/textures/Sportsnet/Anim/Anim121.png")		
	
    -- Since the clock will never move, we tell the coordinate for top left with 20 padding from top
    ClockX = Launcher.Screen.Width()/2 - ClockWidth/2
    ClockY = 60
	
    -- Let's retrieve the home and away team abbreviations for loading the pogs and store them in HomeAbbreviation and AwayAbbreviation global variables
    HomeAbbreviation = Launcher.Game.HomeNameAbbreviation()
    AwayAbbreviation = Launcher.Game.AwayNameAbbreviation()
    
    -- Now that we have the abbreviations, we can load the pog images as sprites and store the sprite handles in HomePog and AwayPog
    HomePog = Launcher.Sprite.Load("launcher/media/textures/CBC_SN_Shared/pogs/"..HomeAbbreviation..".png")  
    HomeGoalPog = Launcher.Sprite.Load("launcher/media/textures/CBC_SN_Shared/goalpogs/"..HomeAbbreviation..".png")  
    HomeGoalColour = Launcher.Sprite.Load("launcher/media/textures/CBC_SN_Shared/goalcolour/"..HomeAbbreviation..".png")  
	AwayPog = Launcher.Sprite.Load("launcher/media/textures/CBC_SN_Shared/pogs/AWAY/"..AwayAbbreviation..".png")	
	AwayGoalPog = Launcher.Sprite.Load("launcher/media/textures/CBC_SN_Shared/goalpogs/AWAY/"..AwayAbbreviation..".png")	
	AwayGoalColour = Launcher.Sprite.Load("launcher/media/textures/CBC_SN_Shared/goalcolour/"..AwayAbbreviation..".png")	

	GoalPog = Launcher.Sprite.Load("launcher/media/textures/CBC_SN_Shared/goalpogs/"..HomeAbbreviation..".png")
	GoalPogX = 1
	GoalColour = Launcher.Sprite.Load("launcher/media/textures/CBC_SN_Shared/goalcolour/"..HomeAbbreviation..".png")
	GoalColourX = 1

end

function DeviceCreatedCallback()
	LoadAssets()
end


function ReloadedCallback()
	LoadAssets()
end

function PlayStoppedCallback(Reason)
	ClockSpriteGoal = ""
	GoalTimer = GoalTimer_Max+1
	GoalTeam = 0
	GoalPlayer = Launcher.Game.LastGoalPlayer()
	GoalPlayerFirstName = Launcher.Player.FirstName(GoalPlayer)
	GoalPlayerLastName = Launcher.Player.LastName(GoalPlayer)
	GoalPlayerInitial = GoalPlayerFirstName:sub(1,1)
	GoalPlayerGoals = Launcher.Player.Goals(GoalPlayer)
	if Reason == LauncherPlayStoppedGoalHome then
		GoalTimer = 0
		GoalTeam = 1
		GoalPog = HomeGoalPog
		GoalPogX = HomeGoalPogX
		GoalColour = HomeGoalColour
		GoalColourX = HomeGoalColourX
	elseif Reason == LauncherPlayStoppedGoalAway then
		GoalTimer = 0
		GoalTeam = 2
		GoalPog = AwayGoalPog
		GoalPogX = AwayGoalPogX
		GoalColour = AwayGoalColour
		GoalColourX = AwayGoalColourX
	end
end


function RenderCallback()
    local X, Y
    -- if Launcher.Game.Paused() and not Launcher.Game.InReplay() then
        -- X = Launcher.Screen.Width()*0.5-Launcher.Sprite.Width(PauseSprite)*0.5
        -- Y = Launcher.Screen.Height()*0.5-Launcher.Sprite.Height(PauseSprite)*0.5
        -- Launcher.Sprite.Draw(PauseSprite,X,Y)
        -- return
    -- end
	if (Launcher.Game.InCutscene() or Launcher.Game.IsShootout() or Launcher.Game.InReplay()) and GoalTimer == GoalTimer_Max+1 then
		return
	end
	
	

	Launcher.Sprite.Draw(SurfaceSprite,0,0)
	
    
end

-- The following callback function is called every frame for doing our own drawing
function TickCallback()
    local HomeGoals, AwayGoals, Period, Minutes, Seconds, PowerPlayTime, Time, PenaltyTeam, PenaltyPendingTeam, PowerPlayTeam, HomeShots, AwayShots, ppOffset

	Launcher.Screen.SetRenderTarget(1,SurfaceSprite)


	if GoalTimer < GoalTimer_Max then
		Launcher.Sprite.Draw(GoalPog, ClockX+GoalPogX, ClockY)
		Launcher.Sprite.Draw(GoalColour, ClockX+GoalColourX, ClockY)
		--Make sure Clock Sprite is Loaded
		if GoalTimer < 91 then
			if GoalTimer < 10 then
			ClockSpriteGoalFULL = Launcher.Sprite.Load("launcher/media/textures/Sportsnet/Anim/Anim00"..GoalTimer..".png")
			else
			ClockSpriteGoalFULL = Launcher.Sprite.Load("launcher/media/textures/Sportsnet/Anim/Anim0"..GoalTimer..".png")	
			end
		elseif GoalTimer > 90 then
		ClockSpriteGoalFULL = ClockSpriteGoalStatic
		end
		-- Script breaks here on Fourth Goal
		if GoalTeam == 1 then
			if ClockSpriteGoal == "" or ClockSpriteGoal == nil then
				Launcher.Sprite.Clip(ClockSpriteGoalFULL,0,0,ClockWidth,ClockHeight)
				Launcher.Sprite.Draw(ClockSpriteGoalFULL, ClockX, ClockY)
			elseif not (ClockSpriteGoal == "" or ClockSpriteGoal == nil) then
				Launcher.Sprite.Draw(ClockSpriteGoalFULL, ClockX, ClockY)
			end
		elseif GoalTeam == 2 then
			if ClockSpriteGoal == "" or ClockSpriteGoal == nil then
				Launcher.Sprite.Clip(ClockSpriteGoalFULL,0,ClockHeight,ClockWidth,ClockHeight)
				Launcher.Sprite.Draw(ClockSpriteGoalFULL, ClockX, ClockY)
			elseif not (ClockSpriteGoal == "" or ClockSpriteGoal == nil) then
				Launcher.Sprite.Draw(ClockSpriteGoalFULL, ClockX, ClockY)
			end
		end
--        Launcher.Font.DrawText(ClockFontPP,GoalPlayerInitial..". "..GoalPlayerLastName.." ("..GoalPlayerGoals..")",ClockX + 180*.75,ClockY + 49,FontColor1)
		GoalTimer = GoalTimer + 1
		return
	elseif GoalTimer == GoalTimer_Max then
		GoalTimer = GoalTimer_Max+1
	end

	
	if Launcher.Game.InCutscene() or Launcher.Game.IsShootout() or Launcher.Game.InReplay() then
		return
	end

	if Launcher.Screen.BeginScene() then
	Launcher.Screen.Clear(0)
    -- First, let's make sure we're not in a cutscene or the pause menu
        
        -- Now that our background has been drawn, we can draw the home and away pogs on top of it
        Launcher.Sprite.Draw(HomePog, ClockX + 415, ClockY)
        Launcher.Sprite.Draw(AwayPog, ClockX + 80, ClockY)
		
		Launcher.Sprite.Clip(ClockSprite,0,0,ClockWidth,ClockHeight)
		Launcher.Sprite.Draw(ClockSprite, ClockX, ClockY)

        -- Now it's time to draw some basic game information
        -- First, let's store some of the information into local variables
        -- A local variable only exists in the current function. A global variable can be accessed from all functions
        -- By default, all variables are global. To make them local, simply add "local" before the declaration
        -- The next three lines retrieves the goals for each team and the current period
		HomeGoals = Launcher.Stats.HomeGoals()
        AwayGoals = Launcher.Stats.AwayGoals()
		--CP SHOT COUNT START--
		HomeShots = Launcher.Stats.HomeShots()
		AwayShots = Launcher.Stats.AwayShots()
		--CP SHOT COUNT END--
        Period = Launcher.Game.Period()
		PenaltyTeam = Launcher.Game.PenaltyPendingTeam()

        
        -- Let's create a nice string representation of the period
        if Period == 1 then
            PeriodStr = "1st"
        elseif Period == 2 then
            PeriodStr = "2nd"
        elseif Period == 3 then
            PeriodStr = "3rd"
        elseif Period == 4 then
            PeriodStr = "OT"
		elseif Period > 4 then
			PeriodStr = ""..(Period-3).."OT"
        end
        
        -- The next line retrieves the game time in seconds
        local Time = Launcher.Game.Time()
        
        -- Lets convert these seconds into minutes and seconds
        -- For minutes, simply divide by 60 and round down
        local Minutes = math.floor(Time/60)
        if Minutes < 10 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            -- Minutes = "0"..Minutes
        end
        
        -- % is modulo. Modulo means the remainder of a division
        -- So in our case, the remainder of dividing the time by 60 would be the seconds component
        local Seconds = Time % 60
        if Seconds < 10 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            Seconds = "0"..Seconds
        end
        
-- Icing/Offside is pending
		if Launcher.Game.Warning() == 1 then
	Launcher.Sprite.Clip(ClockSprite,612,96,156,32)
    Launcher.Sprite.Draw(ClockSprite, ClockX + 612, ClockY + 64)
		elseif Launcher.Game.Warning() == 2 then
    Launcher.Sprite.Clip(ClockSprite,612,64,156,32)
    Launcher.Sprite.Draw(ClockSprite, ClockX + 612, ClockY + 64)
   end
   
-- Penalty is pending
		if Launcher.Game.PenaltyPending() then
		if Launcher.Game.PenaltyPendingTeam() == 1 then
	Launcher.Sprite.Clip(ClockSprite,78,64,196,32)
	Launcher.Sprite.Draw(ClockSprite, ClockX + AwayX, ClockY + 64)
		elseif Launcher.Game.PenaltyPendingTeam() == 0 then
	Launcher.Sprite.Clip(ClockSprite,78,64,196,32)
	Launcher.Sprite.Draw(ClockSprite, ClockX + HomeX, ClockY + 64)
	end
end

-- POWERPLAY
	if Launcher.Game.PowerplayTime() > 0 then
		PowerPlayTeam = Launcher.Game.PowerplayTeam()
			if PowerPlayTeam == 1 then
			Launcher.Sprite.Clip(ClockSprite,78,96,196,32)
			Launcher.Sprite.Draw(ClockSprite, ClockX + HomeX, ClockY + 64)
			else
			Launcher.Sprite.Clip(ClockSprite,78,96,196,32)
			Launcher.Sprite.Draw(ClockSprite, ClockX + AwayX, ClockY + 64)
			end	
  -- The next line retrieves the PP time in seconds
        local pptime = Launcher.Game.PowerplayTime()
        
        -- Lets convert these seconds into minutes and seconds
        -- For minutes, simply divide by 60 and round down
        ppMinutes = math.floor(pptime/60)
        if ppMinutes > 1 or ppMinutes == 0 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            ppOffset = 143.1494
		else
			ppOffset = 145.4473
        end
        
        -- % is modulo. Modulo means the remainder of a division
        -- So in our case, the remainder of dividing the time by 60 would be the seconds component
        ppSeconds = pptime % 60
        if ppSeconds < 10 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            ppSeconds = "0"..ppSeconds
        end 
		
		if PowerPlayTeam == 1 then
		Launcher.Font.DrawText(FontPP," "..ppMinutes..":"..ppSeconds,ClockX + HomeX + ppOffset,ClockY + 71,FontColor1)
		else
		Launcher.Font.DrawText(FontPP," "..ppMinutes..":"..ppSeconds,ClockX + AwayX + ppOffset,ClockY + 71,FontColor1)
	end
end

-- Now we can render all of the information to the screen using the DrawText function.
		if HomeGoals == 0 then
			Launcher.Font.DrawText(FontGoal,HomeGoals,ClockX + HomeGoalsX,ClockY + Goals_Y,FontColor2)
		elseif HomeGoals == 1 then
			Launcher.Font.DrawText(FontGoal,HomeGoals,ClockX + HomeGoalsX_1,ClockY + Goals_Y,FontColor2)
		else
			Launcher.Font.DrawText(FontGoal,HomeGoals,ClockX + HomeGoalsX_N,ClockY + Goals_Y,FontColor2)
		end
		if AwayGoals == 0 then
			Launcher.Font.DrawText(FontGoal,AwayGoals,ClockX + AwayGoalsX,ClockY + Goals_Y,FontColor2)
		elseif AwayGoals == 1 then
			Launcher.Font.DrawText(FontGoal,AwayGoals,ClockX + AwayGoalsX_1,ClockY + Goals_Y,FontColor2)
		else
			Launcher.Font.DrawText(FontGoal,AwayGoals,ClockX + AwayGoalsX_N,ClockY + 8,FontColor2)
		end
		if HomeShots == 0 then
			Launcher.Font.DrawText(FontShot,HomeShots,ClockX + HomeX + ShotsHX,ClockY + Shots_Y,FontColor2)
		elseif HomeShots == 1 then
			Launcher.Font.DrawText(FontShot,HomeShots,ClockX + HomeX + ShotsHX_1,ClockY + Shots_Y,FontColor2)
		elseif HomeShots < 10 and HomeShots > 1 then
			Launcher.Font.DrawText(FontShot,HomeShots,ClockX + HomeX + ShotsHX_N,ClockY + Shots_Y,FontColor2)
		elseif HomeShots < 20 and HomeShots > 9 then
			Launcher.Font.DrawText(FontShot,HomeShots,ClockX + HomeX + ShotsHX_1N,ClockY + Shots_Y,FontColor2)
		else
			Launcher.Font.DrawText(FontShot,HomeShots,ClockX + HomeX + ShotsHX_NN,ClockY + Shots_Y,FontColor2)
		end
		if AwayShots == 0 then
			Launcher.Font.DrawText(FontShot,AwayShots,ClockX + AwayX + ShotsAX,ClockY + Shots_Y,FontColor2)
		elseif AwayShots == 1 then
			Launcher.Font.DrawText(FontShot,AwayShots,ClockX + AwayX + ShotsAX_1,ClockY + Shots_Y,FontColor2)
		elseif AwayShots < 10 and AwayShots > 1 then
			Launcher.Font.DrawText(FontShot,AwayShots,ClockX + AwayX + ShotsAX_N,ClockY + Shots_Y,FontColor2)
		elseif AwayShots < 20 and AwayShots > 9 then
			Launcher.Font.DrawText(FontShot,AwayShots,ClockX + AwayX + ShotsAX_1N,ClockY + Shots_Y,FontColor2)
		else
			Launcher.Font.DrawText(FontShot,AwayShots,ClockX + AwayX + ShotsAX_NN,ClockY + Shots_Y,FontColor2)
		end
        if Period == 1 then
			Launcher.Font.DrawText(FontTime,PeriodStr,ClockX + Period_X_1,ClockY + Period_Y,FontColor1)
		elseif Period > 1 and Period < 4 then
			Launcher.Font.DrawText(FontTime,PeriodStr,ClockX + Period_X,ClockY + Period_Y,FontColor1)
		elseif Period == 4 then
			Launcher.Font.DrawText(FontTime,PeriodStr,ClockX + Period_X_OT,ClockY + Period_Y,FontColor1)
		elseif Period > 4 then
			Launcher.Font.DrawText(FontTime_NOT,PeriodStr,ClockX + Period_X_OT,ClockY + Period_Y,FontColor1)
		end
		if Minutes == 20 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            -- Minutes = "0"..Minutes
			Launcher.Font.DrawText(FontTime,Minutes..":"..Seconds,ClockX + Time_X,ClockY + Period_Y,FontColor1)
		elseif Minutes < 20 and Minutes > 9 then
			Launcher.Font.DrawText(FontTime,Minutes..":"..Seconds,ClockX + Time_X_1N,ClockY + Period_Y,FontColor1)
		elseif Minutes < 10 and not (Minutes == 1) then
			Launcher.Font.DrawText(FontTime,Minutes..":"..Seconds,ClockX + Time_X_N,ClockY + Period_Y,FontColor1)
		elseif Minutes == 1 then
			Launcher.Font.DrawText(FontTime,Minutes..":"..Seconds,ClockX + Time_X_1,ClockY + Period_Y,FontColor1)
        end
     Launcher.Screen.EndScene()		
	end
	Launcher.Screen.ResetRenderTarget()
end

-- ************ CALLBACK DEFINITIONS ************ 

-- Callbacks are functions we define that will be called if an in-game event happens
-- There are many kinds of callbacks, but for our case we only need Render and DeviceCreated
-- Render is called every time a frame is rendered
-- DeviceCreated is called right after creating the D3D device, which is right before the in-game loading screen
-- The DeviceCreated callback function is where we load our assets
-- The Render callback function is where we draw everything

Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("RenderBackground",RenderCallback)
Launcher.Callback.Register("Tick",TickCallback)
Launcher.Callback.Register("PlayStopped",PlayStoppedCallback)
Launcher.Callback.Register("Reloaded",ReloadedCallback)

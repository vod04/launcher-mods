
-- Jump down to see the callback definitions

-- ************ CALLBACK FUNCTIONS ************ 

-- The following callback function is called as soon as the D3D device is created, right before the game loading screen.
-- It is only called once, so this is where we load things like fonts, textures and sprites
function CutsceneStartedCallback(CutsceneID) 
Cutscenetype = CutsceneID
 -- 
  if Launcher.Game.InCutscene() then
if Cutscenetype == 27 or Cutscenetype == 30 or Cutscenetype == 32 or Cutscenetype == 34 or Cutscenetype == 35 or Cutscenetype == 44 then
 Launcher.Texture.Inject(LightCrowd, "CRWD")	
elseif Cutscenetype == 9 then
  Launcher.Texture.Inject(BlackCrowd, "CRWD")
 end

end
end
function DeviceCreatedCallback()
    
    -- Before the game start it loads The boards from hometeam folder
HomeAbbreviation = Launcher.Game.HomeNameAbbreviation()
Foam = Launcher.Texture.Load("launcher/media/textures/FOAM.png")
Net = Launcher.Texture.Load("launcher/media/textures/net.png")
Visor = Launcher.Texture.Load("launcher/media/textures/VISR.png")
BlackCrowd = Launcher.Texture.Load("launcher/media/textures/VIDA/"..HomeAbbreviation.."/crowd_B.png")
DarkCrowd = Launcher.Texture.Load("launcher/media/textures/VIDA/"..HomeAbbreviation.."/crowd_D.png")
LightCrowd = Launcher.Texture.Load("launcher/media/textures/VIDA/"..HomeAbbreviation.."/crowd_L.png")
Icequal = Launcher.Texture.Load("launcher/media/textures/VIDA/"..HomeAbbreviation.."/snow.png")
Icesurface = Launcher.Texture.Load("launcher/media/textures/VIDA/"..HomeAbbreviation.."/ice.png")
   Launcher.Texture.Inject(DarkCrowd, "CRWD")
   Launcher.Texture.Inject(Foam, "FOAM")
    Launcher.Texture.Inject(Net, "GLS1")
      Launcher.Texture.Inject(Visor, "VISR")
     Launcher.Texture.Inject(Icequal, "SNOW")
      Launcher.Texture.Inject(Scratch, "SCRH")
      Launcher.Texture.Inject(Icesurface, "L256")
end


function RenderCallback()
if not Launcher.Game.InCutscene() then
Launcher.Texture.Inject(DarkCrowd, "CRWD")
end
end
-- ************ CALLBACK DEFINITIONS ************ 



Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("Render",RenderCallback)
Launcher.Callback.Register("CutsceneStarted",CutsceneStartedCallback)


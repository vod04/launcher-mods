
Padding = 6
FontFamily = "Euro Caps"
FontColor = 0xFFD6A430
FontColor2 = 0xeeffffff
FontSize = 85
FontWeight = 1200
FontWeight2 = 1800

Render = false
Text = ""
function DeviceCreatedCallback()
	BGSprite = Launcher.Sprite.Load("launcher\\media\\textures\\FOXTrax.png")	
	ShotFont = Launcher.Font.Load(FontFamily,FontSize, FontWeight, false, false, false, true)
	mphFont = Launcher.Font.Load(FontFamily,40, FontWeight2)
	if BGSprite ~= nil then
		Launcher.Callback.Register("Render",RenderCallback)
	end
end
function Timeout()
	Render = false
end
function ShotCallback()
if tonumber (string.sub(Launcher.Game.ShotSpeed(),1,2))>70 then
	Render = true
	Text = string.sub(Launcher.Game.ShotSpeed(),1,2)
	Launcher.Timer.SetTimeout(3000,Timeout)
end
end
function RenderCallback()
	local X, Y, Width, Height
	if Render  then
		X = Launcher.Screen.Width() - 284
		Y = Launcher.Screen.Height() - 127
		Launcher.Sprite.Draw(BGSprite, X - 40, Y - 68, 0, 0xFFFFFFFF)
		Launcher.Font.DrawText(ShotFont, Text, X + 5, Y - 15, FontColor)
		Launcher.Font.DrawText(mphFont, "MPH", X + 95, Y + 18, FontColor2)
	end
end

Launcher.Callback.Register("ShotHome",ShotCallback)
Launcher.Callback.Register("ShotAway",ShotCallback)
Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)

-- Jump down to see the callback definitions

-- ************ CALLBACK FUNCTIONS ************ 

-- The following callback function is called as soon as the D3D device is created, right before the game loading screen.
-- It is only called once, so this is where we load things like fonts, textures and sprites
function CutsceneStartedCallback(CutsceneID) 
Cutscenetype = CutsceneID
  if Launcher.Game.InCutscene() then
if Cutscenetype == 42 or Cutscenetype == 38 or Cutscenetype == 43 or Cutscenetype == 41 then
 Launcher.Texture.Inject(GoalVIDA, "VIDA")	
elseif Cutscenetype == 9 then
 Launcher.Texture.Inject(FOVIDA, "VIDA")	
 end

end
end
function DeviceCreatedCallback()
    
    -- Before the game start it loads one of the 4 different video for the jumbotron
HomeAbbreviation = Launcher.Game.HomeNameAbbreviation()
AwayAbbreviation = Launcher.Game.AwayNameAbbreviation()
Number     = math.random(1, 5)
RandVIDA = Launcher.Texture.Load("launcher/media/textures/VIDA/"..HomeAbbreviation.."/vida"..Number..".png")
LOCALEMAP = Launcher.Texture.Load("launcher/media/textures/VIDA/"..HomeAbbreviation.."/emap.png")
LOCALSPO3 = Launcher.Texture.Load("launcher/media/textures/VIDA/"..HomeAbbreviation.."/spo3.png")
FOVIDA = Launcher.Texture.Load("launcher/media/textures/VIDA/"..HomeAbbreviation.."/vidaFO.png")
GoalVIDA = Launcher.Texture.Load("launcher/media/textures/VIDA/"..HomeAbbreviation.."/vidaGoal.png")
HomeTM = Launcher.Texture.Load("launcher/media/textures/VIDA/"..HomeAbbreviation.."/TMAW.png")
AwayTM = Launcher.Texture.Load("launcher/media/textures/VIDA/"..AwayAbbreviation.."/TMAW.png")
Launcher.Texture.Inject(RandVIDA, "VIDA")
Launcher.Texture.Inject(HomeTM, "TMHM")	
Launcher.Texture.Inject(AwayTM, "TMAW")	
 Launcher.Texture.Inject(LOCALEMAP, "EMAP")
  Launcher.Texture.Inject(LOCALSPO3, "SPO3")
  
   
end

function RenderCallback()

if not Launcher.Game.InCutscene() then
Launcher.Texture.Inject(RandVIDA, "VIDA")
end
end
-- ************ CALLBACK DEFINITIONS ************ 



Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("Render",RenderCallback)
Launcher.Callback.Register("CutsceneStarted",CutsceneStartedCallback)



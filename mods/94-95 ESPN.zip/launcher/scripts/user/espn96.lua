-- Lines that start with "--" are comments. They are not executed 
-- Let's define some basic global variables to make it easier to adjust things

FontSize = 40
FontSize1 = 25
FontSize2 = 30
FontSize3 = 20
FontFamily = "Kenyan Coffee Rg"
FontColor1 = 0xee000000
FontColor2 = 0xeeffffff
FontColor3 = 0xeeecc10d
HomeGoalsX = 132
AwayGoalsX = 132
TimeX = 170
--position of the Fox cutscenes Overlay
    ClockXCS = Launcher.Screen.Width() - 600
    ClockYCS = Launcher.Screen.Height() - 260
    HomeGoalsXCS = 548
    AwayGoalsXCS = 548
--Position for the faceoff overlay
 CenterscreenX = Launcher.Screen.Width()/2
 CenterscreenY = Launcher.Screen.Height()/2
PauseMenuX = math.floor(Launcher.Screen.Width()*0.74)

-- Next a list of some cutscenestypes
--9 Player positioning Before puck drop
--44 Game intro
--45 Start of period
--34 End of period
--35 End of third period with Equality before OT
--32 End of game Includes OT goal
--30 three stars
--27 Timout
--16 Goalie Change
--13 Start of fight
--14 Start of fight Goalies
--58 End of fight Goalies
--92 End of Fight Draw
--93 End of Fight H win
--94 End of Fight A Win
--79 Penalty to player
--37 Empty net goal
--38 Goal HOME
--39 first Goal (team outscored like 8-0*) Home ?
--43 Goal AWAY
--42 Goal POWERPLAY
--40 Own goal pissed off coach (Empty net delayed Penalty ?))
--41 Own goal
--77 Hat trick
--78 first NHL goal or ShootoutGoal or Career Milestone
--22 Player skating or coach talking
--20 Player skating
--21 Player skating with ea stats 
--66 player being hard checked (and not happy)
--67 Coach disgusted player being checked
--24 Bench (caoch clapping) or player skating
--17 Goalie in front of net
--25 puck on net
--57 Goalie
--62 Goalie stopped shootout (Home ?)
--63 Goalie (has made a stop) or super stop Away
--64 Goalie super save Home



LastPlayStoppedReason = 0
Cutscenetype = 0
function LoadAssets()
-- Load all sprites, fonts etc here
end

function ReloadedCallback()
LoadAssets()
end
--OFFSIDES and ICINGS
function Launcher.Game.PowerplayTime()
   return Launcher.Mem.Short(0x7BD8B0)
end
function Launcher.Game.Warning()
   return Launcher.Mem.Byte(0x79BB05)
end
function CutsceneStartedCallback(CutsceneID) 
Cutscenetype = CutsceneID
end


-- ************ CALLBACK FUNCTIONS ************ 

-- The following callback function is called as soon as the D3D device is created, right before the game loading screen.
-- It is only called once, so this is where we load things like fonts, textures and sprites

function DeviceCreatedCallback()
    
    -- First, let's load the background image of our gameclock. The image dimensions should be pow2. 
    -- 2D images drawn to the screen are called "sprites". Sprites can be scaled, rotated, faded etc.
    -- After the sprite is loaded, the handle is stored in the BGSprite variable
    BGSprite = Launcher.Sprite.Load("launcher/media/textures/espn96/BGSprite.png")	
    --penaltysprite = Launcher.Sprite.Load("launcher/media/textures/Game Clocks/penalty.png") 
    --penaltymarker = Launcher.Sprite.Load("launcher/media/textures/Game Clocks/penaltydot.png")
	--offsidesprite = Launcher.Sprite.Load("launcher/media/textures/Game Clocks/offside.png")    
	--icingsprite = Launcher.Sprite.Load("launcher/media/textures/Game Clocks/icing.png")    
	--powerplaytimesprite = Launcher.Sprite.Load("launcher/media/textures/Game Clocks/powerplaytime.png")
	--powerplayframesprite = Launcher.Sprite.Load("launcher/media/textures/Game Clocks/powerplayframe.png")
LoadAssets()

    -- Next, let's load a font that we can use later to draw text
    -- The font handle will then be stored in the global variable, ClockFont
    teamfont = Launcher.Font.Load("Euro Caps",40,900, false, false, false, true)
    timefont = Launcher.Font.Load(FontFamily,45,0,false, false, false, true)
        playerintrofont = Launcher.Font.Load(FontFamily,38,0,false, false, false, true)
     timefont2 = Launcher.Font.Load(FontFamily,75,100,false, false, false, true)
   periodfont = Launcher.Font.Load(FontFamily,25,100,false, false, false, true)
     ClockFont = Launcher.Font.Load(FontFamily,FontSize)
  ClockFont2 = Launcher.Font.Load(FontFamily,FontSize2)
    ShotFont = Launcher.Font.Load(FontFamily,50,100,false, false, false, true)
	powerplayfont = Launcher.Font.Load(FontFamily,38,900,false, false, false, true)
CommentFont = Launcher.Font.Load(FontFamily,30,100,false, false, false, true)
PlayerFont = Launcher.Font.Load(FontFamily,45,100,false, false, false, true)
    
    -- Since the clock will never move, we can calculate the coordinates now to center it horizontally on the screen instead of doing it every frame
    ClockX = 30
    ClockY = 30
    
    -- Let's retrieve the home and away team abbreviations for loading the pogs and store them in HomeAbbreviation and AwayAbbreviation global variables
    HomeAbbreviation = Launcher.Game.HomeNameAbbreviation()
    AwayAbbreviation = Launcher.Game.AwayNameAbbreviation()
    
    -- Now that we have the abbreviations, we can load the pog images as sprites and store the sprite handles in HomePog and AwayPog
    HomePogCS = Launcher.Sprite.Load("launcher/media/textures/espn96/PogsCS/"..HomeAbbreviation..".png")
    AwayPogCS = Launcher.Sprite.Load("launcher/media/textures/espn96/PogsCS/"..AwayAbbreviation..".png")
    EspnNHN = Launcher.Sprite.Load("launcher/media/textures/espn96/espnNHN.png")
   -- Arena = Launcher.Sprite.Load("launcher/media/textures/Game Clocks/loc/"..HomeAbbreviation..".png")

--powerplaytime = Launcher.Sprite.Load("launcher/media/textures/Game Clocks/powerplaytime.png")

end


-- The following callback function is called every frame for doing our own drawing

function RenderCallback()
   -- Now it's time to draw some basic game information
        -- First, let's store some of the information into local variables
        -- A local variable only exists in the current function. A global variable can be accessed from all functions
        -- By default, all variables are global. To make them local, simply add "local" before the declaration
        -- The next three lines retrieves the goals for each team and the current period
        local HomeGoals = Launcher.Stats.HomeGoals()
        local AwayGoals = Launcher.Stats.AwayGoals()
        local Period = Launcher.Game.Period()
        local HomeShots = Launcher.Stats.HomeShots()
        local AwayShots = Launcher.Stats.AwayShots()
        -- infos on player with puck
PuckPlayer = Launcher.Game.PlayerWithPuck ()
PuckPlayerLName = Launcher.Player.LastName (PuckPlayer)
PuckPlayerFName = Launcher.Player.FirstName (PuckPlayer)
-- infos on Last Scorer
ScorePlayer = Launcher.Game.LastGoalPlayer ()
SCORFname = Launcher.Player.FirstName (ScorePlayer)
SCORFname = string.lower (SCORFname)
SCORFname = SCORFname:gsub("^%l", string.upper)
SCORLname = Launcher.Player.LastName (ScorePlayer)
SCORLname = string.lower (SCORLname)
SCORLname = SCORLname:gsub("^%l", string.upper)
ScorePlayerName = SCORFname.." "..SCORLname
ScorePlayerTeam = Launcher.Game.LastGoalTeam ()
HomePrecision = math.floor(Launcher.Stats.HomePasses ()/Launcher.Stats.HomePassAttempts ()*100)
AwayPrecision = math.floor(Launcher.Stats.AwayPasses ()/Launcher.Stats.AwayPassAttempts ()*100)

Pen = {}
Pen [0] = "Game misconduct"
Pen [03] = " "
Pen [21] = "Penalty"
Pen [22] = "Slashing"
Pen [23] = "Roughing"
Pen [24] = "Cross-checking"
Pen [25] = "Hooking"
Pen [26] = "Tripping"
Pen [27] = "Interference"
Pen [28] = "Penalty"
Pen [29] = "Elbowing"
Pen [30] = "Penalty"
Pen [31] = "Penalty"
Pen [32] = "Holding"
Pen [33] = "Obstruction"
Pen [34] = "Obstruction-Hooking"
Pen [35] = "Obstruction-Boarding"
Pen [36] = "Obstruction-Tripping"
Pen [37] = "Penalty"


	--local penaltyteam = Launcher.Game.PenaltyPendingTeam()
  
   if Period == 1 then
            Period = "1st"
            Intermission =" 1st intermission"
        elseif Period == 2 then
            Period = "2nd"
             Intermission =" 2nd intermission"
        elseif Period == 3 then
            Period = "3rd"
             Intermission =" Going to Overtime"
        elseif Period > 3 then
            Period = "OT"
             Intermission =" OT intermission"
        end
        
        -- The next line retrieves the game time in seconds
        local Time = Launcher.Game.Time()
        
        -- Lets convert these seconds into minutes and seconds
        -- For minutes, simply divide by 60 and round down
        local Minutes = math.floor(Time/60)
        if Minutes < 10 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            Minutes = "0"..Minutes
        end
        -- % is modulo. Modulo means the remainder of a division
        -- So in our case, the remainder of dividing the time by 60 would be the seconds component
        local Seconds = Time % 60
        if Seconds < 10 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            Seconds = "0"..Seconds
        end  
        -- elapsedtime 
         -- The next line retrieves the game time in seconds
        local Timee = 1200 - Launcher.Game.Time()
        
        -- Lets convert these seconds into minutes and seconds
        -- For minutes, simply divide by 60 and round down
        local Minutese = math.floor(Timee/60)
        if Minutese < 10 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            Minutese = "0"..Minutese
        end
        
        -- % is modulo. Modulo means the remainder of a division
        -- So in our case, the remainder of dividing the time by 60 would be the seconds component
        local Secondse = Timee % 60
        if Secondse < 10 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            Secondse = "0"..Secondse
        end  
--cutscene



if Launcher.Game.InCutscene() then
 Launcher.Override.DisableOverlay()
--Launcher.Font.DrawText(teamfont,"CUTSCENE ID :"..Cutscenetype,ClockX + 500,ClockY +300,FontColor2)


-- Video before Puckdroop
--Display list of players dressed
if  Cutscenetype == 44 then

   Launcher.Sprite.Draw(EspnNHN, CenterscreenX -240 ,0)
 Launcher.Sprite.Clip(AwayPogCS,0,0,512,96)
Launcher.Sprite.Draw(AwayPogCS, CenterscreenX +353, ClockY +100) 
Launcher.Sprite.Clip(HomePogCS,0,0,512,96)
Launcher.Sprite.Draw(HomePogCS, CenterscreenX -706, ClockY +100)
--Launcher.Sprite.Clip(BGSprite,0,421,512,91)
     -- Launcher.Sprite.Draw(BGSprite, CenterscreenX -737, ClockY +50)
--Launcher.Sprite.Clip(BGSprite,0,330,512,91)
      --Launcher.Sprite.Draw(BGSprite, CenterscreenX +263, ClockY +50)
      

 for i = 0, 17 do
PLAFname = Launcher.Player.FirstName (i)
PLAFname = string.lower (PLAFname)
PLAFname = PLAFname:gsub("^%l", string.upper)
PLALname = Launcher.Player.LastName (i)
PLALname = string.lower (PLALname)
PLALname = PLALname:gsub("^%l", string.upper)
PLAName = PLAFname.." "..PLALname

   Launcher.Sprite.Clip(HomePogCS,0,184,512,40)
   Launcher.Sprite.Draw(HomePogCS, CenterscreenX -827, ClockY +205+40*i)
  Launcher.Font.DrawText(playerintrofont,PLAName, CenterscreenX -670 ,ClockY +205+40*i,FontColor2)
 
end
for i = 18, 19 do
   
   PLAFname = Launcher.Player.FirstName (i)
PLAFname = string.lower (PLAFname)
PLAFname = PLAFname:gsub("^%l", string.upper)
PLALname = Launcher.Player.LastName (i)
PLALname = string.lower (PLALname)
PLALname = PLALname:gsub("^%l", string.upper)
PLAName = PLAFname.." "..PLALname

Launcher.Sprite.Clip(HomePogCS,0,184,512,40)
   Launcher.Sprite.Draw(HomePogCS, CenterscreenX -827, ClockY +215+40*i)
  Launcher.Font.DrawText(playerintrofont,PLAName, CenterscreenX -670 ,ClockY +215+40*i,FontColor3)

end

for k = 20, 37 do
  
      PLAFname = Launcher.Player.FirstName (k)
PLAFname = string.lower (PLAFname)
PLAFname = PLAFname:gsub("^%l", string.upper)
PLALname = Launcher.Player.LastName (k)
PLALname = string.lower (PLALname)
PLALname = PLALname:gsub("^%l", string.upper)
PLAName = PLAFname.." "..PLALname
  Launcher.Sprite.Clip(AwayPogCS,0,184,512,40)
   Launcher.Sprite.Draw(AwayPogCS, CenterscreenX +232 ,ClockY +205+40*(k-20))
  Launcher.Font.DrawText(playerintrofont,PLAName, CenterscreenX +379 ,ClockY +205+40*(k-20),FontColor2)
end
for k = 38, 39 do
    
         PLAFname = Launcher.Player.FirstName (k)
PLAFname = string.lower (PLAFname)
PLAFname = PLAFname:gsub("^%l", string.upper)
PLALname = Launcher.Player.LastName (k)
PLALname = string.lower (PLALname)
PLALname = PLALname:gsub("^%l", string.upper)
PLAName = PLAFname.." "..PLALname
Launcher.Sprite.Clip(AwayPogCS,0,184,512,40)
   Launcher.Sprite.Draw(AwayPogCS, CenterscreenX +232 ,ClockY +215+40*(k-20))
  Launcher.Font.DrawText(playerintrofont,PLAName, CenterscreenX +379 ,ClockY +215+40*(k-20),FontColor3)

end

  
end

-- Cutscene is player skating or period start/end cutscene
-- Draw the big bottom right score
if  Cutscenetype == 32 or Cutscenetype == 35  or Cutscenetype == 45 or Cutscenetype == 34 or Cutscenetype == 20 or Cutscenetype == 22 then



    --draw the images
    Launcher.Sprite.Clip(AwayPogCS,0,21,512,74)
        Launcher.Sprite.Draw(AwayPogCS, ClockXCS , ClockYCS + 39)
         Launcher.Sprite.Clip(HomePogCS,0,21,512,74)
        Launcher.Sprite.Draw(HomePogCS, ClockXCS , ClockYCS + 113)
	
	-- draw the text
  	Launcher.Sprite.Clip(BGSprite,0,0,512,39)
      Launcher.Sprite.Draw(BGSprite, ClockXCS, ClockYCS)
   Launcher.Sprite.Clip(BGSprite,400,39,87,148)     
Launcher.Sprite.Draw(BGSprite, ClockXCS+400, ClockYCS+39)

 	Launcher.Font.DrawText(timefont2,AwayGoals,ClockXCS + 425,ClockYCS+42,FontColor2)
        Launcher.Font.DrawText(timefont2,HomeGoals,ClockXCS + 425,ClockYCS + 116,FontColor2)
      
        if Cutscenetype == 45 or Cutscenetype == 32  or Cutscenetype == 34 or Cutscenetype == 35 then 
Launcher.Sprite.Clip(HomePogCS,0,96,512,48)
Launcher.Sprite.Draw(HomePogCS, ClockXCS, ClockYCS+187)
end
end
--cutscene player skating or coach
if Cutscenetype == 24   then
  if AwayShots < 10 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            AwayShots = " "..AwayShots
        end  
  if HomeShots < 10 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            HomeShots = " "..HomeShots
        end 
  Launcher.Sprite.Clip(AwayPogCS,0,21,512,74)
        Launcher.Sprite.Draw(AwayPogCS, ClockXCS , ClockYCS + 39)
         Launcher.Sprite.Clip(HomePogCS,0,21,512,74)
        Launcher.Sprite.Draw(HomePogCS, ClockXCS , ClockYCS + 113)
        
        Launcher.Sprite.Clip(BGSprite,155,187,332,48)    
  Launcher.Sprite.Draw(BGSprite, ClockXCS+155, ClockYCS+187)
       
        	Launcher.Sprite.Clip(BGSprite,0,0,512,39)
      Launcher.Sprite.Draw(BGSprite, ClockXCS, ClockYCS)
   Launcher.Sprite.Clip(BGSprite,400,39,87,148)     
Launcher.Sprite.Draw(BGSprite, ClockXCS+400, ClockYCS+39)
 Launcher.Font.DrawText(ClockFont2,"SHOTS ON GOAL",ClockXCS + 275,ClockYCS-2,FontColor3)
	Launcher.Font.DrawText(ShotFont,AwayShots,ClockXCS + 415,ClockYCS+45,FontColor2)
        Launcher.Font.DrawText(ShotFont,HomeShots,ClockXCS + 415,ClockYCS + 119,FontColor2)
     


  end 
  if Cutscenetype == 21 then
    Launcher.Sprite.Clip(AwayPogCS,0,21,512,74)
        Launcher.Sprite.Draw(AwayPogCS, ClockXCS , ClockYCS + 39)
         Launcher.Sprite.Clip(HomePogCS,0,21,512,74)
        Launcher.Sprite.Draw(HomePogCS, ClockXCS , ClockYCS + 113)
        
        Launcher.Sprite.Clip(BGSprite,155,187,332,48)    
  Launcher.Sprite.Draw(BGSprite, ClockXCS+155, ClockYCS+187)
       
        	Launcher.Sprite.Clip(BGSprite,0,0,512,39)
      Launcher.Sprite.Draw(BGSprite, ClockXCS, ClockYCS)
   Launcher.Sprite.Clip(BGSprite,400,39,87,148)     
Launcher.Sprite.Draw(BGSprite, ClockXCS+400, ClockYCS+39)
 Launcher.Font.DrawText(ClockFont2,"PASSING",ClockXCS + 285,ClockYCS-2,FontColor3)
	Launcher.Font.DrawText(timefont,AwayPrecision.."%",ClockXCS + 415,ClockYCS+45,FontColor2)
        Launcher.Font.DrawText(timefont,HomePrecision.."%",ClockXCS + 415,ClockYCS + 119,FontColor2)
    end



-- Cutscene is Starting the game first Puck drop
-- Draw a large espn presentation, the 2 opponents and Location
if Cutscenetype == 9 then
Launcher.Sprite.Clip(BGSprite,0,0,512,39)
Launcher.Sprite.Scale(BGSprite,1.5,1.5)
      Launcher.Sprite.Draw(BGSprite, CenterscreenX -256, CenterscreenY -83)
       Launcher.Sprite.Clip(AwayPogCS,0,0,512,96)
       Launcher.Sprite.Scale(AwayPogCS,1.5,1.5)
Launcher.Sprite.Draw(AwayPogCS, CenterscreenX -256, CenterscreenY-26)
 Launcher.Sprite.Clip(HomePogCS,0,0,512,144)
 Launcher.Sprite.Scale(HomePogCS,1.5,1.5)
Launcher.Sprite.Draw(HomePogCS, CenterscreenX -256, CenterscreenY+118)
Launcher.Sprite.Scale(BGSprite,1,1)
Launcher.Sprite.Scale(HomePogCS,1,1)
Launcher.Sprite.Scale(AwayPogCS,1,1)
end
-- Cutscene is goalie draw Info on Shots
if Cutscenetype == 17 or Cutscenetype == 57 or Cutscenetype == 63 then



if HomeShots > AwayShots then

     Launcher.Sprite.Clip(HomePogCS,0,0,121,96)
    Launcher.Sprite.Draw(HomePogCS, ClockXCS , ClockYCS)
    Launcher.Sprite.Clip(HomePogCS,0,144,512,96)
    Launcher.Sprite.Draw(HomePogCS, ClockXCS , ClockYCS)
     Launcher.Font.DrawText(PlayerFont,HomeAbbreviation.." offense at "..Minutese..":"..Secondse.." ("..Period..")",ClockXCS + 125,ClockYCS +2,FontColor2)  
     Launcher.Font.DrawText(CommentFont,"Outshot its opponent "..HomeShots.." to "..AwayShots,ClockXCS + 125,ClockYCS +44,FontColor2)
elseif HomeShots < AwayShots then
Launcher.Sprite.Clip(AwayPogCS,0,0,121,96)
    Launcher.Sprite.Draw(AwayPogCS, ClockXCS , ClockYCS)
    Launcher.Sprite.Clip(AwayPogCS,0,144,512,96)
    Launcher.Sprite.Draw(AwayPogCS, ClockXCS , ClockYCS)
     Launcher.Font.DrawText(PlayerFont,AwayAbbreviation.." offense at "..Minutese..":"..Secondse.." ("..Period..")",ClockXCS + 125,ClockYCS +2,FontColor2)  
     Launcher.Font.DrawText(CommentFont,"Outshot its opponent "..AwayShots.." to "..HomeShots,ClockXCS + 125,ClockYCS +44,FontColor2)
elseif HomeShots == AwayShots then
 Launcher.Sprite.Clip(HomePogCS,0,0,121,96)
    Launcher.Sprite.Draw(HomePogCS, ClockXCS , ClockYCS)
    Launcher.Sprite.Clip(HomePogCS,0,144,512,96)
    Launcher.Sprite.Draw(HomePogCS, ClockXCS , ClockYCS)
     Launcher.Font.DrawText(PlayerFont,HomeAbbreviation.."  offense at "..Minutese..":"..Secondse.." ("..Period..")",ClockXCS + 125,ClockYCS +2,FontColor2)  
Launcher.Font.DrawText(CommentFont,HomeShots.." Shots on goal tonight",ClockXCS + 125,ClockYCS +44,FontColor2)
end
end
-- Cutscene is goal replay Draw First goal of game and Specials goals


if Cutscenetype == 42 or Cutscenetype == 38 or Cutscenetype == 43 or Cutscenetype == 41 or Cutscenetype == 39 or Cutscenetype == 77 or Cutscenetype == 78 then
 -- NumberGoal = Launcher.Player.Goals (ScorePlayer)
  --Launcher.Font.DrawText(teamfont,"NUMBER GOAL :"..NumberGoal,ClockX + 500,ClockY +500,FontColor2)
  Goaltype = " goal"
if HomeGoals == 1 and AwayGoals == 0 then

Launcher.Sprite.Clip(HomePogCS,0,0,121,96)
    Launcher.Sprite.Draw(HomePogCS, ClockXCS , ClockYCS)
    Launcher.Sprite.Clip(HomePogCS,0,144,512,96)
    Launcher.Sprite.Draw(HomePogCS, ClockXCS , ClockYCS)
     Launcher.Font.DrawText(PlayerFont,ScorePlayerName,ClockXCS + 125,ClockYCS ,FontColor2)  
     Launcher.Font.DrawText(CommentFont,"First goal of  game "..Minutese..":"..Secondse.." in the "..Period ,ClockXCS + 125,ClockYCS +44,FontColor2)
   
elseif  HomeGoals == 0 and AwayGoals == 1 then

Launcher.Sprite.Clip(AwayPogCS,0,0,121,96)
    Launcher.Sprite.Draw(AwayPogCS, ClockXCS , ClockYCS)
Launcher.Sprite.Clip(AwayPogCS,0,144,512,96)
    Launcher.Sprite.Draw(AwayPogCS, ClockXCS, ClockYCS)
      Launcher.Font.DrawText(PlayerFont,ScorePlayerName,ClockXCS + 125,ClockYCS,FontColor2)  
     Launcher.Font.DrawText(CommentFont,"First goal of  game "..Minutese..":"..Secondse.." in the "..Period ,ClockXCS + 125,ClockYCS +44,FontColor2)
elseif (HomeGoals + AwayGoals) > 1 then
if HomeGoals == AwayGoals then
Goaltype = "Game-tying goal "
elseif HomeGoals == AwayGoals + 1 and ScorePlayer < 20 or  AwayGoals == HomeGoals + 1 and ScorePlayer >= 20 then
Goaltype = "Go-ahead goal "
end
if  ScorePlayer < 20 then
 Launcher.Sprite.Clip(HomePogCS,0,0,121,96)
    Launcher.Sprite.Draw(HomePogCS, ClockXCS , ClockYCS)
    Launcher.Sprite.Clip(HomePogCS,0,144,512,96)
    Launcher.Sprite.Draw(HomePogCS, ClockXCS , ClockYCS)
  
elseif ScorePlayer >= 20 then 
   Launcher.Sprite.Clip(AwayPogCS,0,0,121,96)
    Launcher.Sprite.Draw(AwayPogCS, ClockXCS , ClockYCS)
Launcher.Sprite.Clip(AwayPogCS,0,144,512,96)
    Launcher.Sprite.Draw(AwayPogCS, ClockXCS, ClockYCS)

end


     Launcher.Font.DrawText(PlayerFont,ScorePlayerName,ClockXCS + 125,ClockYCS,FontColor2)  
     Launcher.Font.DrawText(CommentFont,Period.." Period "..Goaltype.." ("..Minutese..":"..Secondse..")",ClockXCS + 125,ClockYCS +44,FontColor2)
     
     
end
if Cutscenetype == 78 then
   Launcher.Sprite.Clip(BGSprite,155,256,640,24) 
     Launcher.Sprite.Draw(BGSprite, ClockXCS+121,ClockYCS+72)
  Launcher.Sprite.Clip(BGSprite,0,105,156,30)
  Launcher.Sprite.Draw(BGSprite, ClockXCS + 240,ClockYCS+70)
  Launcher.Font.DrawText(CommentFont,"Career Milestone ",ClockXCS + 128,ClockYCS +71,FontColor1)
end  
if Cutscenetype == 77 then
   Launcher.Sprite.Clip(BGSprite,155,256,640,24) 
     Launcher.Sprite.Draw(BGSprite, ClockXCS+121,ClockYCS+72)
  Launcher.Sprite.Clip(BGSprite,0,105,156,30)
  Launcher.Sprite.Draw(BGSprite, ClockXCS + 240,ClockYCS+70)
  Launcher.Font.DrawText(CommentFont,"Hat Trick ",ClockXCS + 128,ClockYCS +71,FontColor1)
end

--if NumberGoal == 2 then
--Launcher.Font.DrawText(CommentFont,"2nd goal tonight",ClockXCS + 128,ClockYCS +71,FontColor1)
--end
--if NumberGoal > 3 then
--Launcher.Font.DrawText(CommentFont,NumberGoal.."th goal tonight",ClockXCS + 128,ClockYCS +71,FontColor1)
--end
end


--


-- PENALTY TO PLAYER


end

-- First, let's make sure we're not in a cutscene or the pause menu
    if not Launcher.Game.InCutscene() and not Launcher.Game.Paused() then
    if Launcher.Game.Time() > 60 then
        -- Clipping the sprite means you only draw a portion of the image
        -- This allows you to store multiple images in one image file, like a tileset
        -- Our base image is 64 pixels high. The fist 32 is our background, the next 32 is our foreground for the overlap effect on top of the pog      
        -- So in this case, we tell the game to draw the sprite from 0, 0 to 406, 128
        Launcher.Sprite.Clip(BGSprite,0,0,256,75)
        
        -- Now we can draw the base sprite to the screen and it will be clipped
        Launcher.Sprite.Draw(BGSprite, ClockX, ClockY)
        
        -- Now that our background has been drawn, we can draw the home and away pogs on top of it
        --Launcher.Sprite.Draw(HomePog, ClockX + 37, ClockY + 30)
       -- Launcher.Sprite.Draw(AwayPog, ClockX + 20, ClockY + 94)
	--Launcher.Sprite.Draw(Arena, ClockX + 68, ClockY)

Launcher.Font.DrawText(teamfont,HomeAbbreviation,ClockX + 10,ClockY + 20,FontColor2)
Launcher.Font.DrawText(teamfont,AwayAbbreviation,ClockX + 10,ClockY + 44,FontColor2)
        


-- Penalty is pending
       if Launcher.Game.PenaltyPending() then
	-- penaltyplayer = Launcher.Player.LastName (Launcher.Game.PenaltyPendingPlayer())
Launcher.Sprite.Clip(BGSprite,0,135,256,30)	
Launcher.Sprite.Draw(BGSprite, ClockX, ClockY+75)
	-- Launcher.Font.DrawText(ClockFont2,penaltyplayer,ClockX,ClockY + 245,FontColor1)
--if Launcher.Game.PenaltyPendingTeam() == 0 then
--Launcher.Sprite.Draw(penaltymarker, ClockX + 46, ClockY + 71)
--elseif Launcher.Game.PenaltyPendingTeam() == 1 then
--Launcher.Sprite.Draw(penaltymarker,ClockX + 28, ClockY + 135 )
end
	
--end
-- Game warning Offsides and Icings
--if Launcher.Game.Warning() == 1 then
 --     Launcher.Sprite.Draw(icingsprite, ClockX + 15, ClockY + 202)
  -- elseif Launcher.Game.Warning() == 2 then
  --     Launcher.Sprite.Draw(offsidesprite, ClockX + 15, ClockY + 202)
  -- end


--POWERPLAY

if Launcher.Game.PowerplayTime() > 0 then

Launcher.Sprite.Clip(BGSprite,0,75,256,30)
Launcher.Sprite.Draw(BGSprite, ClockX, ClockY + 75)

  -- The next line retrieves the PP time in seconds
        pptime = Launcher.Game.PowerplayTime()
        

        
        -- Lets convert these seconds into minutes and seconds
        -- For minutes, simply divide by 60 and round down
        ppMinutes = math.floor(pptime/60)
                
            
        -- % is modulo. Modulo means the remainder of a division
        -- So in our case, the remainder of dividing the time by 60 would be the seconds component
        ppSeconds = pptime % 60
        if ppSeconds < 10 then
            -- let's pad a zero if it's 9 or less so it looks nicer
            ppSeconds = "0"..ppSeconds
        end 

Launcher.Font.DrawText(powerplayfont," "..ppMinutes..":"..ppSeconds,ClockX + 3,ClockY + 70,FontColor1)
--PTeam = Launcher.Game.PenaltyTeam(Index)
--if PTeam == 1 then
		--Launcher.Sprite.Clip(BGSprite,0,105,125,23)
--Launcher.Sprite.Draw(BGSprite, ClockX, ClockY +25)
	--	elseif PTeam == 0 then
	--	Launcher.Sprite.Clip(BGSprite,0,105,125,23)
--Launcher.Sprite.Draw(BGSprite, ClockX, ClockY +49)
	--end

end





        -- Now that we have the game time, we can render all of the information to the screen using the DrawText function.
        Launcher.Font.DrawText(teamfont,HomeGoals,ClockX + HomeGoalsX,ClockY + 20,FontColor2)
        Launcher.Font.DrawText(teamfont,AwayGoals,ClockX + AwayGoalsX,ClockY + 44,FontColor2)
        Launcher.Font.DrawText(periodfont,Period,ClockX + TimeX+15,ClockY + 2,FontColor2)
        Launcher.Font.DrawText(timefont ,""..Minutes..":"..Seconds,ClockX + TimeX,ClockY +32,FontColor2)

        
    end
if Launcher.Game.Time() < 60 then
--the last minute timer 
  Launcher.Sprite.Clip(BGSprite,0,165,155,81)
        
        -- Now we can draw the base sprite to the right bottom of screen and it will be clipped
        Launcher.Sprite.Draw(BGSprite, Launcher.Screen.Width() -355, Launcher.Screen.Height()-281)

Launcher.Font.DrawText(timefont2 ,"0:"..Seconds,Launcher.Screen.Width() -325,Launcher.Screen.Height()-278,FontColor3)
end

end

if  Launcher.Game.Paused() then
  if not Launcher.Game.Over () then
         
          if Time == 0 then
      Launcher.Sprite.Clip(BGSprite,0,0,512,24)
Launcher.Sprite.Draw(BGSprite, PauseMenuX-385, 32)
 Launcher.Sprite.Clip(HomePogCS,121,96,385,48)
   Launcher.Sprite.Draw(HomePogCS, PauseMenuX-385 ,56)
   Launcher.Sprite.Clip(AwayPogCS,0,0,385,96)
   Launcher.Sprite.Draw(AwayPogCS, PauseMenuX-385 ,134)
   Launcher.Sprite.Clip(HomePogCS,0,0,385,96)
   Launcher.Sprite.Draw(HomePogCS, PauseMenuX ,134)
   Launcher.Font.DrawText(CommentFont,Intermission,PauseMenuX-185,32,FontColor2)
      else
Launcher.Sprite.Clip(BGSprite,0,0,512,24)
Launcher.Sprite.Draw(BGSprite, PauseMenuX-385, 32)
 Launcher.Sprite.Clip(HomePogCS,121,96,385,48)
   Launcher.Sprite.Draw(HomePogCS, PauseMenuX-385 ,56)
   Launcher.Sprite.Clip(AwayPogCS,0,0,385,96)
   Launcher.Sprite.Draw(AwayPogCS, PauseMenuX-385 ,134)
   Launcher.Sprite.Clip(HomePogCS,0,0,385,96)
   Launcher.Sprite.Draw(HomePogCS, PauseMenuX ,134)
   Launcher.Font.DrawText(CommentFont,Minutese..":"..Secondse.." in the "..Period.." period" ,PauseMenuX-185,32,FontColor2)
end

  else
   Launcher.Sprite.Clip(BGSprite,0,0,512,24)
Launcher.Sprite.Draw(BGSprite, PauseMenuX-385, 32)
 Launcher.Sprite.Clip(HomePogCS,121,96,385,48)
   Launcher.Sprite.Draw(HomePogCS, PauseMenuX-385 ,56)
   Launcher.Sprite.Clip(AwayPogCS,0,0,385,96)
   Launcher.Sprite.Draw(AwayPogCS, PauseMenuX-385 ,134)
   Launcher.Sprite.Clip(HomePogCS,0,0,385,96)
   Launcher.Sprite.Draw(HomePogCS, PauseMenuX ,134)
   Launcher.Font.DrawText(CommentFont,"Game Completed" ,PauseMenuX-185,32,FontColor2)

  end
end
end

-- ************ CALLBACK DEFINITIONS ************ 

-- Callbacks are functions we define that will be called if an in-game event happens
-- There are many kinds of callbacks, but for our case we only need Render and DeviceCreated
-- Render is called every time a frame is rendered
-- DeviceCreated is called right after creating the D3D device, which is right before the in-game loading screen
-- The DeviceCreated callback function is where we load our assets
-- The Render callback function is where we draw everything

Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("Render",RenderCallback)
Launcher.Callback.Register("CutsceneStarted",CutsceneStartedCallback)
Launcher.Callback.Register("Reloaded",ReloadedCallback)


Launcher.Mem.WriteASM(0x58f2bc,[[
    nop 
    nop 
    nop 
    nop 
    nop 
    nop 
    mov ebx, 0x58F4A4
    jmp ebx
]])









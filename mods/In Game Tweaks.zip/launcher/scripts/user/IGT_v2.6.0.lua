-- drgullen's In Game Tweaks - v2.6.0 - December 24, 2021

-- Requirements to run this script:
	--	Vod's "NHL 2004 Launcher" (V2.35 or newer) and these libraries that go with the Launcher:
		-- Default Libraries (V2.52 or newer)
		-- Default System Scripts (V2.15 or newer)
		-- Tweaks (V1.1 or newer)
	
-- ============================================ START OF SETTINGS SECTION - CHANGE THINGS HERE TO ALTER GAME PLAY AS YOU WISH =================================================

-- =========================================================================== OFFLINE ========================================================================================

-- Attribute Tweaks (APPLIES TO OFFLINE MODE ONLY)
AccelTweak = Launcher.Config.Bool("acceltweak",true) -- Set to false to disable the tweak to Player Acceleration
AccuracyTweak = Launcher.Config.Bool("accuracytweak",true) -- Set to false to disable the tweak for Shot Accuracy
AggressionTweak = Launcher.Config.Bool("aggressiontweak",true) -- Set to false to disable the tweak for Player Aggression
AgilityTweak = Launcher.Config.Bool("agilitytweak",true) -- Set to false to disable the tweak for Player Agility
BalanceTweak = Launcher.Config.Bool("balancetweak",true) -- Set to false to disable the tweak for Player Balance
CheckingTweak = Launcher.Config.Bool("checkingtweak",true) -- Set to false to disable the tweak for Checking (needs to be true if setting BigHits to true below)
DekingTweak = Launcher.Config.Bool("dekingtweak",true) -- Set to false to disable the dek tweak
EnduranceTweak = Launcher.Config.Bool("endurancetweak",true) -- Set to false to disable the tweak for Player Endurance
PassingTweak = Launcher.Config.Bool("passingtweak",true) -- Set to false to disable the tweak for Passing
PenaltyTweak = Launcher.Config.Bool("penaltytweak",true) -- Set to false to disable the tweak for the player's ability to resist penalties
PlayerSpeedTweak = Launcher.Config.Bool("playerspeedtweak",true) -- Set to false to disable the tweak for the player's speed multiplier value
PowerPlayTweak = Launcher.Config.Bool("powerplaytweak",true) -- Set to false to disable the passing boost associated with the players on Power Play lines
	-- IMPORTANT: The PassingTweak listed above must also be true for this to be enabled
PowerTweak = Launcher.Config.Bool("powertweak",true) -- Set to false to disable the tweak for Shot Power
PuckControlTweak = Launcher.Config.Bool("puckcontroltweak",true) -- Set to false to disable the tweak for Puck Control
ToughnessTweak = Launcher.Config.Bool("toughnesstweak",true) -- Set to false to disable the tweak for Player Toughness

-- Shootout Tweaks (APPLIES TO OFFLINE MODE ONLY)
ShootOutTweaks = Launcher.Config.Bool("shootouttweaks",true) -- Set to false to disable tweaks to the shooter and goaltender resulting in more varied Shootout results

-- Goalie Injury Settings (APPLIES TO OFFLINE MODE ONLY)
	-- IMPORTANT: MAKE SURE BOTH TEAMS ARE SET TO HUMAN CONTROL IF YOU PLAN TO USE THIS FEATURE
GoalieDiagnosis = Launcher.Config.Bool("goaliediagnosis",true) -- Set to false to disable the script from generating a diagnosis for a goaltender injury
GoalieInjuries = Launcher.Config.Bool("goalieinjuries",true) -- Set to false to disable the simulation of a goaltender injury (occurs very rarely)
GoalieInjuryLikely = Launcher.Config.Bool("goalieinjurylikely",false) -- Set to true to drastically increase the chance of the simulation of a goaltender injury (will probably happen next game)

-- Hybrid 3-on-3 OT (setup by assessing Major penalties for "Delay of Game" to keep a player from each team in the box for the entire 5-minute OT)
	-- IMPORTANT: Do not set these to true if you are in the Playoffs (i.e. 20-minute OT periods) of your season or dynasty or tournament.
ThreeonThreeOT = Launcher.Config.Bool("threeonthreeot",false) -- Set to true for hybrid 3-on-3 in Overtime (NOTE: THIS ONLY WORKS WITH THE "SINGLE OT (4-ON-4)" TIE-BREAK OPTION SO MAKE SURE THAT IS SET)
SOAfterOT = Launcher.Config.Bool("soafterot",false) -- Set to true if you have ThreeonThreeOT set to true and want a shootout after the overtime period if still tied
	-- IMPORTANT: While in OT, edit the shootout lines if the players placed in the box for the 3-on-3 OT are on the shootout lines, if you don't, the game will crash
	-- IMPORTANT: YOU NEED TO DO THIS FOR BOTH TEAMS AS THE GAME ENGINE WILL NOT DO IT AUTOMATICALLY FOR THE AI

-- On/Off switches for Scripted Penalties
AdditionalPenalties = Launcher.Config.Bool("additionalpenalties",true) -- Set to false to disable all scrpited penalties
DoubleMinorPenalties = Launcher.Config.Bool("doubleminorpenalties",true) -- Set to false to disable the chance of a Double Minor penalty for High Sticking
MajorPenalties = Launcher.Config.Bool("majorpenalties",true) -- Set to false to disable the chance of a Major penalty for Checking From Behind
Misconducts = Launcher.Config.Bool("misconductpenalties",true) -- Set to false to disable chances at receiving Game Misconduct penalties

-- Scripted Penalties (AdditionalPenalties must be set to true otherwise none of these will be active)
CoincidentalMinors = Launcher.Config.Bool("coincidentalminors",true) -- Set to false to disable the chance of hybrid coincidental minor penalties
DelayPenalty = Launcher.Config.Bool("delaypenalty",true) -- Set to false to disable the chance of a "Delay of Game" penalty for shooting the puck out of play from within the defensive zone
IcingPenalty = Launcher.Config.Bool("icingpenalty",false) -- Set to true to enable the chance of a "Delay of Game" penalty for multiple successive icings by the same team
	-- IMPORTANT: Leave this false if planning to use the "IcingLineManagement" option below
InstigatorPenalty = Launcher.Config.Bool("instigatorpenalty",true) -- Set to false to disable the chance of an instigator penalty when a fight occurs
Long5on3 = Launcher.Config.Bool("long5on3",true) -- Set to false to disable the chance of back-to-back minors to the same team resulting in almost two minutes of 5-on-3
OfficialAbusePenalty = Launcher.Config.Bool("officialabusepenalty",true) -- Set to false to disable the chance of a player receiving an end-of-period penalty for verbally abusing an official
PreGamePenalty = Launcher.Config.Bool("pregamepenalty",true) -- Set to false to disable the chance of a player receiving a Game Misconduct for attempting to injure someone during the pre-game warm-up
	-- IMPORTANT: Set "PreGameGoalies" below to true or false to include or exclude goaltenders as being eligible for this penalty
RoughingPenalty = Launcher.Config.Bool("roughingpenalty",true) -- Set to false to disable the additional chances of roughing calls relating to big hits (must be true for Double Minors and Majors to work)

-- Other True/False Options
BalancedFaceoffs = Launcher.Config.Bool("balancedfaceoffs",true) -- Set to false to stop the script from making attempts to balance the faceoff win percentages
BigHits = Launcher.Config.Bool("bighits",true) -- Set to false to disable the charged up checking tweak (doing so will reduce chance of an in-game injury)
DeterioratingIce = Launcher.Config.Bool("deterioratingice",true) -- Set to false to stop the bouncing puck/slowing ice effects due to changing ice conditions as the period progresses
FalseStarts = Launcher.Config.Bool("falsestarts",true) -- Set to false to disable chance of a false start on a face-off (RandomPuckDrops must also be set to true for a false start to occur)
GameFlow = Launcher.Config.Bool("gameflow",true) -- Set to false to stop the goaltenders from passing more if there have been an excessive number of faceoffs to that point in the game
	-- IMPORTANT: Adjust the FaceoffsPerMinute value below in "Game Multi-Value Options" if you want more or less total faceoffs
IcingLineManagement = Launcher.Config.Bool("icinglinemanagement",true) -- Set to false to stop the script from forcing the line that iced the puck back onto the ice
	-- IMPORTANT: Make sure the "IcingPenalty" in the Scripted Penalties section above is set to false if you are planning to use this system
PreGameGoalies = Launcher.Config.Bool("pregamegoalies",false) -- Set to true if you want goaltenders to be eligible to be placed in the box for a pre-game penalty
RandomPuckDrops = Launcher.Config.Bool("randompuckdrops",true) -- Set to false to disable the referee dropping the puck at random time intervals (required if FalseStarts listed above is set to true)
RefErrors = Launcher.Config.Bool("referrors",true) -- Set to false to disable the chance of the referee stopping play in error
ShotFlow = Launcher.Config.Bool("shotflow",true) -- Set to false to stop the game from forcing missed shots when the total shots on goal is getting too high
	-- IMPORTANT: Adjust the ShotsPerMinute value below in "Game Multi-Value Options" if you want more or less total shots on goal
SlowingPassSpeed = Launcher.Config.Bool("slowingpassspeed",true) -- Set to false to disable the speed of passes slowing down as the ice deteriorates
StrangeBounceTweak = Launcher.Config.Bool("strangebounces",true) -- Set to false to disable the chance of a strange bounce off the boards
WildShot = Launcher.Config.Bool("wildshot",true) -- Set to false to disable the chance of a player's shot missing the net entirely

-- ====================================================================== OFFLINE OR ONLINE ===================================================================================

-- Alternate Game Modes (APPLIES TO BOTH ONLINE AND OFFLINE MODES)
RealTime = Launcher.Config.Bool("realtime",false) -- Set to true to have the clock tick in real time
RealTimeStartInThird = Launcher.Config.Bool("rtime3rd",false) -- Set to true to have the clock tick in real time, but playing a 1-period game (RealTime on previous line must also be true)

-- Game Multi-Value Options - change the number for the desired effect - NOTE: READ CAREFULLY AS SOME THINGS HERE NOT VALID FOR ONLINE
ClearingDelaysPerGame = Launcher.Config.Int("clearingdelays",2) -- Increase or decrease for more or less possible "Delay of Game" penalties for the defense clearing the puck out of play (APPLIES TO OFFLINE ONLY)
	-- IMPORTANT: The "DelayPenalty" option above in the Scripted Penalties section must be set to true to get any clearing delays
	-- IMPORTANT: VALUES: Set to 0 for unlimited otherwise set to a per game limit (Default is 2)
FaceoffsPerMinute = Launcher.Config.Number("faceoffsperminute",0.88) -- Increase or decrease for more or less total faceoffs per game (Default of 0.88 equates to NHL average of 50 to 60 faceoffs per game)
	-- IMPORTANT: FaceoffsPerMinute APPLIES TO OFFLINE ONLY
	-- IMPORTANT: GameFlow listed above in "Other True/False Options" must be set to true for FaceoffsPerMinute to work
	-- IMPORTANT: Default value of 0.88 works best with period slider set to 10
	-- IMPORTANT: This feature will not be able to keep up if playing with Real Time 20-minute periods (faceoff total will most likely exceed 70)
ShotsPerMinute = Launcher.Config.Number("shotsperminute",0.88) -- Increase or decrease for more or less shots on goal (Default of 1.05 equates to an average of between 60 and 70 total shots per game)
	-- IMPORTANT: ShotsPerMinute APPLIES TO BOTH ONLINE AND OFFLINE MODES
	-- IMPORTANT: ShotFlow listed above in "Other True/False Options" must be set to true for ShotsPerMinute to work (IF ONLINE, SET TO TRUE IN ONLINE SECTION)
	-- IMPORTANT: This system can be used with the period slider set to any value, but the longer the period, the more missed shots you'll experience
	-- IMPORTANT: NOTE: If playing with 20-minute periods, expect an unrealistically high number of missed shots in order to achieve NHL-like shot totals
InjuryChance = Launcher.Config.Int("injurychance",1) -- Set to 0 to disable, 1 for a random chance (DO NOT USE 1 IF ONLINE), 2 for a higher chance (if Offline, set BigHits to true for even more of a chance)
QuickCover = Launcher.Config.Int("quickcover",1) -- Set to 0 for default NHL 2004 cover speed, 1 to have the goaltender cover moderately quickly, 2 for very quickly (APPLIES TO BOTH ONLINE AND OFFLINE MODES)

-- ============================================================================ ONLINE ========================================================================================

-- Online Settings (THESE VALUES OVERRIDE THE PREVIOUS VALUES IF OnlinePlay IS SET TO TRUE)
-- IMPORTANT: Make sure your values below are identical to the values in your opponent's script to avoid any unexpected results during the game

OnlinePlay = Launcher.Config.Bool("onlineplay",false) -- Set to true if playing the online

if OnlinePlay == true then

-- Online Tweaks  (LEAVE ALL THESE FALSE)
	AccelTweak = false
	AccuracyTweak = false
	AggressionTweak = false
	AgilityTweak = false
	BalanceTweak = false
	CheckingTweak = false
	DekingTweak = false
	EnduranceTweak = false
	PassingTweak = false
	PenaltyTweak = false
	PlayerSpeedTweak = false
	PowerPlayTweak = false
	PowerTweak = false
	PuckControlTweak = false
	ShootOutTweaks = false
	StrangeBounceTweak = false
	ToughnessTweak = false

-- Online Additional Options  (UNLESS GIVEN A CHOICE BELOW, LEAVE THESE VALUES AS THEY ARE)
	BalancedFaceoffs = Launcher.Config.Bool("balancedfaceoffs",true) -- Set to false to stop the script from making attempts to balance the faceoff win percentages
	BigHits = false
	DeterioratingIce = Launcher.Config.Bool("deterioratingice",true) -- Set to false to stop the bouncing puck/slowing ice effects due to changing ice conditions as the period progresses
	FalseStarts = false
	GameFlow = false
	GoalieDiagnosis = false
	GoalieInjuries = false
	GoalieInjuryLikely = false
	IcingLineManagement = Launcher.Config.Bool("icinglinemanagement",true) -- Set to false to stop the script from forcing the line that iced the puck back onto the ice
		-- IMPORTANT: Make sure the "IcingPenalty" below is set to false if you are planning to use this system
	PreGameGoalies = false
	RandomPuckDrops = false
	RefErrors = false
	ShotFlow = Launcher.Config.Bool("shotflow",true) -- Set to false to stop the game from forcing missed shots when the total shots on goal is getting too high
		-- IMPORTANT: Adjust the ShotsPerMinute value above in "Game Multi-Value Options" if you want more or less total shots on goal
		-- IMPORTANT: Make sure the ShotsPerMinute value is the same in both scripts (yours and your opponent's)
	SlowingPassSpeed = false
	WildShot = false

-- Online Hybrid 3-on-3  (setup by assessing Major penalties for "Delay of Game" to keep a player from each team in the box for the entire 5-minute OT)
		-- IMPORTANT: Do not set these to true if you are in the Playoffs (i.e. 20-minute OT periods) of your season or dynasty or tournament.
	ThreeonThreeOT = Launcher.Config.Bool("threeonthreeot",false) -- Set to true for hybrid 3-on-3 in Overtime (NOTE: THIS ONLY WORKS WITH THE "SINGLE OT (4-ON-4)" TIE-BREAK OPTION SO MAKE SURE THAT IS SET)
	SOAfterOT = Launcher.Config.Bool("soafterot",false) -- Set to true if you also have ThreeonThreeOT set to true and want a shootout after the overtime period
		-- IMPORTANT: While in OT, edit the shootout lines if the players placed in the box for the 3-on-3 OT are on the shootout lines, if you don't change them, the game will crash
		-- IMPORTANT: BOTH YOU AND YOUR OPPONENT NEED TO DO THIS

-- Online Additional Penalties  (UNLESS GIVEN A CHOICE BELOW, LEAVE THESE VALUES AS THEY ARE)
	AdditionalPenalties = Launcher.Config.Bool("additionalpenalties",true) -- Set to false to disable all scripted penalties
	CoincidentalMinors = false
	DelayPenalty = false
	DoubleMinorPenalties = false
	IcingPenalty = Launcher.Config.Bool("icingpenalty",false) -- Set to true to enable the chance of a "Delay of Game" penalty for multiple successive icings by the same team
		-- IMPORTANT: Leave this false if planning to use the "IcingLineManagement" option above
	InstigatorPenalty = false
	Long5on3 = false
	MajorPenalties = false
	Misconducts = false
	OfficialAbusePenalty = false
	PreGamePenalty = false
	RoughingPenalty = false
end

-- ==================================================================== END OF SETTINGS SECTION ==============================================================================

-- ========================== SCRIPT CODE SECTION - FOR THE SCRIPT TO FUNCTION AS INTENDED, PLEASE DO NOT CHANGE ANYTHING BELOW THIS LINE ====================================

-- Variable starting values
AwayFixPending = 0
AwayGoalieInjured = 0
Checking = 0
CoincidentalMinor = 0
CurrentTime = 1200
DelayPenaltySet = 0
Diagnosis = 0
DMCount = 0
DoubleMinor = 0
ExclPID1 = -1
ExclPID1Time = 1200
ExclPID2 = -1
ExclPID2Time = 1200
ExclPID3 = -1
ExclPID3Time = 1200
ExclPID4 = -1
ExclPID4Time = 1200
ExclPID5 = -1
ExclPID5Time = 1200
ExclPID6 = -1
ExclPID6Time = 1200
ExpectedAwayTotalPP = 0
ExpectedHomeTotalPP = 0
FaceoffRate = 0
FirstBalance = 0
FirstFaceoff = 0
FixAwayMisconduct = 0
FixHomeMisconduct = 0
ForcedMissed = 0
HomeFixPending = 0
HomeGoalieInjured = 0
IcingAwayLine = -1
IcingHomeLine = -1
IcingPlayer = -1
L5on3 = 0
LastIcing = 1200
LastIcingTeam = -1
MajorAwayPlayer = -1
MajorHomePlayer = -1
Majors = 0
MajorTrigger = 0
MisconductPenalty = 0
PassesSinceReload = 0
PenaltySet = 0
PPPlayer = 0
PPT = 0
PreGamePenaltyPending = 0
ScriptedPending = 0
SetIcingLine = 0
ShotFlowPause = false
StartEnergyMultiplier = 0.000244140625
StartPassSpeed = 92
PassSpeed = StartPassSpeed
StartPlayerSpeedMultiplier = 0.62
PlayerSpeedMultiplier = StartPlayerSpeedMultiplier
StartPuckBoardBounceFriction = 0.285
StartPuckBounceFriction = 0.285
StartPuckGravity = 2.5
StopforDelay = 0
StrangeBounce = 0
StrangeBounceChance = 0
ThreeonThree = 0
TotalClearings = 0
TotalFaceoffs = 0
TotalShots = 0
UseCutSceneFunction = 0
WildShotPause = false

Launcher.Physics.SetPassBaseSpeed(StartPassSpeed)
Launcher.Physics.SetPuckGravity(StartPuckGravity)

-- Functions
function CutsceneStartedCallback()
	if UseCutSceneFunction == 1 then
-- This determines which line to put back onto the ice in the case of an icing call if the "IcingManagement" option is set to true
		if SetIcingLine == 1 and IcingLineManagement == true and PPT == 0 then
			if IcingPlayer > 19 then
				IcingPlayer = IcingPlayer - 20
				IcingHomeLine = -1
				IcingPlayerID = -1
				loopcount = 0
				repeat
					loopplayer = Launcher.Line.AwayPlayer(0,loopcount)
					if loopplayer == IcingPlayer then
						IcingPlayerID = loopplayer
					else
						loopcount = loopcount + 1
					end
				until IcingPlayerID == loopplayer
				if IcingPlayerID < 3 then
					IcingAwayLine = 0
				elseif IcingPlayerID < 6 then
					IcingAwayLine = 1
				elseif IcingPlayerID < 9 then
					IcingAwayLine = 2
				elseif IcingPlayerID < 12 then
					IcingAwayLine = 3
				elseif IcingPlayerID < 14 then
					IcingAwayLine = 0
				elseif IcingPlayerID < 16 then
					IcingAwayLine = 1
				else
					IcingAwayLine = 2
				end
			else
				IcingAwayLine = -1
				IcingPlayerID = -1
				loopcount = 0
				repeat
					loopplayer = Launcher.Line.HomePlayer(0,loopcount)
					if loopplayer == IcingPlayer then
						IcingPlayerID = loopplayer
					else
						loopcount = loopcount + 1
					end
				until IcingPlayerID == loopplayer
				if IcingPlayerID < 3 then
					IcingHomeLine = 0
				elseif IcingPlayerID < 6 then
					IcingHomeLine = 1
				elseif IcingPlayerID < 9 then
					IcingHomeLine = 2
				elseif IcingPlayerID < 12 then
					IcingHomeLine = 3
				elseif IcingPlayerID < 14 then
					IcingHomeLine = 0
				elseif IcingPlayerID < 16 then
					IcingHomeLine = 1
				else
					IcingHomeLine = 2
				end
			end
			SetIcingLine = 2
		end
-- This resets the enforcement of a missed shot if the "ShotFlow" option is set to true
		if ShotFlow == true then
			ForceMissed = 0
		end
-- This resets the Checking attribute if it was set for a big hit prior to the last whistle
		if CheckingTweak == true and Checking > 1 then
			Checking = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(11,Checking,0,true)
			Checking = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(11,Checking,1,true)
		end
-- This resets the count of the number of passes since the player's default attributes were reloaded
		PassesSinceReload = 0
-- This sets how quickly the goaltender will cover the puck depending on whether or not a Power Play is active
		PPT = Launcher.Game.PowerplayTime()
		if QuickCover == 1 and PPT == 0 then
			Launcher.Game.SetGoalieCoverTime(50)
		elseif QuickCover == 2 and PPT == 0 then
			Launcher.Game.SetGoalieCoverTime(10)
		end
-- This resets the strange bounce option if active
		if DeterioratingIce == true then
			Launcher.Physics.SetPuckBoardBounceFriction(StartPuckBoardBounceFriction)
		end
-- This resets the player's speed multipliers to their default values prior to every faceoff
		if PlayerSpeedTweak == true then
			Launcher.Physics.SetPlayerSpeedMultiplier(StartPlayerSpeedMultiplier)
			PlayerSpeedMultiplier = StartPlayerSpeedMultiplier
			Launcher.Physics.SetPlayerSpeedEnergyMultiplier(StartEnergyMultiplier)
		end
-- This reloads the player's default attributes
		for loopcount=0, 39 do
			for attributecount=0, 16 do
				Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
				Value = players[loopcount] [attributecount]
				Launcher.Mem.WriteByte(Pointer, Value)
			end
		end
	end
-- This pauses the ShotFlow system late in the 3rd period if the score isn't tied
	if ShotFlow == true and RealTime == false and Launcher.Game.Period() == 3 and Launcher.Game.Time() < 300 then
		if Launcher.Stats.AwayGoals() ~= Launcher.Stats.HomeGoals() then
			ShotFlowPause = true
		else
			ShotFlowPause = false
		end
	else
		ShotFlowPause = false
	end
-- This disables the ShotFlow system in the final minute of Regulation Time (shots can still miss from a WildShot)
	if ShotFlow == true and Launcher.Game.Period() == 3 and Launcher.Game.Time() < 60 then
		ShotFlow = false
	end
-- This corrects the game stats relating to Major and Misconduct penalties where a bug in the base game miscalculates the number of attempted Power Plays
	if PPT == 0 and AwayFixPending == 1 then 
		if AwayFixGoals ~= Launcher.Stats.AwayGoals() then
			AwayFixGoalDifference = Launcher.Stats.AwayGoals() - AwayFixGoals
			AwayNewPPTotal = Launcher.Stats.AwayPowerPlays() - AwayFixGoalDifference
			Launcher.Stats.AwayPowerPlays(AwayNewPPTotal)
			AwayFixPending = 0
		else
			AwayFixPending = 0
		end
	end
	if PPT == 0 and HomeFixPending == 1 then
		if HomeFixGoals ~= Launcher.Stats.HomeGoals() then
			HomeFixGoalDifference = Launcher.Stats.HomeGoals() - HomeFixGoals
			HomeNewPPTotal = Launcher.Stats.HomePowerPlays() - HomeFixGoalDifference
			Launcher.Stats.HomePowerPlays(HomeNewPPTotal)
			HomeFixPending = 0
		else
			HomeFixPending = 0
		end
	end
	if PPT == 0 and FixAwayMisconduct == 1 and ExpectedAwayTotalPP ~= Launcher.Stats.AwayPowerPlays() then
		AwayNewPPTotal = Launcher.Stats.AwayPowerPlays() - 1
		Launcher.Stats.AwayPowerPlays(AwayNewPPTotal)
		FixAwayMisconduct = 0
	end
	if PPT == 0 and FixHomeMisconduct == 1 and ExpectedHomeTotalPP ~= Launcher.Stats.HomePowerPlays() then
		HomeNewPPTotal = Launcher.Stats.HomePowerPlays() - 1
		Launcher.Stats.HomePowerPlays(HomeNewPPTotal)
		FixHomeMisconduct = 0
	end
end
function FaceOffStartedCallback()
	if FirstFaceoff == 0 then
-- Randomizes the seed once per game based on current OS time to produce different sets of random numbers for each game
		math.randomseed(os.time())
-- This sets penalty chances and timing options depending on what game mode is being played
		if RealTime == true then
			RoughingChance = 0.0125
			RoughingMisconduct = 0.975
			DoubleMinorChance = 0.975
			MajorChance = 0.0125
			MajorMisconduct = 0.01
			Launcher.Game.SetTimer(28)
			Launcher.Game.SetPenaltyTimer(28)
			if RealTimeStartInThird == true then
				Launcher.Game.SetPeriod(3)
			end
		else
			RoughingChance = 0.033
			RoughingMisconduct = 0.95
			DoubleMinorChance = 0.95
			MajorChance = 0.033
			MajorMisconduct = 0.025
		end
	end
-- This resets the previous pause of the Wild Shot system, if applicable
	if WildShot == true and WildShotPause == true then
		WildShotPause = false
	end
-- This keeps track of the total faceoffs for use with the Game Flow system
	TotalFaceoffs = TotalFaceoffs + 1
-- This updates hit totals to avoid roughing situations that occurred prior to this faceoff being penalized right after this faceoff
	if FirstFaceoff ~= 0 then
		for loopcount=0, 39 do
			if hittotals[loopcount] ~= Launcher.Player.Hits(loopcount) then
				hittotals[loopcount] = Launcher.Player.Hits(loopcount)
			end
		end
	end
-- This resets the period and clock to one second remaining in the third period to complete the setup for the hybrid 3-on-3 OT if it's active
	if ThreeonThreeOT == true and Launcher.Game.Period() == 4 and ThreeonThree == 1 then
		Launcher.Game.SetPeriod(3)
		Launcher.Game.SetTime(1)
		ThreeonThree = 2
	end
-- This randomizes how quickly or how slowly the referee drops the puck during a face-off
	if RandomPuckDrops == true then
		PuckDropTime = math.random (35, 127)
		Launcher.Game.SetPuckDropTime(PuckDropTime,60)
-- This defines the parameters for a false start on a face-off and stops play if they are valid
		CurrentTime = math.floor(Launcher.Game.Time())
		if FalseStarts == true and FirstFaceoff ~= 0 and PPT == 0 and CurrentTime > 1 and SetIcingLine == 0 then
			FalseStartChance = math.random ()
			if FalseStartChance > 0.85 and PuckDropTime < 40 then
				CurrentTime = math.floor(CurrentTime - 1)
				Launcher.Game.SetTime(CurrentTime)
				Launcher.Game.StopPlay()
			end
		end
	end
-- This saves the original attributes of all 40 dressed players to be reloaded prior to each subsequent face-off
	if FirstFaceoff == 0 then
		players = {}
		for loopcount=0, 39 do
			players[loopcount] = {}
			for attributecount =0, 16 do
				Pointer = Launcher.Mem.Long(0x79C310+loopcount*4) + 0x7C + attributecount
				Value = Launcher.Mem.Byte(Pointer)
				players[loopcount] [attributecount] = Value
			end
		end
-- This sets up an array to keep track of which players have dished out hits in order to assess Roughing, Double Minor and Major penalties
		hittotals = {}
		for loopcount=0, 39 do
			hittotals[loopcount] = Launcher.Player.Hits(loopcount)
		end
-- This determines whether the game is using default or no-touch icing and disables the Icing Line Management if using default icing
		IcingType = Launcher.Mem.Byte(0x4b48eb)
		if IcingType == 235 then
			NoTouchIcing = false
			IcingLineManagement = false
		else
			NoTouchIcing = true
		end
    end
-- This attempts to balance the face-off win percentages between the two teams if the "BalancedFaceoffs" option is active
	if BalancedFaceoffs == true then
		FaceOffHome = Launcher.Stats.HomeFaceoffsWon() - Launcher.Stats.AwayFaceoffsWon()
		FaceOffVis = Launcher.Stats.AwayFaceoffsWon() - Launcher.Stats.HomeFaceoffsWon()
		if FirstFaceoff == 0 then
			Launcher.Player.AllSetAttribute(9,255,0,true)
			Launcher.Player.AllSetAttribute(9,255,1,true)
			FirstFaceoff = 1
			UseCutSceneFunction = 1
		elseif FaceOffHome > 5 then
			Launcher.Player.AllSetAttribute(9,1,0,true)
			Launcher.Player.AllSetAttribute(9,255,1,true)
		elseif FaceOffVis > 5 then
			Launcher.Player.AllSetAttribute(9,255,0,true)
			Launcher.Player.AllSetAttribute(9,1,1,true)
		end
	end
-- This contains most of the player attribute tweaks (some are defined below in the PassCallback section)
	if FirstFaceoff ~= 0 and OnlinePlay == false then
		KeeporTweak = math.random ()
		if AccelTweak == true and KeeporTweak > 0.5 then
			Accel = math.random ()
			if Accel < 0.5 then
				Accel = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(1,Accel,0,true)
			Accel = math.random ()
			if Accel < 0.5 then
				Accel = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(1,Accel,1,true)
		end
		KeeporTweak = math.random ()
		if AgilityTweak == true and KeeporTweak > 0.5 then
			Agility = math.random ()
			if Agility < 0.5 then
				Agility = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(2,Agility,0,true)
			Agility = math.random ()
			if Agility < 0.5 then
				Agility = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(2,Agility,1,true)
		end
		KeeporTweak = math.random ()
		if BalanceTweak == true and KeeporTweak > 0.5 then
			Balance = math.random ()
			if Balance < 0.5 then
				Balance = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(3,Balance,0,true)
			Balance = math.random ()
			if Balance < 0.5 then
				Balance = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(3,Balance,1,true)
		end
		KeeporTweak = math.random ()
		if DekingTweak == true and KeeporTweak > 0.5 then
			Deking = math.random ()
			if Deking < 0.5 then
				Deking = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(7,Deking,0,true)
			Deking = math.random ()
			if Deking < 0.5 then
				Deking = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(7,Deking,1,true)
		end
		KeeporTweak = math.random ()
		if PuckControlTweak == true and KeeporTweak > 0.5 then
			PuckControl = math.random ()
			if PuckControl < 0.75 then
				PuckControl = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(8,PuckControl,0,true)
			PuckControl = math.random ()
			if PuckControl < 0.75 then
				PuckControl = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(8,PuckControl,1,true)
		end
		KeeporTweak = math.random ()
		if AggressionTweak == true and KeeporTweak > 0.5 then
			Aggression = math.random ()
			if Aggression < 0.5 then
				Aggression = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(10,Aggression,0,true)
			Aggression = math.random ()
			if Aggression < 0.5 then
				Aggression = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(10,Aggression,1,true)
		end
		KeeporTweak = math.random ()
		if EnduranceTweak == true and KeeporTweak > 0.5 then
			Endurance = math.random ()
			if Endurance < 0.5 then
				Endurance = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(12,Endurance,0,true)
			Endurance = math.random ()
			if Endurance < 0.5 then
				Endurance = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(12,Endurance,1,true)
		end
		KeeporTweak = math.random ()
		if PenaltyTweak == true and KeeporTweak > 0.5 then
			Penalty = math.random ()
			if Penalty < 0.5 then
				Penalty = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(14,Penalty,0,true)
			Penalty = math.random ()
			if Penalty < 0.5 then
				Penalty = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(14,Penalty,1,true)
		end
		KeeporTweak = math.random ()
		if ToughnessTweak == true and KeeporTweak > 0.5 then
			Toughness = math.random ()
			if Toughness < 0.5 then
				Toughness = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(15,Toughness,0,true)
			Toughness = math.random ()
			if Toughness < 0.5 then
				Toughness = 1.1
			end
			Launcher.Player.AllSetAttributeMultiplier(15,Toughness,1,true)
		end
		if InjuryChance == 0 then
			Launcher.Player.AllSetAttribute(16,99,0,true)
			Launcher.Player.AllSetAttribute(16,99,1,true)
		elseif InjuryChance == 1 then
			Injuries = math.random (50, 99)
			Launcher.Player.AllSetAttribute(16,Injuries,0,true)
			Launcher.Player.AllSetAttribute(16,Injuries,1,true)
		elseif InjuryChance == 2 then
			Launcher.Player.AllSetAttribute(16,1,0,true)
			Launcher.Player.AllSetAttribute(16,1,1,true)
		end
	end
end
function PassCallback()
-- If an icing call just occurred, this forces the line that iced the puck back onto the ice if the "IcingLineManagement" option is set to true
	if SetIcingLine == 2 and IcingLineManagement == true and PPT == 0 then
		if IcingAwayLine == -1 then
			CurrentLine = Launcher.Game.HomeLine()
			if CurrentLine == IcingHomeLine then
				IcingHomeLine = -1
				SetIcingLine = 0
			else
				Launcher.Line.Set(0,IcingHomeLine)
			end
		else
			CurrentLine = Launcher.Game.AwayLine()
			if CurrentLine == IcingAwayLine then
				IcingAwayLine = -1
				SetIcingLine = 0
			else
				Launcher.Line.Set(1,IcingAwayLine)
			end
		end
	end
-- This checks for pending Major or Misconduct penalties
	if Majors == 1 then
		Majors = 2
	elseif MisconductPenalty == 1 then
		MisconductPenalty = 2
	end
-- This keeps track of the number of passes since the last time the player's default attributes were reloaded
	PassesSinceReload = PassesSinceReload + 1
-- This resets the strange bounce option if active
	if StrangeBounceChance > 0.75 and DeterioratingIce == true and OnlinePlay == false then
		Launcher.Physics.SetPuckBoardBounceFriction(StartPuckBoardBounceFriction)
	end
-- This section contains tweaks related to player speed, passing and checking
	if PlayerSpeedTweak == true then
		FasterSlower = math.random ()
		SpeedTweak = (math.random (1, 3) / 100)
		if FasterSlower < 0.5 then
			PlayerSpeedMultiplier = PlayerSpeedMultiplier - SpeedTweak
			if PlayerSpeedMultiplier < 0.59 then
				PlayerSpeedMultiplier = PlayerSpeedMultiplier + 0.02
			end
		else
			PlayerSpeedMultiplier = PlayerSpeedMultiplier + SpeedTweak
			if PlayerSpeedMultiplier > 0.67 then
				PlayerSpeedMultiplier = PlayerSpeedMultiplier - 0.02
			end
		end
		Launcher.Physics.SetPlayerSpeedMultiplier(PlayerSpeedMultiplier)
		HomeorAwayPlayer = math.random ()
		if HomeorAwayPlayer < 0.5 then
			FasterSlower = math.random ()
			if FasterSlower < 0.5 then
				HomePlayerSpeed = Launcher.Mem.Float(0x79C840)
				HomePlayerSpeed = HomePlayerSpeed - 0.01
				if HomePlayerSpeed < 0.97 then
					HomePlayerSpeed = 1
				end
				Launcher.Physics.SetHomePlayerSpeedMultiplier(HomePlayerSpeed)
			else
				HomePlayerSpeed = Launcher.Mem.Float(0x79C840)
				HomePlayerSpeed = HomePlayerSpeed + 0.01
				if HomePlayerSpeed > 1.03 then
					HomePlayerSpeed = 1
				end
				Launcher.Physics.SetHomePlayerSpeedMultiplier(HomePlayerSpeed)
			end
		else
			FasterSlower = math.random ()
			if FasterSlower < 0.5 then
				AwayPlayerSpeed = Launcher.Mem.Float(0x79C844)
				AwayPlayerSpeed = AwayPlayerSpeed - 0.01
				if AwayPlayerSpeed < 0.97 then
					AwayPlayerSpeed = 1
				end
				Launcher.Physics.SetAwayPlayerSpeedMultiplier(AwayPlayerSpeed)
			else
				AwayPlayerSpeed = Launcher.Mem.Float(0x79C844)
				AwayPlayerSpeed = AwayPlayerSpeed + 0.01
				if AwayPlayerSpeed > 1.03 then
					AwayPlayerSpeed = 1
				end
				Launcher.Physics.SetAwayPlayerSpeedMultiplier(AwayPlayerSpeed)
			end
		end
	end
	if PassingTweak == true then
		if PowerPlayTweak == true and PPT > 0 then
			Passing = math.random () + 0.75
			Launcher.Player.AllSetAttributeMultiplier(6,Passing,0,true)
			Passing = math.random () + 0.75
			Launcher.Player.AllSetAttributeMultiplier(6,Passing,1,true)
		else
			Passing = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(6,Passing,0,true)
			Passing = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(6,Passing,1,true)
		end
	end
	if CheckingTweak == true then
		Checking = math.random ()
		if Checking < 0.25 then
			if BigHits == true then
				if Checking < 0.03 then
					Checking = 2.5
				elseif Checking < 0.07 then
					Checking = 2.25
				elseif Checking < 0.12 then
					Checking = 2
				else
					Checking = 0.75
				end
			else
				Checking = 0.75
			end
		end
		Launcher.Player.AllSetAttributeMultiplier(11,Checking,0,true)
		Launcher.Player.AllSetAttributeMultiplier(11,Checking,1,true)
	end
-- This section is only performed if either no regular penalty is pending or a Misconduct penalty is pending
	PenaltyPending = Launcher.Mem.Byte(0x79B9BC)
	if PenaltyPending == 0 or Majors == 2 or MisconductPenalty == 2 then
-- This sets up the Game Misconduct penalty connected with the previous Major for Checking from Behind
		if MajorPenalties == true and Misconducts == true and Majors == 2 then
			if MajorHomePlayer >= 0 then
				FixAwayMisconduct = 1
				ExpectedAwayTotalPP = Launcher.Stats.AwayPowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, MajorHomePlayer)
				Launcher.Game.SetPenaltyPendingID(30)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			else
				FixHomeMisconduct = 1
				ExpectedHomeTotalPP = Launcher.Stats.HomePowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, MajorAwayPlayer)
				Launcher.Game.SetPenaltyPendingID(30)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			end
			Majors = 3
			Launcher.Game.StopPlay()
		end
-- This sets up the Game Misconduct penalty connected with the previous minor for Roughing
		if MajorPenalties == true and Misconducts == true and MisconductPenalty == 2 then
			if MajorHomePlayer >= 0 then
				FixAwayMisconduct = 1
				ExpectedAwayTotalPP = Launcher.Stats.AwayPowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, MajorHomePlayer)
				Launcher.Game.SetPenaltyPendingID(23)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			else
				FixHomeMisconduct = 1
				ExpectedHomeTotalPP = Launcher.Stats.HomePowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, MajorAwayPlayer)
				Launcher.Game.SetPenaltyPendingID(23)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			end
			MisconductPenalty = 3
			Launcher.Game.StopPlay()
		end
-- This triggers the chance at Minor, Double Minor or Major penalties relating to what the game considers a "Hit" in the stats
		CurrentHitCount = 0
		BigHitPlayer = -1
		for loopcount=0, 39 do
			if hittotals[loopcount] ~= Launcher.Player.Hits(loopcount) then
				CurrentHitCount = CurrentHitCount + 1
				if loopcount ~= ExclPID1 and loopcount ~= ExclPID2 and loopcount ~= ExclPID3 and loopcount ~= ExclPID4 and loopcount ~= ExclPID5 and loopcount ~= ExclPID6 then
					BigHitPlayer = loopcount	
				end
			end
		end
		CurrentTime = Launcher.Game.Time()
		if CurrentHitCount > 0 and Checking == 2.5 and Majors == 0 and CurrentTime >= 300 then
			MajorTrigger = 1
		elseif CurrentHitCount > 0 and Checking > 2 and Majors == 0 and CurrentTime >= 300 then
			MajorTrigger = 2
		else
			MajorTrigger = 0
		end
-- This assesses the coincidental minor penalty if that option is enabled
		if CoincidentalMinor > 0 and AdditionalPenalties == true and CoincidentalMinors == true then
			PenaltySet = 0
			repeat
				PenaltyPlayer = math.random (0,17)
				if PenaltyPlayer ~= ExclPID1 and PenaltyPlayer ~= ExclPID2 and PenaltyPlayer ~= ExclPID3 and PenaltyPlayer ~= ExclPID4 and PenaltyPlayer ~= ExclPID5 and PenaltyPlayer ~= ExclPID6 then
					PenaltySet = 1
					CurrentTime = Launcher.Game.Time()
					ExclPID1Time = ExclPID1Time - CurrentTime
					ExclPID2Time = ExclPID2Time - CurrentTime
					ExclPID3Time = ExclPID3Time - CurrentTime
					ExclPID4Time = ExclPID4Time - CurrentTime
					ExclPID5Time = ExclPID5Time - CurrentTime
					ExclPID6Time = ExclPID6Time - CurrentTime
					if ExclPID1Time > 360 then
						ExclPID1 = -1
						ExclPID1Time = CurrentTime
					end
					if ExclPID2Time > 360 then
						ExclPID2 = -1
						ExclPID2Time = CurrentTime
					end
					if ExclPID3Time > 360 then
						ExclPID3 = -1
						ExclPID3Time = CurrentTime
					end
					if ExclPID4Time > 360 then
						ExclPID4 = -1
						ExclPID4Time = CurrentTime
					end
					if ExclPID5Time > 360 then
						ExclPID5 = -1
						ExclPID5Time = CurrentTime
					end
					if ExclPID6Time > 360 then
						ExclPID6 = -1
						ExclPID6Time = CurrentTime
					end
				end
			until PenaltySet == 1
			RandPenalty = math.random (21,45)
			if RandPenalty == 33 or (RandPenalty > 37 and RandPenalty < 43) then
				RandPenalty = math.random (21,29)
			end
			if CoincidentalPenaltyTeam == 0 then
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, PenaltyPlayer)
				Launcher.Game.SetPenaltyPendingID(RandPenalty)
				Launcher.Game.SetPenaltyPendingTime(2)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			else
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, PenaltyPlayer)
				Launcher.Game.SetPenaltyPendingID(RandPenalty)
				Launcher.Game.SetPenaltyPendingTime(2)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			end
			if ExclPID1 == -1 then
				ExclPID1 = PenaltyPlayer
			elseif ExclPID2 == -1 then
				ExclPID2 = PenaltyPlayer
			elseif ExclPID3 == -1 then
				ExclPID3 = PenaltyPlayer
			elseif ExclPID4 == -1 then
				ExclPID4 = PenaltyPlayer
			elseif ExclPID5 == -1 then
				ExclPID5 = PenaltyPlayer
			else
				ExclPID6 = PenaltyPlayer
			end
			CoincidentalMinor = 0
			ScriptedPending = 1
-- This creates a long 5-on-3 situation if that option is enabled
		elseif L5on3 > 0 and AdditionalPenalties == true and Long5on3 == true then
			PenaltySet = 0
			repeat
				PenaltyPlayer = math.random (0,17)
				if PenaltyPlayer ~= ExclPID1 and PenaltyPlayer ~= ExclPID2 and PenaltyPlayer ~= ExclPID3 and PenaltyPlayer ~= ExclPID4 and PenaltyPlayer ~= ExclPID5 and PenaltyPlayer ~= ExclPID6 and PenaltyPlayer ~= 18 and PenaltyPlayer ~= 19 then
					PenaltySet = 1
					CurrentTime = Launcher.Game.Time()
					ExclPID1Time = ExclPID1Time - CurrentTime
					ExclPID2Time = ExclPID2Time - CurrentTime
					ExclPID3Time = ExclPID3Time - CurrentTime
					ExclPID4Time = ExclPID4Time - CurrentTime
					ExclPID5Time = ExclPID5Time - CurrentTime
					ExclPID6Time = ExclPID6Time - CurrentTime
					if ExclPID1Time > 360 then
						ExclPID1 = -1
						ExclPID1Time = CurrentTime
					end
					if ExclPID2Time > 360 then
						ExclPID2 = -1
						ExclPID2Time = CurrentTime
					end
					if ExclPID3Time > 360 then
						ExclPID3 = -1
						ExclPID3Time = CurrentTime
					end
					if ExclPID4Time > 360 then
						ExclPID4 = -1
						ExclPID4Time = CurrentTime
					end
					if ExclPID5Time > 360 then
						ExclPID5 = -1
						ExclPID5Time = CurrentTime
					end
					if ExclPID6Time > 360 then
						ExclPID6 = -1
						ExclPID6Time = CurrentTime
					end
				end
			until PenaltySet == 1
			RandPenalty = math.random (21,45)
			if RandPenalty == 33 or (RandPenalty > 37 and RandPenalty < 43) then
				RandPenalty = math.random (21,29)
			end
			if L5on3PenaltyTeam == 0 then
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, PenaltyPlayer)
				Launcher.Game.SetPenaltyPendingID(RandPenalty)
				Launcher.Game.SetPenaltyPendingTime(2)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			else
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, PenaltyPlayer)
				Launcher.Game.SetPenaltyPendingID(RandPenalty)
				Launcher.Game.SetPenaltyPendingTime(2)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			end
			if ExclPID1 == -1 then
				ExclPID1 = PenaltyPlayer
			elseif ExclPID2 == -1 then
				ExclPID2 = PenaltyPlayer
			elseif ExclPID3 == -1 then
				ExclPID3 = PenaltyPlayer
			elseif ExclPID4 == -1 then
				ExclPID4 = PenaltyPlayer
			elseif ExclPID5 == -1 then
				ExclPID5 = PenaltyPlayer
			else
				ExclPID6 = PenaltyPlayer
			end
			L5on3 = 0
			ScriptedPending = 1
-- If there was no coincidental minor or 5-on-3 situation, check to see if there is a Major for Checking From Behind with a Game Misconduct penalty
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and MajorPenalties == true and Misconducts == true and MajorTrigger == 1 and Majors == 0 then
			RandomPenalty = math.random()
			if RandomPenalty < MajorMisconduct then
				Majors = 1
				if BigHitPlayer < 20 then
					MajorHomePlayer = BigHitPlayer
					MajorAwayPlayer = -1
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(30)
					Launcher.Game.SetPenaltyPendingTime(8)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
					AwayFixPending = 1
					AwayFixGoals = Launcher.Stats.AwayGoals()
				else
					BigHitPlayer = BigHitPlayer - 20
					MajorAwayPlayer = BigHitPlayer
					MajorHomePlayer = -1
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(30)
					Launcher.Game.SetPenaltyPendingTime(8)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
					HomeFixPending = 1
					HomeFixGoals = Launcher.Stats.HomeGoals()
				end
				CurrentTime = Launcher.Game.Time()
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = BigHitPlayer
				elseif ExclPID2 == -1 then
					ExclPID2 = BigHitPlayer
				elseif ExclPID3 == -1 then
					ExclPID3 = BigHitPlayer
				elseif ExclPID4 == -1 then
					ExclPID4 = BigHitPlayer
				elseif ExclPID5 == -1 then
					ExclPID5 = BigHitPlayer
				else
					ExclPID6 = BigHitPlayer
				end
				Launcher.Game.StopPlay()
			end
-- If no Major with a Game Misconduct was called, check to see if there is a Major penalty for Checking From Behind
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and MajorPenalties == true and MajorTrigger == 2 and Majors == 0 then
			RandomPenalty = math.random()
			if RandomPenalty < MajorChance then
				Majors = 3
				if BigHitPlayer < 20 then
					MajorHomePlayer = BigHitPlayer
					MajorAwayPlayer = -1
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(30)
					Launcher.Game.SetPenaltyPendingTime(8)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
					AwayFixPending = 1
					AwayFixGoals = Launcher.Stats.AwayGoals()
				else
					BigHitPlayer = BigHitPlayer - 20
					MajorAwayPlayer = BigHitPlayer
					MajorHomePlayer = -1
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(30)
					Launcher.Game.SetPenaltyPendingTime(8)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
					HomeFixPending = 1
					HomeFixGoals = Launcher.Stats.HomeGoals()
				end
				CurrentTime = Launcher.Game.Time()
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = BigHitPlayer
				elseif ExclPID2 == -1 then
					ExclPID2 = BigHitPlayer
				elseif ExclPID3 == -1 then
					ExclPID3 = BigHitPlayer
				elseif ExclPID4 == -1 then
					ExclPID4 = BigHitPlayer
				elseif ExclPID5 == -1 then
					ExclPID5 = BigHitPlayer
				else
					ExclPID6 = BigHitPlayer
				end
				ScriptedPending = 1
			end
-- If there were no Major penalties called, check to see if there is a Double Minor for High Sticking
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and DoubleMinorPenalties == true and Checking >= 2 and DMCount == 0 then
			RandomPenalty = math.random()
			if RandomPenalty > DoubleMinorChance then
				DMCount = 1
				if BigHitPlayer < 20 then
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(28)
					Launcher.Game.SetPenaltyPendingTime(4)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					BigHitPlayer = BigHitPlayer - 20
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(28)
					Launcher.Game.SetPenaltyPendingTime(4)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
				CurrentTime = Launcher.Game.Time()
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = BigHitPlayer
				elseif ExclPID2 == -1 then
					ExclPID2 = BigHitPlayer
				elseif ExclPID3 == -1 then
					ExclPID3 = BigHitPlayer
				elseif ExclPID4 == -1 then
					ExclPID4 = BigHitPlayer
				elseif ExclPID5 == -1 then
					ExclPID5 = BigHitPlayer
				else
					ExclPID6 = BigHitPlayer
				end
				ScriptedPending = 1
			end
-- If there were no Major or Double Minor penalties called, check to see if there is a Roughing call with a Game Misconduct
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and Misconducts == true and Checking >= 2 and MisconductPenalty == 0 then
			RandomPenalty = math.random()
			if RandomPenalty > RoughingMisconduct then
				if BigHitPlayer < 20 then
					MajorHomePlayer = BigHitPlayer
					MajorAwayPlayer = -1
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(23)
					Launcher.Game.SetPenaltyPendingTime(2)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					BigHitPlayer = BigHitPlayer - 20
					MajorAwayPlayer = BigHitPlayer
					MajorHomePlayer = -1
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(23)
					Launcher.Game.SetPenaltyPendingTime(2)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
				CurrentTime = Launcher.Game.Time()
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = BigHitPlayer
				elseif ExclPID2 == -1 then
					ExclPID2 = BigHitPlayer
				elseif ExclPID3 == -1 then
					ExclPID3 = BigHitPlayer
				elseif ExclPID4 == -1 then
					ExclPID4 = BigHitPlayer
				elseif ExclPID5 == -1 then
					ExclPID5 = BigHitPlayer
				else
					ExclPID6 = BigHitPlayer
				end
				MisconductPenalty = 1
			 	Launcher.Game.StopPlay()
			end
-- If there were no Major or Double Minor penalties called, check to see if there is a Roughing call with the chance of a Game Misconduct
		elseif BigHitPlayer >= 0 and CurrentHitCount > 3 and BigHits == true and AdditionalPenalties == true and RoughingPenalty == true and Misconducts == true then
			if BigHitPlayer < 20 then
				MajorHomePlayer = BigHitPlayer
				MajorAwayPlayer = -1
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
				Launcher.Game.SetPenaltyPendingID(23)
				Launcher.Game.SetPenaltyPendingTime(2)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			else
				BigHitPlayer = BigHitPlayer - 20
				MajorAwayPlayer = BigHitPlayer
				MajorHomePlayer = -1
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
				Launcher.Game.SetPenaltyPendingID(23)
				Launcher.Game.SetPenaltyPendingTime(2)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			end
			CurrentTime = Launcher.Game.Time()
			ExclPID1Time = ExclPID1Time - CurrentTime
			ExclPID2Time = ExclPID2Time - CurrentTime
			ExclPID3Time = ExclPID3Time - CurrentTime
			ExclPID4Time = ExclPID4Time - CurrentTime
			ExclPID5Time = ExclPID5Time - CurrentTime
			ExclPID6Time = ExclPID6Time - CurrentTime
			if ExclPID1Time > 360 then
				ExclPID1 = -1
				ExclPID1Time = CurrentTime
			end
			if ExclPID2Time > 360 then
				ExclPID2 = -1
				ExclPID2Time = CurrentTime
			end
			if ExclPID3Time > 360 then
				ExclPID3 = -1
				ExclPID3Time = CurrentTime
			end
			if ExclPID4Time > 360 then
				ExclPID4 = -1
				ExclPID4Time = CurrentTime
			end
			if ExclPID5Time > 360 then
				ExclPID5 = -1
				ExclPID5Time = CurrentTime
			end
			if ExclPID6Time > 360 then
				ExclPID6 = -1
				ExclPID6Time = CurrentTime
			end
			if ExclPID1 == -1 then
				ExclPID1 = BigHitPlayer
			elseif ExclPID2 == -1 then
				ExclPID2 = BigHitPlayer
			elseif ExclPID3 == -1 then
				ExclPID3 = BigHitPlayer
			elseif ExclPID4 == -1 then
				ExclPID4 = BigHitPlayer
			elseif ExclPID5 == -1 then
				ExclPID5 = BigHitPlayer
			else
				ExclPID6 = BigHitPlayer
			end
			if MisconductPenalty == 0 then
				RandomMisconduct = math.random ()
				if RandomMisconduct > 0.85 then
					MisconductPenalty = 1
					Launcher.Game.StopPlay()
				else
					ScriptedPending = 1
				end
			else
				ScriptedPending = 1
			end
-- Lastly, check to see if there is a Roughing penalty
		elseif BigHitPlayer >= 0 and BigHits == true and AdditionalPenalties == true and RoughingPenalty == true then
			RandomPenalty = math.random()
			if RandomPenalty < RoughingChance then
				if BigHitPlayer < 20 then
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(23)
					Launcher.Game.SetPenaltyPendingTime(2)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					BigHitPlayer = BigHitPlayer - 20
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, BigHitPlayer)
					Launcher.Game.SetPenaltyPendingID(23)
					Launcher.Game.SetPenaltyPendingTime(2)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
				CurrentTime = Launcher.Game.Time()
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = BigHitPlayer
				elseif ExclPID2 == -1 then
					ExclPID2 = BigHitPlayer
				elseif ExclPID3 == -1 then
					ExclPID3 = BigHitPlayer
				elseif ExclPID4 == -1 then
					ExclPID4 = BigHitPlayer
				elseif ExclPID5 == -1 then
					ExclPID5 = BigHitPlayer
				else
					ExclPID6 = BigHitPlayer
				end
				ScriptedPending = 1
			end
		end
-- This resets the Checking attribute if it was just in play for a big hit
		if CheckingTweak == true and Checking > 1 then
			Checking = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(11,Checking,0,true)
			Checking = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(11,Checking,1,true)
		end
	end
end
function PenaltyPendingCallback()
-- This keeps track of which players are in the penalty box to avoid accidental duplicates
	PenaltyTeam = Launcher.Game.PenaltyPendingTeam()
	PPPlayer = Launcher.Game.PenaltyPendingPlayer()
	CurrentTime = Launcher.Game.Time()
	ExclPID1Time = ExclPID1Time - CurrentTime
	ExclPID2Time = ExclPID2Time - CurrentTime
	ExclPID3Time = ExclPID3Time - CurrentTime
	ExclPID4Time = ExclPID4Time - CurrentTime
	ExclPID5Time = ExclPID5Time - CurrentTime
	ExclPID6Time = ExclPID6Time - CurrentTime
	if ExclPID1Time > 360 then
		ExclPID1 = -1
		ExclPID1Time = CurrentTime
	end
	if ExclPID2Time > 360 then
		ExclPID2 = -1
		ExclPID2Time = CurrentTime
	end
	if ExclPID3Time > 360 then
		ExclPID3 = -1
		ExclPID3Time = CurrentTime
	end
	if ExclPID4Time > 360 then
		ExclPID4 = -1
		ExclPID4Time = CurrentTime
	end
	if ExclPID5Time > 360 then
		ExclPID5 = -1
		ExclPID5Time = CurrentTime
	end
	if ExclPID6Time > 360 then
		ExclPID6 = -1
		ExclPID6Time = CurrentTime
	end
	if PPPlayer > 19 then
		PPPlayer = PPPlayer - 20
	end
	if ExclPID1 == -1 then
		ExclPID1 = PPPlayer
	elseif ExclPID2 == -1 then
		ExclPID2 = PPPlayer
	elseif ExclPID3 == -1 then
		ExclPID3 = PPPlayer
	elseif ExclPID4 == -1 then
		ExclPID4 = PPPlayer
	elseif ExclPID5 == -1 then
		ExclPID5 = PPPlayer
	else
		ExclPID6 = PPPlayer
	end
-- This triggers the chance of a scripted coincidental minor penalty being called if that option is enabled
    if AdditionalPenalties == true and CoincidentalMinors == true then
		RandomPenalty = math.random()
		if RandomPenalty < 0.075 then
			if PenaltyTeam == 0 then
				CoincidentalPenaltyTeam = 1
			else
				CoincidentalPenaltyTeam = 0
			end
			CoincidentalMinor = 1
		end
	end
-- This triggers the chance of a scripted penalty being called against the same team right after the first penalty, creating a long 5-on-3 situation if that option is enabled
    if AdditionalPenalties == true and Long5on3 == true and CoincidentalMinor == 0 then
		RandomPenalty = math.random()
		if RandomPenalty > 0.95 then
			if PenaltyTeam == 0 then
				L5on3PenaltyTeam = 0
			else
				L5on3PenaltyTeam = 1
			end
			L5on3 = 1
		end
	end
end
function PeriodStartedCallback()
-- This resets the physics values to default at the start of each period
	if DeterioratingIce == true then
		Launcher.Physics.SetPuckBounceFriction(StartPuckBounceFriction)
		Launcher.Physics.SetPuckBoardBounceFriction(StartPuckBoardBounceFriction)
		Launcher.Physics.SetPlayerSpeedEnergyMultiplier(StartEnergyMultiplier)
		PuckBounceFriction = Launcher.Mem.Float(0x79C768)
		PuckBoardBounceFriction = Launcher.Mem.Float(0x79C76C)
		Launcher.Physics.SetPuckGravity(StartPuckGravity)
		Launcher.Physics.SetPassBaseSpeed(StartPassSpeed)
	end
	if PlayerSpeedTweak == true then
		Launcher.Physics.SetPlayerSpeedMultiplier(0.62)
	end
-- This resets parameters relating to penalties
	BigHitPlayer = -1
	CurrentHitCount = 0
	CoincidentalMinor = 0
	ScriptedPending = 0
	LastIcingTeam = -1
	LastIcing = 1200
	ExclPID1Time = 1200
	ExclPID2Time = 1200
	ExclPID3Time = 1200
	ExclPID4Time = 1200
	ExclPID5Time = 1200
	ExclPID6Time = 1200
	if Launcher.Game.Period() == 4 and (Launcher.GameOption.OTMode() == 3 or Launcher.GameOption.OTMode() == 4) then
		ExclPID1Time = 300
		ExclPID2Time = 300
		ExclPID3Time = 300
		ExclPID4Time = 300
		ExclPID5Time = 300
		ExclPID6Time = 300
	end
end
function PlayStoppedCallback(Reason)
-- This resets the enforcement of a missed shot if the "ShotFlow" option is set to true
	if ShotFlow == true then
		ForceMissed = 0
	end
-- This pauses the WildShot system until the next face-off if that option is set to true
	if WildShot == true then
		WildShotPause = true
	end
-- This sets the parameters to trigger sending the line that iced the puck back onto the ice if the "IcingLineManagement" option is set to true
	if Reason == LauncherPlayStoppedIcing and IcingLineManagement == true and PPT == 0 then
		SetIcingLine = 1
		IcingPlayer = Launcher.Game.PlayerWithPuck()
	end
-- This negates a pending scripted penalty if a goal was scored
	if (Reason == LauncherPlayStoppedGoalAway or Reason == LauncherPlayStoppedGoalHome) and ScriptedPending == 1 then
		ScriptedPending = 0
	end
-- This handles the random chance of a goaltender suffering a simulated in-game injury
	if OnlinePlay == false and GoalieInjuries == true and Diagnosis == 0 and Launcher.Game.Period() > 1 and Launcher.Game.Period() < 4 and Reason == LauncherPlayStoppedGoalie then
		InjuredGoalieChance = math.random ()
		if InjuredGoalieChance < 0.05 or GoalieInjuryLikely == true then
			InjuredGoalie = math.random (0, 39)
			if (InjuredGoalie == 18 and (Launcher.Game.PlayerWithPuck() == 18 or Launcher.Game.PlayerWithPuck() == 19)) or (InjuredGoalie == 38 and (Launcher.Game.PlayerWithPuck() == 38 or Launcher.Game.PlayerWithPuck() == 39)) then
				if InjuredGoalie == 18 and (Launcher.Player.ShotsAgainst(18) == 0 or Launcher.Player.ShotsAgainst(19) == 0) then
					HomeGoalieInjured = 1
					GoalieInjuryLikely = false
					if Launcher.Player.ShotsAgainst(18) == 0 then
						os.execute('start cmd /k echo ' .. Launcher.Player.FirstName(19) .. ' ' .. Launcher.Player.LastName(19) .. ' is injured.  His performance will be reduced.  Recommend substituting him for the backup.')
						for attributecount =0, 16 do
							Pointer = Launcher.Mem.Long(0x79C310+19*4) + 0x7C + attributecount
							Value = players[19] [attributecount]
							PerformanceLoss = math.random ()
							if PerformanceLoss > 0.5 then
								PerformanceLoss = PerformanceLoss - 0.5
							end
							NewValue = Value * PerformanceLoss
							NewValue = math.floor (NewValue)
							Launcher.Mem.WriteByte(Pointer, NewValue)
							players[19] [attributecount] = NewValue
						end
						if GoalieDiagnosis == true then
							Diagnosis = 1
							GoalieFName = Launcher.Player.FirstName(19)
							GoalieLName = Launcher.Player.LastName(19)
							if Launcher.Game.Period() == 3 and Launcher.Game.Time() < 300 then
								Whistles = 1
							else
								Whistles = math.random (10, 25)
							end
						end
					else
						os.execute('start cmd /k echo ' .. Launcher.Player.FirstName(18) .. ' ' .. Launcher.Player.LastName(18) .. ' is injured.  His performance will be reduced.  Recommend substituting him for the backup.')
						for attributecount =0, 16 do
							Pointer = Launcher.Mem.Long(0x79C310+18*4) + 0x7C + attributecount
							Value = players[18] [attributecount]
							PerformanceLoss = math.random ()
							if PerformanceLoss > 0.5 then
								PerformanceLoss = PerformanceLoss - 0.5
							end
							NewValue = Value * PerformanceLoss
							NewValue = math.floor (NewValue)
							Launcher.Mem.WriteByte(Pointer, NewValue)
							players[18] [attributecount] = NewValue
						end
						if GoalieDiagnosis == true then
							Diagnosis = 1
							GoalieFName = Launcher.Player.FirstName(18)
							GoalieLName = Launcher.Player.LastName(18)
							if Launcher.Game.Period() == 3 and Launcher.Game.Time() < 300 then
								Whistles = 1
							else
								Whistles = math.random (10, 25)
							end
						end
					end
				elseif InjuredGoalie == 38 and (Launcher.Player.ShotsAgainst(38) == 0 or Launcher.Player.ShotsAgainst(39) == 0) then
					AwayGoalieInjured = 1
					GoalieInjuryLikely = false
					if Launcher.Player.ShotsAgainst(38) == 0 then
						os.execute('start cmd /k echo ' .. Launcher.Player.FirstName(39) .. ' ' .. Launcher.Player.LastName(39) .. ' is injured.  His performance will be reduced.  Recommend substituting him for the backup.')
						for attributecount =0, 16 do
							Pointer = Launcher.Mem.Long(0x79C310+39*4) + 0x7C + attributecount
							Value = players[39] [attributecount]
							PerformanceLoss = math.random ()
							if PerformanceLoss > 0.5 then
								PerformanceLoss = PerformanceLoss - 0.5
							end
							NewValue = Value * PerformanceLoss
							NewValue = math.floor (NewValue)
							Launcher.Mem.WriteByte(Pointer, NewValue)
							players[39] [attributecount] = NewValue
						end
						if GoalieDiagnosis == true then
							Diagnosis = 1
							GoalieFName = Launcher.Player.FirstName(39)
							GoalieLName = Launcher.Player.LastName(39)
							if Launcher.Game.Period() == 3 and Launcher.Game.Time() < 300 then
								Whistles = 1
							else
								Whistles = math.random (10, 25)
							end
						end
					else
						os.execute('start cmd /k echo ' .. Launcher.Player.FirstName(38) .. ' ' .. Launcher.Player.LastName(38) .. ' is injured.  His performance will be reduced.  Recommend substituting him for the backup.')
						for attributecount =0, 16 do
							Pointer = Launcher.Mem.Long(0x79C310+38*4) + 0x7C + attributecount
							Value = players[38] [attributecount]
							PerformanceLoss = math.random ()
							if PerformanceLoss > 0.5 then
								PerformanceLoss = PerformanceLoss - 0.5
							end
							NewValue = Value * PerformanceLoss
							NewValue = math.floor (NewValue)
							Launcher.Mem.WriteByte(Pointer, NewValue)
							players[38] [attributecount] = NewValue
						end
						if GoalieDiagnosis == true then
							Diagnosis = 1
							GoalieFName = Launcher.Player.FirstName(38)
							GoalieLName = Launcher.Player.LastName(38)
							if Launcher.Game.Period() == 3 and Launcher.Game.Time() < 300 then
								Whistles = 1
							else
								Whistles = math.random (10, 25)
							end
						end
					end
				end
			end
		end
	end
-- This sets up the major Delay of Game penalties in preparation for the hybrid 3-on-3 OT if that option is active
	if ThreeonThreeOT == true and Launcher.Game.Period() == 3 and Launcher.Game.Time() == 0 and Launcher.Stats.HomeGoals() == Launcher.Stats.AwayGoals() then
		if ThreeonThree == 0 then
			HomePlayerSet = 0
			HomePlayerToSit = 17
			repeat
				if HomePlayerToSit ~= ExclPID1 and HomePlayerToSit ~= ExclPID2 and HomePlayerToSit ~= ExclPID3 and HomePlayerToSit ~= ExclPID4 and HomePlayerToSit ~= ExclPID5 and HomePlayerToSit ~= ExclPID6 then 
					HomePlayerSet = 1
					if ExclPID1 == -1 then
						ExclPID1 = HomePlayerToSit
					elseif ExclPID2 == -1 then
						ExclPID2 = HomePlayerToSit
					elseif ExclPID3 == -1 then
						ExclPID3 = HomePlayerToSit
					elseif ExclPID4 == -1 then
						ExclPID4 = HomePlayerToSit
					elseif ExclPID5 == -1 then
						ExclPID5 = HomePlayerToSit
					else
						ExclPID6 = HomePlayerToSit
					end
				else
					HomePlayerToSit = HomePlayerToSit - 1
				end
			until HomePlayerSet == 1
			Launcher.Mem.WriteByte(0x79b3f4, 0)
			Launcher.Mem.WriteByte(0x79b3f5, HomePlayerToSit)
			Launcher.Game.SetPenaltyPendingID(42)
			Launcher.Game.SetPenaltyPendingTime(8)
			Launcher.Mem.WriteByte(0x79B9BC, 1)
			AdditionalPenalties = false
			ThreeonThree = 1
		elseif ThreeonThree == 2 then
			AwayPlayerSet = 0
			AwayPlayerToSit = 17
			repeat
				if AwayPlayerToSit ~= ExclPID1 and AwayPlayerToSit ~= ExclPID2 and AwayPlayerToSit ~= ExclPID3 and AwayPlayerToSit ~= ExclPID4 and AwayPlayerToSit ~= ExclPID5 and AwayPlayerToSit ~= ExclPID6 then 
					AwayPlayerSet = 1
					if ExclPID1 == -1 then
						ExclPID1 = AwayPlayerToSit
					elseif ExclPID2 == -1 then
						ExclPID2 = AwayPlayerToSit
					elseif ExclPID3 == -1 then
						ExclPID3 = AwayPlayerToSit
					elseif ExclPID4 == -1 then
						ExclPID4 = AwayPlayerToSit
					elseif ExclPID5 == -1 then
						ExclPID5 = AwayPlayerToSit
					else
						ExclPID6 = AwayPlayerToSit
					end
				else
					AwayPlayerToSit = AwayPlayerToSit - 1
				end
			until AwayPlayerSet == 1
			Launcher.Mem.WriteByte(0x79b3f4, 1)
			Launcher.Mem.WriteByte(0x79b3f5, AwayPlayerToSit)
			Launcher.Game.SetPenaltyPendingID(42)
			Launcher.Game.SetPenaltyPendingTime(8)
			Launcher.Mem.WriteByte(0x79B9BC, 1)
			ThreeonThree = 3
		end
	end
-- This pauses the game and opens a command prompt, reminding the user to check the Shootout lines to avoid a game crash
	if SOAfterOT == true and ThreeonThree == 3 and Launcher.Game.Period() == 4 and Reason ~= LauncherPlayStoppedGameOver then
		ThreeonThree = 4
		os.execute('start cmd /k echo Check the Shootout lines for BOTH TEAMS to see if the players in the box are on them -- if so, change them or the game will crash.')
	end
-- This transitions to a shootout after the 3-on-3 OT if that option is enabled
	if ThreeonThreeOT == true and Launcher.GameOption.OTMode() ~= 5 and SOAfterOT == true and Launcher.Game.Period() == 4 and Launcher.Game.Time() == 0.0 and Reason ~= LauncherPlayStoppedIcing and Reason ~= LauncherPlayStoppedOffside and Launcher.Stats.HomeGoals() == Launcher.Stats.AwayGoals() then
		Launcher.Game.SetPeriod(0)
		AdditionalPenalties = false
	end
-- These are scripted penalties related to stoppages in play that will randomly come into effect if they are enabled
	if AdditionalPenalties == true then
		CurrentTime = Launcher.Game.Time()
-- This penalizes the player who sent the puck out of play if the "DelayPenalty" option is enabled
		if DelayPenalty == true and OnlinePlay == false and DelayPenaltySet == 1 then
			StopforDelay = 0
			DelayPenaltySet = 0
			ExclPID1Time = ExclPID1Time - CurrentTime
			ExclPID2Time = ExclPID2Time - CurrentTime
			ExclPID3Time = ExclPID3Time - CurrentTime
			ExclPID4Time = ExclPID4Time - CurrentTime
			ExclPID5Time = ExclPID5Time - CurrentTime
			ExclPID6Time = ExclPID6Time - CurrentTime
			if ExclPID1Time > 360 then
				ExclPID1 = -1
				ExclPID1Time = CurrentTime
			end
			if ExclPID2Time > 360 then
				ExclPID2 = -1
				ExclPID2Time = CurrentTime
			end
			if ExclPID3Time > 360 then
				ExclPID3 = -1
				ExclPID3Time = CurrentTime
			end
			if ExclPID4Time > 360 then
				ExclPID4 = -1
				ExclPID4Time = CurrentTime
			end
			if ExclPID5Time > 360 then
				ExclPID5 = -1
				ExclPID5Time = CurrentTime
			end
			if ExclPID6Time > 360 then
				ExclPID6 = -1
				ExclPID6Time = CurrentTime
			end
			if ExclPID1 == -1 then
				ExclPID1 = PlayerPenalty
			elseif ExclPID2 == -1 then
				ExclPID2 = PlayerPenalty
			elseif ExclPID3 == -1 then
				ExclPID3 = PlayerPenalty
			elseif ExclPID4 == -1 then
				ExclPID4 = PlayerPenalty
			elseif ExclPID5 == -1 then
				ExclPID5 = PlayerPenalty
			else
				ExclPID6 = PlayerPenalty
			end
			if PlayerPenalty > 19 then
				PlayerPenalty = PlayerPenalty - 20
			end
			if Launcher.Game.TeamWithPuck() == 0 then
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
				Launcher.Game.SetPenaltyPendingID(42)
				Launcher.Game.SetPenaltyPendingTime(2)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			else
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
				Launcher.Game.SetPenaltyPendingID(42)
				Launcher.Game.SetPenaltyPendingTime(2)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
			end
		elseif Reason == LauncherPlayStoppedIcing and IcingPenalty == true then
-- This penalizes a team if they commit back-to-back icings within a short period of time if the "IcingPenalty" option is enabled
			LastIcing = LastIcing - CurrentTime
			if LastIcing <= 60 and LastIcingTeam == Launcher.Game.TeamWithPuck() then
				if NoTouchIcing == false then
					PlayerPenalty = 17
					PenaltySet = 0
					repeat
						if PlayerPenalty ~= ExclPID1 and PlayerPenalty ~= ExclPID2 and PlayerPenalty ~= ExclPID3 and PlayerPenalty ~= ExclPID4 and PlayerPenalty ~= ExclPID5 and PlayerPenalty ~= ExclPID6 then 
							PenaltySet = 1
						else
							PlayerPenalty = PlayerPenalty - 1
						end
					until PenaltySet == 1
				else
					PlayerPenalty = Launcher.Game.PlayerWithPuck()
				end
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = PlayerPenalty
				elseif ExclPID2 == -1 then
					ExclPID2 = PlayerPenalty
				elseif ExclPID3 == -1 then
					ExclPID3 = PlayerPenalty
				elseif ExclPID4 == -1 then
					ExclPID4 = PlayerPenalty
				elseif ExclPID5 == -1 then
					ExclPID5 = PlayerPenalty
				else
					ExclPID6 = PlayerPenalty
				end
				if PlayerPenalty > 19 then
					PlayerPenalty = PlayerPenalty - 20
				end
				if Launcher.Game.TeamWithPuck() == 0 then
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(42)
					Launcher.Game.SetPenaltyPendingTime(2)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(42)
					Launcher.Game.SetPenaltyPendingTime(2)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
			end
			LastIcing = CurrentTime
			LastIcingTeam = Launcher.Game.TeamWithPuck()
		elseif Reason == LauncherPlayStoppedFight and InstigatorPenalty == true then
-- This randomly puts one of the two fighters in the box with a Fight Instigator penalty if the "InstigatorPenalty" option is enabled
			RandomPenaltyChance = math.random ()
			if RandomPenaltyChance > 0.67 then
				RandomPenalty = math.random (0, 39)
				if RandomPenalty < 20 then
					PlayerPenalty = Launcher.Game.HomeFighter()
				else
					PlayerPenalty = Launcher.Game.AwayFighter()
				end
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if ExclPID1 == -1 then
					ExclPID1 = PlayerPenalty
				elseif ExclPID2 == -1 then
					ExclPID2 = PlayerPenalty
				elseif ExclPID3 == -1 then
					ExclPID3 = PlayerPenalty
				elseif ExclPID4 == -1 then
					ExclPID4 = PlayerPenalty
				elseif ExclPID5 == -1 then
					ExclPID5 = PlayerPenalty
				else
					ExclPID6 = PlayerPenalty
				end
				if RandomPenalty < 20 then
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(39)
					Launcher.Game.SetPenaltyPendingTime(2)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					PlayerPenalty = PlayerPenalty - 20
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(39)
					Launcher.Game.SetPenaltyPendingTime(2)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
			end
		elseif Reason == LauncherPlayStoppedPeriod and OfficialAbusePenalty == true then
-- This will randomly penalize one of the 40 dressed players to simulate them verbally abusing an official at the end of a period if the "OfficialAbusePenalty" option is enabled
			RandomPenaltyChance = math.random ()
			if RandomPenaltyChance > 0.98 then
				PlayerPenalty = math.random (0, 39)
				ExclPID1Time = ExclPID1Time - CurrentTime
				ExclPID2Time = ExclPID2Time - CurrentTime
				ExclPID3Time = ExclPID3Time - CurrentTime
				ExclPID4Time = ExclPID4Time - CurrentTime
				ExclPID5Time = ExclPID5Time - CurrentTime
				ExclPID6Time = ExclPID6Time - CurrentTime
				if ExclPID1Time > 360 then
					ExclPID1 = -1
					ExclPID1Time = CurrentTime
				end
				if ExclPID2Time > 360 then
					ExclPID2 = -1
					ExclPID2Time = CurrentTime
				end
				if ExclPID3Time > 360 then
					ExclPID3 = -1
					ExclPID3Time = CurrentTime
				end
				if ExclPID4Time > 360 then
					ExclPID4 = -1
					ExclPID4Time = CurrentTime
				end
				if ExclPID5Time > 360 then
					ExclPID5 = -1
					ExclPID5Time = CurrentTime
				end
				if ExclPID6Time > 360 then
					ExclPID6 = -1
					ExclPID6Time = CurrentTime
				end
				if PlayerPenalty < 20 then
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(40)
					Launcher.Game.SetPenaltyPendingTime(2)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					PlayerPenalty = PlayerPenalty - 20
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, PlayerPenalty)
					Launcher.Game.SetPenaltyPendingID(40)
					Launcher.Game.SetPenaltyPendingTime(2)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
				if ExclPID1 == -1 then
					ExclPID1 = PlayerPenalty
				elseif ExclPID2 == -1 then
					ExclPID2 = PlayerPenalty
				elseif ExclPID3 == -1 then
					ExclPID3 = PlayerPenalty
				elseif ExclPID4 == -1 then
					ExclPID4 = PlayerPenalty
				elseif ExclPID5 == -1 then
					ExclPID5 = PlayerPenalty
				else
					ExclPID6 = PlayerPenalty
				end
			end
		end
	end
-- This decides the fate of the injured goaltender if the "GoalieDiagnosis" option is enabled
	if GoalieDiagnosis == true and Diagnosis == 1 and (Reason ~= LauncherPlayStoppedGoalHome and Reason ~= LauncherPlayStoppedGoalAway) then
		Whistles = Whistles - 1
		if (PPT == 0 and Whistles <= 0) or (Launcher.Game.Period() == 3 and Launcher.Game.Time() < 180) then
			Whistles = 0
			InjuryNumber = math.random (7, 23)
			if InjuryNumber == 7 then
				InjuryType = "A BROKEN RIGHT FOOT"
			elseif InjuryNumber == 8 then
				InjuryType = "A SORE ANKLE"
			elseif InjuryNumber == 9 then
				InjuryType = "TORN KNEE CARTILAGE"
			elseif InjuryNumber == 10 then
				InjuryType = "A BRUISED QUADRICEP"
			elseif InjuryNumber == 11 then
				InjuryType = "A PULLED GROIN"
			elseif InjuryNumber == 12 then
				InjuryType = "A SORE HIP"
			elseif InjuryNumber == 13 then
				InjuryType = "AN ABDOMINAL TEAR"
			elseif InjuryNumber == 14 then
				InjuryType = "A STRAINED RIB MUSCLE"
			elseif InjuryNumber == 15 then
				InjuryType = "DISC SURGERY"
			elseif InjuryNumber == 16 then
				InjuryType = "SHOULDER CONTUSIONS"
			elseif InjuryNumber == 17 then
				InjuryType = "A LACERATED ARM"
			elseif InjuryNumber == 18 then
				InjuryType = "A SORE ELBOW"
			elseif InjuryNumber == 19 then
				InjuryType = "A BRUISED LEFT WRIST"
			elseif InjuryNumber == 20 then
				InjuryType = "A DISLOCATED RIGHT THUMB"
			elseif InjuryNumber == 21 then
				InjuryType = "WHIPLASH"
			elseif InjuryNumber == 22 then
				InjuryType = "A HEAD LACERATION"
			else
				InjuryType = "A MILD CONCUSSION"
			end
			InjuryLength = math.random (2, 10)
			if InjuryNumber == 7 or InjuryNumber == 15 then
				InjuryLength = 11
			elseif InjuryNumber == 8 or InjuryNumber == 12 or InjuryNumber == 18 then
				InjuryLength = 0
			elseif (InjuryNumber == 14 or InjuryNumber == 19 or InjuryNumber == 23) and InjuryLength < 5 then
				InjuryLength = 0
			elseif InjuryNumber == 14 or InjuryNumber == 19 or InjuryNumber == 23 then
				InjuryTime = " DAYS"
			else
				InjuryTime = " WEEKS"
			end
			if InjuryLength == 0 then
				os.execute('start cmd /k echo Injured Goalie Diagnosis: ' .. GoalieFName .. ' ' .. GoalieLName .. ' IS OUT FOR THE REMAINDER OF THIS GAME ONLY WITH ' .. InjuryType .. '.')
			elseif InjuryLength == 11 then
				os.execute('start cmd /k echo Injured Goalie Diagnosis: ' .. GoalieFName .. ' ' .. GoalieLName .. ' IS OUT FOR THE REMAINDER OF THE SEASON WITH ' .. InjuryType .. ' (Injury Number ' .. InjuryNumber .. ').')
			else
				os.execute('start cmd /k echo Injured Goalie Diagnosis: ' .. GoalieFName .. ' ' .. GoalieLName .. ' IS OUT FOR ' .. InjuryLength .. InjuryTime .. ' WITH ' .. InjuryType .. ' (Injury Number ' .. InjuryNumber .. ').')
			end
			if Launcher.Game.Period() == 3 and Launcher.Game.Time() < 600 then
				Diagnosis = 2
			else
				Diagnosis = 0
			end
		end
	end
end
function ShotAwayCallback()
-- This checks the current rate of shots on goal and sets the flag to force a missed shot if the shot totals are too high
	MissedHigh = 0
	if ShotFlow == true and ShotFlowPause == false and Launcher.Game.Period() ~= 0 and Launcher.Game.Period() < 4 then
		TotalShots = Launcher.Stats.AwayShots() + Launcher.Stats.HomeShots()
		CurrentTime = Launcher.Game.Time()
		if Launcher.Game.Period() == 1 then
			ElapsedTime = 1200 - CurrentTime
		elseif Launcher.Game.Period() == 2 then
			ElapsedTime = 2400 - CurrentTime
		else
			ElapsedTime = 3600 - CurrentTime
		end
		ShotRate = (TotalShots * 60) / ElapsedTime
		if ShotRate > ShotsPerMinute then
			startingx, y, startingz = Launcher.Game.PuckPosition()
			newz = startingz
			ForceMissed = 1
			ForceMissedTimer = Launcher.Game.Time()
			ForceMissedHigh = math.random ()
			if ForceMissedHigh < 0.25 then
				MissedHigh = 1
			end
		end
	end
-- This will occasionally produce a shot attempt by a visiting player that misses wildly if the "WildShot" option is enabled
	if ForceMissed == 0 and OnlinePlay == false and WildShot == true and WildShotPause == false then
		RandomWildShot = math.random ()
		if RandomWildShot > 0.83 then
			startingx, y, startingz = Launcher.Game.PuckPosition()
			newz = startingz
			RandomPower = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(4,RandomPower,1,true)
			ForceMissed = 1
			ForceMissedTimer = Launcher.Game.Time()
			ForceMissedHigh = math.random ()
			if ForceMissedHigh < 0.25 then
				MissedHigh = 1
			end
		end
	end
-- This will force the puck to go over the glass for a "Delay of Game" penalty if the conditions are met
	if Launcher.Game.PlayStopped() ~= 1 and Launcher.Game.Time() > 60 and OnlinePlay == false and AdditionalPenalties == true and DelayPenalty == true and PPT == 0 and (ClearingDelaysPerGame == 0 or TotalClearings < ClearingDelaysPerGame) then
		DelayofGameChance = math.random ()
		if DelayofGameChance < 0.05 then
			startingx, y, z = Launcher.Game.PuckPosition()
			newz = z
			DelayTimer = Launcher.Game.Time()
			if (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and z < -1450 and Launcher.Game.TeamWithPuck() == 1 then
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			elseif (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and z > 1450 and Launcher.Game.TeamWithPuck() == 0 then
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			elseif Launcher.Game.Period() == 2 and z > 1450 and Launcher.Game.TeamWithPuck() == 1 then
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			elseif Launcher.Game.Period() == 2 and z < -1450 and Launcher.Game.TeamWithPuck() == 0 then
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			end
		end
	end
end
function ShotHomeCallback()
-- This checks the current rate of shots on goal and sets the flag to force a missed shot if the shot totals are too high
	MissedHigh = 0
	if ShotFlow == true and ShotFlowPause == false and Launcher.Game.Period() ~= 0 and Launcher.Game.Period() < 4 then
		TotalShots = Launcher.Stats.AwayShots() + Launcher.Stats.HomeShots()
		CurrentTime = Launcher.Game.Time()
		if Launcher.Game.Period() == 1 then
			ElapsedTime = 1200 - CurrentTime
		elseif Launcher.Game.Period() == 2 then
			ElapsedTime = 2400 - CurrentTime
		else
			ElapsedTime = 3600 - CurrentTime
		end
		ShotRate = (TotalShots * 60) / ElapsedTime
		if ShotRate > ShotsPerMinute then
			startingx, y, startingz = Launcher.Game.PuckPosition()
			newz = startingz
			ForceMissed = 1
			ForceMissedTimer = Launcher.Game.Time()
			ForceMissedHigh = math.random ()
			if ForceMissedHigh < 0.25 then
				MissedHigh = 1
			end
		end
	end
-- This will occasionally produce a shot attempt by a home team player that misses wildly if the "WildShot" option is enabled
	if ForceMissed == 0 and OnlinePlay == false and WildShot == true and WildShotPause == false then
		RandomWildShot = math.random ()
		if RandomWildShot > 0.83 then
			startingx, y, startingz = Launcher.Game.PuckPosition()
			newz = startingz
			RandomPower = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(4,RandomPower,0,true)
			ForceMissed = 1
			ForceMissedTimer = Launcher.Game.Time()
			ForceMissedHigh = math.random ()
			if ForceMissedHigh < 0.25 then
				MissedHigh = 1
			end
		end
	end
-- This will force the puck to go over the glass for a "Delay of Game" penalty if the conditions are met
	if Launcher.Game.PlayStopped() ~= 1 and Launcher.Game.Time() > 60 and OnlinePlay == false and AdditionalPenalties == true and DelayPenalty == true and PPT == 0 and (ClearingDelaysPerGame == 0 or TotalClearings < ClearingDelaysPerGame) then
		DelayofGameChance = math.random ()
		if DelayofGameChance < 0.05 then
			startingx, y, z = Launcher.Game.PuckPosition()
			newz = z
			DelayTimer = Launcher.Game.Time()
			if (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and z < -1450 and Launcher.Game.TeamWithPuck() == 1 then
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			elseif (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) and z > 1450 and Launcher.Game.TeamWithPuck() == 0 then
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			elseif Launcher.Game.Period() == 2 and z > 1450 and Launcher.Game.TeamWithPuck() == 1 then
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			elseif Launcher.Game.Period() == 2 and z < -1450 and Launcher.Game.TeamWithPuck() == 0 then
				StopforDelay = 1
				TotalClearings = TotalClearings + 1
			end
		end
	end
end
function TickCallback()
-- This stops play if there is a script-initiated penalty pending
	if ScriptedPending == 1 then
		if (Launcher.Game.PenaltyPendingTeam() == 0 and Launcher.Game.TeamWithPuck() == 0) or (Launcher.Game.PenaltyPendingTeam() == 1 and Launcher.Game.TeamWithPuck() == 1) then
			ScriptedPending = 0
			Launcher.Game.StopPlay()
		end
	end
-- This handles whether or not to enforce a missed shot if the "ShotFlow" option is enabled
	if ForceMissed == 1 then
		CurrentTime = Launcher.Game.Time()
		ForcedLength = ForceMissedTimer - CurrentTime
		if (RealTime == false and ForcedLength > 3) or (RealTime == true and ForcedLength > 1) then
			ForceMissed = 0
		end
		CurrentShots = Launcher.Stats.AwayShots() + Launcher.Stats.HomeShots()
		if CurrentShots ~= TotalShots then
			ForceMissed = 0
		end
	end
	x, y, z = Launcher.Game.PuckPosition()
	if ForceMissed == 1 and (Launcher.Game.Period() == 1 or Launcher.Game.Period() == 3) then
		if (z < -1450 and Launcher.Game.TeamWithPuck() == 1) or (z > newz and Launcher.Game.TeamWithPuck() == 0) then
			ForceMissed = 0
		elseif (z > 1450 and Launcher.Game.TeamWithPuck() == 0) or (z < newz and Launcher.Game.TeamWithPuck() == 1) then
			ForceMissed = 0
		end
	elseif ForceMissed == 1 and Launcher.Game.Period() == 2 then
		if (z < -1450 and Launcher.Game.TeamWithPuck() == 0) or (z > newz and Launcher.Game.TeamWithPuck() == 1) then
			ForceMissed = 0
		elseif (z > 1450 and Launcher.Game.TeamWithPuck() == 1) or (z < newz and Launcher.Game.TeamWithPuck() == 0) then
			ForceMissed = 0
		end
	end
	if ForceMissed == 1 and ((z < 4550 and z > 1450) or (z > -4550 and z < -1450)) then
		if ((startingz < 2010 and startingz > 1450) or (startingz > -2010 and startingz < -1450)) then
			if MissedHigh == 1 then
				y = y + 10
			else
				if startingx <= 0 then
					x = x - 5
				else
					x = x + 5
				end
			end
		elseif ((startingz < 2455 and startingz > 1450) or (startingz > -2455 and startingz < -1450)) then
			if startingx <= 0 then
				x = x - 10
			else
				x = x + 10
			end
		elseif ((startingz < 2900 and startingz > 1450) or (startingz > -2900 and startingz < -1450)) then
			if startingx <= 0 then
				x = x - 15
			else
				x = x + 15
			end
		elseif ((startingz < 3345 and startingz > 1450) or (startingz > -3345 and startingz < -1450)) then
			if startingx <= 0 then
				x = x - 20
			else
				x = x + 20
			end
		elseif ((startingz < 3790 and startingz > 1450) or (startingz > -3790 and startingz < -1450)) then
			if startingx <= 0 then
				x = x - 25
			else
				x = x + 25
			end
		elseif ((startingz < 4000 and startingz > 1450) or (startingz > -4000 and startingz < -1450)) then
			if MissedHigh == 1 then
				y = y + 25
			else
				if startingx <= 0 then
					x = x - 30
				else
					x = x + 30
				end
			end
		end
		Launcher.Game.SetPuckPosition(x,y,z)
		newz = z
	else
		ForceMissed = 0
	end
-- This sends the puck out of play simulating the player clearing the puck over the glass if the "DelayPenalty" is set to true
	if StopforDelay == 1 then
		x, y, z = Launcher.Game.PuckPosition()
		ShotPower = 1
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,0,true)
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,1,true)
		if startingx <= 0 then
			x = x - 50
			y = y + 25
		else
			x = x + 50
			y = y + 25
		end
		Launcher.Game.SetPuckPosition(x,y,z)
		if DelayPenaltySet == 0 then
			DelayPenaltySet = 1
			PlayerPenalty = Launcher.Game.PlayerWithPuck()
		end
	end
end
function ZoneChangedCallback()
-- If an icing call just occurred, this forces the line that iced the puck back onto the ice if the "IcingLineManagement" option is enabled
	if SetIcingLine == 2 and IcingLineManagement == true and PPT == 0 then
		if IcingAwayLine == -1 then
			CurrentLine = Launcher.Game.HomeLine()
			if CurrentLine == IcingHomeLine then
				IcingHomeLine = -1
				SetIcingLine = 0
			else
				Launcher.Line.Set(0,IcingHomeLine)
			end
		else
			CurrentLine = Launcher.Game.AwayLine()
			if CurrentLine == IcingAwayLine then
				IcingAwayLine = -1
				SetIcingLine = 0
			else
				Launcher.Line.Set(1,IcingAwayLine)
			end
		end
	end
-- This assesses the pre-game Misconduct penalty if the "PreGamePenalty" option is set to true
	if AdditionalPenalties == true and Misconducts == true and PreGamePenalty == true and PreGamePenaltyPending == 0 then
		PreGamePenaltyPending = 1
		PreGameChance = math.random()
		if PreGameChance < 0.05 then
			PreGamePlayer = math.random (0, 39)
			if PreGameGoalies == false and (PreGamePlayer == 18 or PreGamePlayer == 19 or PreGamePlayer == 38 or PreGamePlayer == 39) then
				PreGamePenaltyPending = 2
			else
				if PreGamePlayer > 19 then
					PreGamePlayer = PreGamePlayer - 20
					Launcher.Mem.WriteByte(0x79b3f4, 1)
					Launcher.Mem.WriteByte(0x79b3f5, PreGamePlayer)
					Launcher.Game.SetPenaltyPendingID(41)
					Launcher.Game.SetPenaltyPendingTime(12)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				else
					Launcher.Mem.WriteByte(0x79b3f4, 0)
					Launcher.Mem.WriteByte(0x79b3f5, PreGamePlayer)
					Launcher.Game.SetPenaltyPendingID(41)
					Launcher.Game.SetPenaltyPendingTime(12)
					Launcher.Mem.WriteByte(0x79B9BC, 1)
				end
				MisconductPenalty = 3
				ExclPID6 = PreGamePlayer
				ExclPID6Time = -9999
				Launcher.Game.StopPlay()
			end
		end
	end
-- This resets the enforcement of a missed shot if the "ShotFlow" option is enabled
	if ShotFlow == true then
		ForceMissed = 0
	end
-- This will randomly vary the player's shot power and accuracy upon each offensive zone entry providing those tweaks are set to true
	if OnlinePlay == false and Launcher.Game.PuckZone() ~= 0 then
		KeeporTweak = math.random ()
		if PowerTweak == true and KeeporTweak > 0.5 then
			ShotPower = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,0,true)
			ShotPower = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,1,true)
		end
		KeeporTweak = math.random ()
		if AccuracyTweak == true and KeeporTweak > 0.5 then
			ShotAcc = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(5,ShotAcc,0,true)
			ShotAcc = math.random ()
			Launcher.Player.AllSetAttributeMultiplier(5,ShotAcc,1,true)
		end
	end
-- This checks for pending Major or Misconduct penalties
	if Majors == 1 then
		Majors = 2
	elseif MisconductPenalty == 1 then
		MisconductPenalty = 2
	end
	if Majors == 2 or MisconductPenalty == 2 then
-- This sets up the Game Misconduct penalty connected with the previous Major for Checking from Behind
		if MajorPenalties == true and Misconducts == true and Majors == 2 then
			if MajorHomePlayer >= 0 then
				FixAwayMisconduct = 1
				ExpectedAwayTotalPP = Launcher.Stats.AwayPowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, MajorHomePlayer)
				Launcher.Game.SetPenaltyPendingID(30)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
				ScriptedPending = 1
			else
				FixHomeMisconduct = 1
				ExpectedHomeTotalPP = Launcher.Stats.HomePowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, MajorAwayPlayer)
				Launcher.Game.SetPenaltyPendingID(30)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
				ScriptedPending = 1
			end
			Majors = 3
		end
-- This sets up the Game Misconduct penalty connected with the previous minor for Roughing
		if MajorPenalties == true and Misconducts == true and MisconductPenalty == 2 then
			if MajorHomePlayer >= 0 then
				FixAwayMisconduct = 1
				ExpectedAwayTotalPP = Launcher.Stats.AwayPowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 0)
				Launcher.Mem.WriteByte(0x79b3f5, MajorHomePlayer)
				Launcher.Game.SetPenaltyPendingID(23)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
				ScriptedPending = 1
			else
				FixHomeMisconduct = 1
				ExpectedHomeTotalPP = Launcher.Stats.HomePowerPlays() + 1
				Launcher.Mem.WriteByte(0x79b3f4, 1)
				Launcher.Mem.WriteByte(0x79b3f5, MajorAwayPlayer)
				Launcher.Game.SetPenaltyPendingID(23)
				Launcher.Game.SetPenaltyPendingTime(16)
				Launcher.Mem.WriteByte(0x79B9BC, 1)
				ScriptedPending = 1
			end
			MisconductPenalty = 3
		end
	end
-- This resets the strange bounce option if active
	if Launcher.Game.PuckZone() == 0 and DeterioratingIce == true then
		Launcher.Physics.SetPuckBoardBounceFriction(StartPuckBoardBounceFriction)
	end
-- This tweaks some skater and goalie abilities for each shot taken in a Shootout
	if Launcher.Game.Period() == 0 and OnlinePlay == false and ShootOutTweaks == true then
		Agility = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(2,Agility,0,false)
		Launcher.Player.AllSetAttributeMultiplier(2,Agility,1,false)
		Recovery = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(3,Recovery,0,false)
		Launcher.Player.AllSetAttributeMultiplier(3,Recovery,1,false)
		ShotPower = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,0,false)
		Launcher.Player.AllSetAttributeMultiplier(4,ShotPower,1,false)
		ShotAcc = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(5,ShotAcc,0,false)
		Launcher.Player.AllSetAttributeMultiplier(5,ShotAcc,1,false)
		Deking = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(7,Deking,0,false)
		Launcher.Player.AllSetAttributeMultiplier(7,Deking,1,false)
		Faceoffs = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(9,Faceoffs,0,false)
		Launcher.Player.AllSetAttributeMultiplier(9,Faceoffs,1,false)
		Endurance = math.random ()
		Launcher.Player.AllSetAttributeMultiplier(12,Endurance,0,false)
		Launcher.Player.AllSetAttributeMultiplier(12,Endurance,1,false)
		GoalieAttribute = math.random (1,99)
		Launcher.Player.Acceleration(18,GoalieAttribute)
		Launcher.Player.Acceleration(19,GoalieAttribute)
		Launcher.Player.Acceleration(38,GoalieAttribute)
		Launcher.Player.Acceleration(39,GoalieAttribute)
		GoalieAttribute = math.random (1,99)
		Launcher.Player.Aggression(18,GoalieAttribute)
		Launcher.Player.Aggression(19,GoalieAttribute)
		Launcher.Player.Aggression(38,GoalieAttribute)
		Launcher.Player.Aggression(39,GoalieAttribute)
		GoalieAttribute = math.random (1,99)
		Launcher.Player.Penalty(18,GoalieAttribute)
		Launcher.Player.Penalty(19,GoalieAttribute)
		Launcher.Player.Penalty(38,GoalieAttribute)
		Launcher.Player.Penalty(39,GoalieAttribute)
		GoalieAttribute = math.random (1,99)
		Launcher.Player.Toughness(18,GoalieAttribute)
		Launcher.Player.Toughness(19,GoalieAttribute)
		Launcher.Player.Toughness(38,GoalieAttribute)
		Launcher.Player.Toughness(39,GoalieAttribute)
	end
-- This sets how quickly the goaltender will cover the puck depending on whether or not a Power Play is active
	PPT = Launcher.Game.PowerplayTime()
	if QuickCover == 1 and PPT == 0 then
		Launcher.Game.SetGoalieCoverTime(50)
	elseif QuickCover == 2 and PPT == 0 then
		Launcher.Game.SetGoalieCoverTime(10)
	end
-- This sets how the goalie handles the puck based on a Power Play in progress or a team trailing late in the third period or an excessive amount of faceoffs
	CurrentTime = Launcher.Game.Time()
	if Launcher.Game.Period() == 1 then
		ElapsedTime = 1200 - CurrentTime
	elseif Launcher.Game.Period() == 2 then
		ElapsedTime = 2400 - CurrentTime
	else
		ElapsedTime = 3600 - CurrentTime
	end
	FaceoffRate = (TotalFaceoffs * 60) / ElapsedTime
	if PPT > 0 then
		if QuickCover ~= 0 then
			Launcher.Game.SetGoalieCoverTime(65)
		end
		if PenaltyTeam == 0 then
			Launcher.Player.Passing(38,255)
			Launcher.Player.Passing(39,255)
			Launcher.Player.Passing(18,0)
			Launcher.Player.Passing(19,0)
		else
			Launcher.Player.Passing(18,255)
			Launcher.Player.Passing(19,255)
			Launcher.Player.Passing(38,0)
			Launcher.Player.Passing(39,0)
		end
	elseif QuickCover ~= 0 and Launcher.Game.Period() >= 3 and Launcher.Game.Time() < 300 and Launcher.Stats.HomeGoals() ~= Launcher.Stats.AwayGoals() then
		Launcher.Game.SetGoalieCoverTime(65)
		if Launcher.Stats.HomeGoals() > Launcher.Stats.AwayGoals() then
			Launcher.Player.Passing(38,255)
			Launcher.Player.Passing(39,255)
			Launcher.Player.Passing(18,0)
			Launcher.Player.Passing(19,0)
		else
			Launcher.Player.Passing(18,255)
			Launcher.Player.Passing(19,255)
			Launcher.Player.Passing(38,0)
			Launcher.Player.Passing(39,0)
		end
	elseif QuickCover ~= 0 and GameFlow == true and PassesSinceReload > 7 then
		Launcher.Player.Passing(38,0)
		Launcher.Player.Passing(39,0)
		Launcher.Player.Passing(18,0)
		Launcher.Player.Passing(19,0)
	elseif GameFlow == true and FaceoffRate > FaceoffsPerMinute and Launcher.Game.Period() < 4 then
		Launcher.Game.SetGoalieCoverTime(75)
		GoaliePassing = players[18] [6]
		GoaliePassingTweak = math.random() + 0.5
		GoaliePassing = math.floor (GoaliePassing * GoaliePassingTweak)
		Launcher.Player.Passing(18,GoaliePassing)
		GoaliePassing = players[19] [6]
		GoaliePassingTweak = math.random() + 0.5
		GoaliePassing = math.floor (GoaliePassing * GoaliePassingTweak)
		Launcher.Player.Passing(19,GoaliePassing)
		GoaliePassing = players[38] [6]
		GoaliePassingTweak = math.random() + 0.5
		GoaliePassing = math.floor (GoaliePassing * GoaliePassingTweak)
		Launcher.Player.Passing(38,GoaliePassing)
		GoaliePassing = players[39] [6]
		GoaliePassingTweak = math.random() + 0.5
		GoaliePassing = math.floor (GoaliePassing * GoaliePassingTweak)
		Launcher.Player.Passing(39,GoaliePassing)
	elseif QuickCover ~= 0 then
		Launcher.Player.Passing(38,0)
		Launcher.Player.Passing(39,0)
		Launcher.Player.Passing(18,0)
		Launcher.Player.Passing(19,0)
	end
-- This halts play if the "RefErrors" option is enabled, simulating the referee blowing the whistle by mistake
	if RefErrors == true and OnlinePlay == false and Launcher.Game.PuckZone() ~= 0 and Launcher.Game.Period() ~= 0 and PPT == 0 then
		RandomError = math.random()
		if RandomError > 0.9975 then
			Launcher.Game.StopPlay()
		end
	end
-- This changes physics related to puck bounce, board friction and pass speed if the "DeterioratingIce" option is enabled
	if Launcher.Game.PuckZone() ~= 0 and DeterioratingIce == true then
		CurrentTime = Launcher.Game.Time()
		if CurrentTime < 1140 then
			PuckBounceFriction = Launcher.Mem.Float(0x79C768)
			RandomBounce = math.random ()
			if RandomBounce > 0.0175 or OnlinePlay == true then
				RandomBounce = 0.0175
			end
			if RealTime == true then
				RandomBounce = 0.0058
			end
			PuckBounceFriction = PuckBounceFriction * (1 + RandomBounce)
			if PuckBounceFriction > 0.575 then
				PuckBounceFriction = PuckBounceFriction * (1 - RandomBounce)
			end
			Launcher.Physics.SetPuckBounceFriction(PuckBounceFriction)
			if RealTime == true then
				Gravity = Launcher.Physics.PuckGravity()
				Gravity = Gravity + 0.002
			else
				Gravity = Launcher.Physics.PuckGravity()
				Gravity = Gravity + 0.025
			end
			Launcher.Physics.SetPuckGravity(Gravity)
			if OnlinePlay == false then
				EnergyMultiplier = Launcher.Mem.Float(0x709f90)
				RandomEnergy = (math.random (1, 9) / 100000)
				MoreLessEnergy = math.random()
				if MoreLessEnergy < 0.5 then
					EnergyMultiplier = EnergyMultiplier - RandomEnergy
				else
					EnergyMultiplier = EnergyMultiplier + RandomEnergy
				end
				if EnergyMultiplier < StartEnergyMultiplier or EnergyMultiplier > (StartEnergyMultiplier * 1.1) then
					Launcher.Physics.SetPlayerSpeedEnergyMultiplier(StartEnergyMultiplier)
				else
					Launcher.Physics.SetPlayerSpeedEnergyMultiplier(EnergyMultiplier)
				end
			end
			if CurrentTime < 900 then
				PuckBoardBounceFriction = Launcher.Mem.Float(0x79C76C)		
				RandomBoardBounce =	(math.random (75, 125) / 100)
				if OnlinePlay == false then
					PuckBoardBounceFriction = PuckBoardBounceFriction * RandomBoardBounce
				else
					PuckBoardBounceFriction = PuckBoardBounceFriction * 1.1
				end
				if PuckBoardBounceFriction < 0.1 or PuckBoardBounceFriction > 0.45 then
					Launcher.Physics.SetPuckBoardBounceFriction(StartPuckBoardBounceFriction)
				else
					Launcher.Physics.SetPuckBoardBounceFriction(PuckBoardBounceFriction)
				end
			end
			if StrangeBounceTweak == true and OnlinePlay == false then
				if CurrentTime > 900 then
					StrangeBounceLimit = 0.9
				elseif CurrentTime > 600 then
					StrangeBounceLimit = 0.75
				else
					StrangeBounceLimit = 0.6
				end
				StrangeBounceChance = math.random ()
				if StrangeBounceChance > StrangeBounceLimit then
					StrangeBounce = math.random ()
					if StrangeBounce > 0.5 then
						StrangeBounce = StrangeBounce - 0.5
					end
					Launcher.Physics.SetPuckBoardBounceFriction(StrangeBounce)
				end
			end
			if SlowingPassSpeed == true then
				if RealTime == true then
					PassSpeed = PassSpeed - 0.1
					Launcher.Physics.SetPassBaseSpeed(PassSpeed)
				else
					RandomPassSpeed = math.random ()
					if RandomPassSpeed > 0.5 then
						RandomPassSpeed = 0.1
					end
					PassSpeed = PassSpeed - RandomPassSpeed
					Launcher.Physics.SetPassBaseSpeed(PassSpeed)
				end
			end
		end
	end
-- This randomizes the saucer pass speed
	if OnlinePlay == false and SlowingPassSpeed == true then
		if Launcher.Game.Time() > 900 or Launcher.Game.Period() > 3 then
			SaucerPassSpeed = math.random () + 0.8
		elseif Launcher.Game.Time() > 600 then
			SaucerPassSpeed = math.random () + 0.6
		elseif Launcher.Game.Time() > 300 then
			SaucerPassSpeed = math.random () + 0.4
		else
			SaucerPassSpeed = math.random () + 0.2
		end
		if SaucerPassSpeed > 1 then
			SaucerPassSpeed = SaucerPassSpeed - 0.25
		end
		Launcher.Physics.SetSaucerPassSpeedMultiplier(SaucerPassSpeed)
	end
end
	
-- ========================================================================== END OF SCRIPT CODE SECTION ============================================================================

-- ========================================================================= START OF CALLBACK DEFINITIONS ==========================================================================

Launcher.Callback.Register("CutsceneStarted",CutsceneStartedCallback)
Launcher.Callback.Register("FaceoffStarted",FaceOffStartedCallback)
Launcher.Callback.Register("Pass",PassCallback)
Launcher.Callback.Register("PenaltyPending",PenaltyPendingCallback)
Launcher.Callback.Register("PeriodStarted",PeriodStartedCallback)
Launcher.Callback.Register("PlayStopped",PlayStoppedCallback)
Launcher.Callback.Register("ShotAway",ShotAwayCallback)
Launcher.Callback.Register("ShotHome",ShotHomeCallback)
Launcher.Callback.Register("Tick",TickCallback)
Launcher.Callback.Register("ZoneChanged",ZoneChangedCallback)

-- =========================================================================== END OF CALLBACK DEFINITIONS ==========================================================================
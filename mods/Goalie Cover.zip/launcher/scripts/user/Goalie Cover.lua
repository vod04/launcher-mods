Heat = 0
function HeatTimer()
    if not Launcher.Game.Paused() and not Launcher.Game.PlayStopped() then
        Heat = Heat + 2
    end
end
function ZoneChangedCallback()
    Heat = 0
    if Launcher.Game.PuckZone() ~= 0 then
        Timer = Launcher.Timer.SetInterval(1000,HeatTimer)
    else
        if Timer ~= nil then
            Launcher.Timer.Release(Timer)
        end
    end
end
function GoalieCoverCallback()
    Heat = math.min(Heat, 100)
    if Launcher.Game.PuckPossessionTime()/50 >= 60 then --3 seconds
        return true
    end
    if math.random(0,100-Heat) == 0 then
        return true
    else
        return false
    end
end
function ShotCallback()
    Heat = Heat + 2
end
function PlayStartedCallback()
    if Launcher.Game.PuckZone ~= 0 then
        Heat = Heat + 3
    end
end
function LoadAssets()
    Font = Launcher.Font.Load("Arial",20, 200)
    --Launcher.Callback.Register("Render",RenderCallback)
end
function DeviceCreatedCallback()
    LoadAssets()
end
function ReloadedCallback()
    LoadAssets()
end
function RenderCallback()
    Launcher.Font.DrawText(Font,Heat,10,Launcher.Screen.Height()-Launcher.Font.TextHeight(Font,Heat)-10,0xff000000)
end
Launcher.Callback.Register("GoalieCover",GoalieCoverCallback)
Launcher.Callback.Register("ZoneChanged",ZoneChangedCallback)
Launcher.Callback.Register("ShotHome",ShotCallback)
Launcher.Callback.Register("ShotAway",ShotCallback)
Launcher.Callback.Register("PlayStarted",PlayStartedCallback)
Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("Reloaded",ReloadedCallback)

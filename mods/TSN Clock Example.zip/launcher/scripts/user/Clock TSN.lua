-- Lines that start with "--" are comments. They are not executed 
-- Let's define some basic global variables to make it easier to adjust things

clockWidth = 1024
clockHeight = 128
FontSize = 50
FontWeight = 760
FontWeight2 = 730
FontSize2 = 60
FontSize3 = 25
FontFamily = "Tw Cen MT"
-- Colors are ARGB
FontColor1 = 0xeeffffff
FontColor2 = 0xee000000
FontColor3 = 0xeeecc10d
HomeGoalsX = 687
AwayGoalsX = 423
TimeX = 780

-- The following is the ideal screen resolution. Anything higher or lower will result in scaling of the surface
NativeResolutionX = 1920 
NativeResolutionY = 1080
NativeResolutionAspect = NativeResolutionY/NativeResolutionX
SurfaceSprite = 0
PauseSprite = 0


-- Jump down to see the callback definitions


-- ************ CALLBACK FUNCTIONS ************ 

-- The following callback function is called as soon as the D3D device is created, right before the game loading screen.
-- It is only called once, so this is where we load things like fonts, textures and sprites

Launcher.Override.DisableOverlay()
function LoadAssets()
    local Width, Height
    -- First, let's load the background image of our gameclock. The image dimensions should be pow2. 
    -- 2D images drawn to the screen are called "sprites". Sprites can be scaled, rotated, faded etc.
    -- After the sprite is loaded, the handle is stored in the BGSprite variable
	
	SurfaceSprite = Launcher.Sprite.Create(NativeResolutionX, NativeResolutionY,1)
	Launcher.Sprite.Scale(SurfaceSprite,Launcher.Screen.Width()/NativeResolutionX, (Launcher.Screen.Width()*NativeResolutionAspect)/NativeResolutionY)


	
    ClockSprite = Launcher.Sprite.Load("launcher/media/textures/TSN/Clock.png")	
    PauseSprite = Launcher.Sprite.Load("launcher/media/textures/TSN/Pause.png")	
    Width = Launcher.Sprite.Width(PauseSprite)
    Height = Launcher.Sprite.Height(PauseSprite)
    Launcher.Sprite.Scale(PauseSprite,(Launcher.Screen.Height()*(Width/Height))/Width,Launcher.Screen.Height()/Height)

    -- Next, let's load a font that we can use later to draw text
    -- The font handle will then be stored in the global variable, ClockFont
    ClockFont = Launcher.Font.Load(FontFamily,FontSize,FontWeight)
	ClockFontS = Launcher.Font.Load(FontFamily,FontSize2,FontWeight2)
	ClockFontPP = Launcher.Font.Load(FontFamily,FontSize3,FontWeight)
    
    -- Since the clock will never move, we tell the coordinate for top left with padding from top
    ClockX = 60
    ClockY = 50
	
    -- Let's retrieve the home and away team abbreviations for loading the pogs and store them in HomeAbbreviation and AwayAbbreviation global variables
    HomeAbbreviation = Launcher.Game.HomeNameAbbreviation()
    AwayAbbreviation = Launcher.Game.AwayNameAbbreviation()
    
    -- Now that we have the abbreviations, we can load the pog images as sprites and store the sprite handles in HomePog and AwayPog
    HomePog = Launcher.Sprite.Load("launcher/media/textures/TSN/pogs_C/"..HomeAbbreviation..".png")
    AwayPog = Launcher.Sprite.Load("launcher/media/textures/TSN/pogs_C/"..AwayAbbreviation..".png")

end


function DeviceCreatedCallback()
    
	LoadAssets()

end
function ReloadedCallback()
	LoadAssets()
end
-- The following callback function is called every frame for doing our own drawing
function RenderCallback()
    local X, Y
    if Launcher.Game.Paused() and not Launcher.Game.InReplay() then
        X = Launcher.Screen.Width()*0.5-Launcher.Sprite.Width(PauseSprite)*0.5
        Y = Launcher.Screen.Height()*0.5-Launcher.Sprite.Height(PauseSprite)*0.5
        Launcher.Sprite.Draw(PauseSprite,X,Y)
        return
    end
	if not Launcher.Clock.Shown() or Launcher.Game.IsShootout() then
		return
	end
	
	

	Launcher.Sprite.Draw(SurfaceSprite,0,0)
	
    
end

function TickCallback()
    local HomeGoals, AwayGoals, Period, Minutes, Seconds, PowerPlayTime, Time, PenaltyTeam, PenaltyPendingTeam, PowerPlayTeam

	if not Launcher.Clock.Shown() or Launcher.Game.IsShootout() then
		return
	end

    
	Launcher.Screen.SetRenderTarget(1,SurfaceSprite)

	
	if Launcher.Screen.BeginScene() then
		Launcher.Screen.Clear(0)
		-- First, let's make sure we're not in a cutscene or the pause menu

		-- We can draw the home and away pogs at the bottom
		Launcher.Sprite.Draw(HomePog, ClockX+479, ClockY)
		Launcher.Sprite.Draw(AwayPog, ClockX+215, ClockY)
		
		-- Clipping the sprite means you only draw a portion of the image
		-- This allows you to store multiple images in one image file, like a tileset
		-- Our base image is 64 pixels high. The fist 32 is our background, the next 32 is our foreground for the overlap effect on top of the pog      
		-- So in this case, we tell the game to draw the sprite from 0, 0 to 1024, 64 THE CLOCK
		Launcher.Sprite.Clip(ClockSprite,0,0,1024,64)
		Launcher.Sprite.Draw(ClockSprite, ClockX, ClockY)

		-- Now it's time to draw some basic game information
		-- First, let's store some of the information into local variables
		-- A local variable only exists in the current function. A global variable can be accessed from all functions
		-- By default, all variables are global. To make them local, simply add "local" before the declaration
		-- The next three lines retrieves the goals for each team and the current period
		HomeGoals = Launcher.Stats.HomeGoals()
		AwayGoals = Launcher.Stats.AwayGoals()
		Period = Launcher.Game.Period()
		

		
		-- Let's create a nice string representation of the period
		if Period == 1 then
			Period = "1st"
		elseif Period == 2 then
			Period = "2nd"
		elseif Period == 3 then
			Period = "3rd"
		elseif Period > 3 then
			Period = "OT"
		end
		

		
	-- Icing/Offside is pending
		if Launcher.Game.Warning() == 1 then
			Launcher.Sprite.Clip(ClockSprite,738,64,286,32)
			Launcher.Sprite.Draw(ClockSprite, ClockX + 738, ClockY + 64)
		elseif Launcher.Game.Warning() == 2 then
			Launcher.Sprite.Clip(ClockSprite,738,96,286,32)
			Launcher.Sprite.Draw(ClockSprite, ClockX + 738, ClockY + 64)
		end



	-- Penalty is pending
		if Launcher.Game.PenaltyPending() then
			PenaltyPendingTeam = Launcher.Game.PenaltyPendingTeam()
			if PenaltyPendingTeam == 0 then
				Launcher.Sprite.Clip(ClockSprite,475,64,265,32)
				Launcher.Sprite.Draw(ClockSprite, ClockX + 476, ClockY + 64)
			else
				Launcher.Sprite.Clip(ClockSprite,475,64,265,32)
				Launcher.Sprite.Draw(ClockSprite, ClockX + 212, ClockY + 64)
			end
		end

	-- POWERPLAY
		
		-- The next line retrieves the PP time in seconds
		local PowerPlayTime = Launcher.Game.PowerplayTime()
		if PowerPlayTime > 0 then
			PowerPlayTeam = Launcher.Game.PowerplayTeam()
			if PowerPlayTeam == 1 then
				Launcher.Sprite.Clip(ClockSprite,475,96,265,32)
				Launcher.Sprite.Draw(ClockSprite, ClockX + 476, ClockY + 64)
			else
				Launcher.Sprite.Clip(ClockSprite,475,96,265,32)
				Launcher.Sprite.Draw(ClockSprite, ClockX + 212, ClockY + 64)
			end





			
			-- Lets convert these seconds into minutes and seconds
			-- For minutes, simply divide by 60 and round down
			Minutes = math.floor(PowerPlayTime/60)
			if Minutes < 10 then
				-- let's pad a zero if it's 9 or less so it looks nicer
				local Minutes = "0"..Minutes
			end
			
			-- % is modulo. Modulo means the remainder of a division
			-- So in our case, the remainder of dividing the time by 60 would be the seconds component
			Seconds = PowerPlayTime % 60
			if Seconds < 10 then
				-- let's pad a zero if it's 9 or less so it looks nicer
				Seconds = "0"..Seconds
			end 
			if PowerPlayTeam == 0 then
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 411,ClockY + 65,FontColor1)
			else
				Launcher.Font.DrawText(ClockFontPP," "..Minutes..":"..Seconds,ClockX + 673,ClockY + 65,FontColor1)
			end
		end

	-- Now we can render all of the information to the screen using the DrawText function.

		-- The next line retrieves the game time in seconds
		Time = Launcher.Game.Time()
		
		-- Lets convert these seconds into minutes and seconds
		-- For minutes, simply divide by 60 and round down
		Minutes = math.floor(Time/60)
		if Minutes < 10 then
			-- let's pad a zero if it's 9 or less so it looks nicer
			Minutes = "0"..Minutes
		end
		
		-- % is modulo. Modulo means the remainder of a division
		-- So in our case, the remainder of dividing the time by 60 would be the seconds component
		Seconds = Time % 60
		if Seconds < 10 then
			-- let's pad a zero if it's 9 or less so it looks nicer
			Seconds = "0"..Seconds
		end

		Launcher.Font.DrawText(ClockFontS,HomeGoals,ClockX + HomeGoalsX,ClockY,FontColor1)
		Launcher.Font.DrawText(ClockFontS,AwayGoals,ClockX + AwayGoalsX,ClockY,FontColor1)
		Launcher.Font.DrawText(ClockFont,Period.."   "..Minutes..":"..Seconds,ClockX + TimeX,ClockY + 6,FontColor2)
        Launcher.Screen.EndScene()		
	end
	Launcher.Screen.ResetRenderTarget()	
	end



-- ************ CALLBACK DEFINITIONS ************ 

-- Callbacks are functions we define that will be called if an in-game event happens
-- There are many kinds of callbacks, but for our case we only need Render and DeviceCreated
-- Render is called every time a frame is rendered
-- DeviceCreated is called right after creating the D3D device, which is right before the in-game loading screen
-- The DeviceCreated callback function is where we load our assets
-- The Render callback function is where we draw everything

Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("RenderBackground",RenderCallback)
Launcher.Callback.Register("Tick",TickCallback)
Launcher.Callback.Register("Reloaded",ReloadedCallback)


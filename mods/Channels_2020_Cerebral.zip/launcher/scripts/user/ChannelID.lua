
-- The following is the ideal screen resolution. Anything higher or lower will result in scaling of the surface
NativeResolutionX = 1920 
NativeResolutionY = 1080
NativeResolutionAspect = NativeResolutionY/NativeResolutionX	

LogoX = 0

ChannelLogo=0

PauseOverlay=0



Current_Network=0

function LoadAssets()
    
	ChannelSprite = Launcher.Sprite.Create(NativeResolutionX, NativeResolutionY,1)
	Launcher.Sprite.Scale(ChannelSprite,Launcher.Screen.Width()/NativeResolutionX, (Launcher.Screen.Width()*NativeResolutionAspect)/NativeResolutionY)

    HomeAbbreviation = Launcher.Game.HomeNameAbbreviation()
    AwayAbbreviation = Launcher.Game.AwayNameAbbreviation()

    PauseSprite = Launcher.Sprite.Load("launcher/media/textures/Pause/Pause.png")
	PauseOverlay_Default = Launcher.Sprite.Load("launcher/media/textures/Pause/TSN_Pause.png")
    Width = Launcher.Sprite.Width(PauseSprite)
    Height = Launcher.Sprite.Height(PauseSprite)
    Launcher.Sprite.Scale(PauseSprite,(Launcher.Screen.Height()*(Width/Height))/Width,Launcher.Screen.Height()/Height)
	
	Override = Launcher.Config.Int("networkoverride",1)
	
	PauseOverlay=0
	HomePausePog=0
	AwayPausePog=0
	
	NetworkSetup()
	
	Network_Style = 0
end

function DeviceCreatedCallback()
	LoadAssets()
end


function ReloadedCallback()
	LoadAssets()
end

function NetworkSetup()
	if Launcher.Config.Int("networkoverride",1) == 1 then
		ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/CBC.png")
		LogoX = NativeResolutionX - 202
		Launcher.Sprite.Draw(ChannelLogo, LogoX, 60)
		PauseOverlay = Launcher.Sprite.Load("launcher/media/textures/Pause/SN_Pause.png")
		HomePausePog = Launcher.Sprite.Load("launcher/media/textures/Pause/SN_POG/"..HomeAbbreviation..".png")
		AwayPausePog = Launcher.Sprite.Load("launcher/media/textures/Pause/SN_POG/"..AwayAbbreviation..".png")
	elseif Launcher.Config.Int("networkoverride",1) == 2 then
		LogoX = 1700
		if HomeAbbreviation == "SSK" or AwayAbbreviation == "SSK" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/TSN3.png")
		elseif HomeAbbreviation == "WPG" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/TSN3.png")
		elseif HomeAbbreviation == "MTL" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/TSN2.png")
		elseif HomeAbbreviation == "TOR" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/TSN4.png")
		elseif HomeAbbreviation == "OTT" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/TSN5.png")
		elseif AwayAbbreviation == "WPG" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/TSN3.png")
		elseif AwayAbbreviation == "MTL" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/TSN2.png")
		elseif AwayAbbreviation == "TOR" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/TSN4.png")
		elseif AwayAbbreviation == "OTT" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/TSN5.png")
		else
			TSN_Channel=math.random(1,5)
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/TSN"..TSN_Channel..".png")
		end
		PauseOverlay = Launcher.Sprite.Load("launcher/media/textures/Pause/TSN_Pause.png")
		HomePausePog = Launcher.Sprite.Load("launcher/media/textures/Pause/TSN_POG/"..HomeAbbreviation..".png")
		AwayPausePog = Launcher.Sprite.Load("launcher/media/textures/Pause/TSN_POG/"..AwayAbbreviation..".png")
		Network_Style = 1
	elseif Launcher.Config.Int("networkoverride",1) == 3 then
		LogoX = 1700
		if HomeAbbreviation == "CGY" or HomeAbbreviation == "EDM" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/Sportsnet_West.png")
		elseif HomeAbbreviation == "VAN" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/Sportsnet_Pacific.png")
		elseif HomeAbbreviation == "TOR" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/Sportsnet_Ontario.png")
		elseif AwayAbbreviation == "CGY" or AwayAbbreviation == "EDM" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/Sportsnet_West.png")
		elseif AwayAbbreviation == "VAN" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/Sportsnet_Pacific.png")
		elseif AwayAbbreviation == "TOR" then
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/Sportsnet_Ontario.png")
		else
			ChannelLogo = Launcher.Sprite.Load("launcher/media/textures/CP_Channel/Sportsnet_One.png")
		end
		PauseOverlay = Launcher.Sprite.Load("launcher/media/textures/Pause/SN_Pause.png")
		HomePausePog = Launcher.Sprite.Load("launcher/media/textures/Pause/SN_POG/"..HomeAbbreviation..".png")
		AwayPausePog = Launcher.Sprite.Load("launcher/media/textures/Pause/SN_POG/"..AwayAbbreviation..".png")
	end
end

function RenderCallback()
    local X, Y
    if Launcher.Game.Paused() and not Launcher.Game.InReplay() then
        X = Launcher.Screen.Width()*0.5-Launcher.Sprite.Width(PauseSprite)*0.5
        Y = Launcher.Screen.Height()*0.5-Launcher.Sprite.Height(PauseSprite)*0.5
        Launcher.Sprite.Draw(PauseSprite,X,Y)
		if not (PauseOverlay == 0) then
			Launcher.Sprite.Draw(PauseOverlay,X,Y)
		else
			Launcher.Sprite.Draw(PauseOverlay_Default,X,Y)
		end
		
		if Network_Style == 1 then
			if not HomePausePog == nil then
				Launcher.Sprite.Clip(HomePausePog,0,0,188,156)
				Launcher.Sprite.Draw(HomePausePog,1605,86)
			end
			if not AwayPausePog == nil then
				Launcher.Sprite.Clip(AwayPausePog,0,0,188,156)
				Launcher.Sprite.Draw(AwayPausePog,1053,86)
			end
		else
			if not HomePausePog == nil then
				Launcher.Sprite.Clip(HomePausePog,0,0,195,156)
				Launcher.Sprite.Draw(HomePausePog,1598,80)
			end
			if not AwayPausePog == nil then
				Launcher.Sprite.Clip(AwayPausePog,0,0,195,156)
				Launcher.Sprite.Draw(AwayPausePog,1053,80)		
			end
		end
        return
    end
	if Launcher.Game.Paused() then
		return
	end
	
	Launcher.Sprite.Draw(ChannelSprite,0,0)
	
end

function TickCallback()
	Launcher.Screen.SetRenderTarget(1,ChannelSprite)
	
	Launcher.Sprite.Draw(ChannelLogo, LogoX, 60)	
		
	Launcher.Screen.ResetRenderTarget()	
end


Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("RenderBackground",RenderCallback)
Launcher.Callback.Register("Tick",TickCallback)
Launcher.Callback.Register("Reloaded",ReloadedCallback)

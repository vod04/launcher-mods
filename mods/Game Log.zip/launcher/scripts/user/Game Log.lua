PenaltyTextLookup = {}
-- drgullen change started: updated/added penalties
PenaltyTextLookup[0] = "Game Misconduct"
PenaltyTextLookup[20] = "Fighting"
PenaltyTextLookup[21] = "Charging"
PenaltyTextLookup[22] = "Slashing"
PenaltyTextLookup[23] = "Roughing"
PenaltyTextLookup[24] = "Cross-Checking"
PenaltyTextLookup[25] = "Hooking"
PenaltyTextLookup[26] = "Tripping"
PenaltyTextLookup[27] = "Interference"
PenaltyTextLookup[28] = "High Sticking"
PenaltyTextLookup[29] = "Elbowing"
PenaltyTextLookup[30] = "Checking From Behind"
PenaltyTextLookup[31] = "Boarding"
PenaltyTextLookup[32] = "Holding"
PenaltyTextLookup[34] = "Hooking"
PenaltyTextLookup[35] = "Holding"
PenaltyTextLookup[36] = "Tripping"
PenaltyTextLookup[37] = "Roughing"
PenaltyTextLookup[38] = "Fighting"
PenaltyTextLookup[39] = "Fighting Instigator"
PenaltyTextLookup[40] = "Abusing the Official"
PenaltyTextLookup[41] = "Attempting to Injure"
PenaltyTextLookup[42] = "Delay of Game"
PenaltyTextLookup[43] = "Holding the Stick"
PenaltyTextLookup[44] = "Diving"
PenaltyTextLookup[45] = "Spearing"
-- drgullen change ended
LogFilename = "Game log"
LogNumber = nil
function LogAction(String)
    if File == nil then
        if LogNumber == nil then
            File = io.open(LogFilename .. ".txt", "w")
        else
            File = io.open(LogFilename .. " " .. LogNumber .. ".txt", "w")
        end
    end
    local Time =Launcher.Game.Time()
    local Minutes = math.floor(Time/60)
    if Minutes < 10 then
        Minutes = "0"..Minutes
    end
    local Seconds = Time % 60
    if Seconds < 10 then
        Seconds = "0"..Seconds
    end

    File:write(Minutes .. ":" .. Seconds.." - " .. String, "\n")
    File:flush()
end
function DeviceCreatedCallback()
    if Launcher.Config.Boolean("newgamelog",false) then
        LogNumber = 1
        while Launcher.Filesystem.FileExists(LogFilename .. " ".. LogNumber .. ".txt") do
            LogNumber = LogNumber + 1
        end
    end
    
    
    PeriodOver = false
    LogAction("Game started between " .. Launcher.Game.HomeFullName() .. " and " .. Launcher.Game.AwayFullName() .. " at the " .. Launcher.Game.ArenaName() .. " in "..Launcher.Game.ArenaLocation())
end
function PlayStoppedCallback(Reason)
    local Player, PlayerName, Team, String, AwayGoals, HomeGoals, PlayerName2
    if Reason == LauncherPlayStoppedPeriod then
        LogAction("Period Over")  
    elseif Reason == LauncherPlayStoppedPuckOver then
        LogAction("Play stopped: Puck out of bounds")  
    elseif Reason == LauncherPlayStoppedIcing then
        LogAction("Play stopped: Icing")  
    elseif Reason == LauncherPlayStoppedOffside then
        LogAction("Play stopped: Offside")  
    elseif Reason == LauncherPlayStoppedGoalHome then
        Player = Launcher.Game.LastGoalPlayer()
        Team = Launcher.Game.HomeNameAbbreviation()
        PlayerName = Launcher.Player.FirstName(Player).." "..Launcher.Player.LastName(Player)
        LogAction(PlayerName .. " scored a goal ("..Team..")")  
    elseif Reason == LauncherPlayStoppedGoalAway then
        Player = Launcher.Game.LastGoalPlayer()
        Team = Launcher.Game.AwayNameAbbreviation()
        PlayerName = Launcher.Player.FirstName(Player).." "..Launcher.Player.LastName(Player)
        LogAction(PlayerName .. " scored a goal ("..Team..")")
    elseif Reason == LauncherPlayStoppedGoalie then
        Player = Launcher.Game.PlayerWithPuck()
        PlayerName = Launcher.Player.FirstName(Player).." "..Launcher.Player.LastName(Player)
        if Launcher.Game.TeamWithPuck() == 0 then
            Team = Launcher.Game.HomeNameAbbreviation()
        else
            Team = Launcher.Game.AwayNameAbbreviation()
        end
        LogAction(PlayerName.."(G) stopped the play ("..Team..")")  
    elseif Reason == LauncherPlayStoppedNetLoose then
        LogAction("Play stopped: Net loose")  
    elseif Reason == LauncherPlayStoppedGameOver then
        HomeGoals = Launcher.Stats.HomeGoals()
        AwayGoals = Launcher.Stats.AwayGoals()
        if HomeGoals > AwayGoals then
            String = Launcher.Game.HomeNameAbbreviation() .. " won: " .. HomeGoals .. "-"..AwayGoals
        elseif AwayGoals > HomeGoals then
            String = Launcher.Game.AwayNameAbbreviation() .. " won: " .. AwayGoals .. "-"..HomeGoals
        else
            String = "Tie: "..HomeGoals.."-"..AwayGoals
        end
        LogAction("Game over. " .. String)  
    elseif Reason == LauncherPlayStoppedFight then
        Player = Launcher.Game.HomeFighter()
        PlayerName = Launcher.Player.FirstName(Player).." "..Launcher.Player.LastName(Player)
        Player = Launcher.Game.AwayFighter()
        PlayerName2 = Launcher.Player.FirstName(Player).." "..Launcher.Player.LastName(Player)
        LogAction("Fight between "..PlayerName.." and "..PlayerName2)  
    elseif Reason == LauncherPlayStoppedTwoLinePass then
        LogAction("Play stopped: Two line pass")  
    end
end
function PlayStartedCallback()
    local PlayerWithPuck = Launcher.Game.PlayerWithPuck(), FirstName, LastName, Team
    if PlayerWithPuck ~= nil then

        if Launcher.Game.TeamWithPuck() == 0 then
            Team = Launcher.Game.HomeNameAbbreviation()
        else
            Team = Launcher.Game.AwayNameAbbreviation()
        end
        FirstName = Launcher.Player.FirstName(PlayerWithPuck) 
        LastName = Launcher.Player.LastName(PlayerWithPuck)
        if FirstName ~= nil and LastName ~= nil then
            LogAction("Faceoff won by " .. FirstName.." " .. LastName .. " (" .. Team .. ")")
        end
    end
end
function PenaltyCallback(Index)
    local Player = Launcher.Game.PenaltyPlayer(Index)
    local Team = Launcher.Game.PenaltyTeam(Index)
    local PenaltyID = Launcher.Game.PenaltyID(Index)
    local Time = Launcher.Game.PenaltyTime(Index)
    local PlayerName = Launcher.Player.FirstName(Player).." "..Launcher.Player.LastName(Player)
-- drgullen chaange started
    local TimeFormatted = Launcher.Util.FormatTime(Time)
-- drgullen chaange ended
	local TeamName
    if Team == 0 then
        TeamName = Launcher.Game.HomeNameAbbreviation()
    else
        TeamName = Launcher.Game.AwayNameAbbreviation()
    end
    if PenaltyTextLookup[PenaltyID] == nil then
        PenaltyString = "unknown ("..PenaltyID..")"
    else
        PenaltyString = PenaltyTextLookup[PenaltyID]
    end
-- drgullen chaange started
	if Time > 480 then
		TimeFormatted = "(Game Misconduct)"
	elseif Time == 480 then
		TimeFormatted = "5:00"
	end
    LogAction("Penalty: "..PlayerName.." for "..PenaltyString.." "..TimeFormatted.." ("..TeamName..")")
-- drgullen chaange ended
end
function PenaltyPendingCallback(Player, Team, PenaltyID, Time)
	local PlayerName, TeamName, PenaltyString
    PlayerName = Launcher.Player.FirstName(Player).." "..Launcher.Player.LastName(Player)
    if Team == 0 then
        TeamName = Launcher.Game.HomeNameAbbreviation()
    else
        TeamName = Launcher.Game.AwayNameAbbreviation()
    end
    if PenaltyTextLookup[PenaltyID] == nil then
        PenaltyString = "unknown ("..PenaltyID..")"
    else
        PenaltyString = PenaltyTextLookup[PenaltyID]
    end
-- drgullen chaange started
    LogAction("Penalty pending: "..PlayerName.." for "..PenaltyString.." ("..TeamName..")")   
-- drgullen chaange ended  
end
function PeriodStartedCallback()
	local Period
    Period = Launcher.Game.Period()
    if Period > 3 then
        LogAction("OT started")    
    else
        LogAction("Period " .. Period .. " started")    
    end
end
function DeviceReleasedCallback()
    if File ~= nil then
        File:close()
    end
    File = nil
end
Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("DeviceReleased",DeviceReleasedCallback)
Launcher.Callback.Register("PlayStarted",PlayStartedCallback)
Launcher.Callback.Register("PlayStopped",PlayStoppedCallback)
Launcher.Callback.Register("Penalty",PenaltyCallback)
Launcher.Callback.Register("PenaltyPending",PenaltyPendingCallback)
Launcher.Callback.Register("PeriodStarted",PeriodStartedCallback)
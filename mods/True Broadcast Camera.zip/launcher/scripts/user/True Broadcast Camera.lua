--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]



CameraMinZoom = 0.12
CameraMaxZoom = 0.40
CameraTiltSpeed = 0.02
CameraRotationSpeed = 0.02
CameraZoomSpeed = 0.01


CameraZoom = CameraMaxZoom
CameraZoomTarget =  CameraZoom
CameraX = -3100
CameraY = 1300
CameraZ = 0
FPSTarget = 60
CameraAngle = 0
CameraAngleTarget = 0
CameraTiltTarget=0.453
CameraTilt=0.453
CameraMaxTargetRotation = math.rad(55)+1.5708
CameraMinTargetRotation = math.rad(-55)+1.5708
function InitCamera()
	Launcher.Camera.SetPosition(CameraX,CameraY,CameraZ)
	Launcher.Camera.SetZoom(CameraZoom)
	Launcher.Camera.SetRotation(math.deg(90))
	Launcher.Camera.SetTilt(CameraTilt)
	ZoomTarget = MinZoom


	Launcher.Override.DisableCamera()
	Launcher.Callback.Register("Tick",TickCallback)	
	Launcher.Callback.Register("CutsceneStarted",CutsceneStartedCallback)
	Launcher.Callback.Register("CutsceneStopped",CutsceneStoppedCallback)
	Launcher.Callback.Register("FaceoffStarted",FaceoffStartedCallback)
end
function FreeCamera()
	Launcher.Override.EnableCamera()
	Launcher.Callback.Remove("Tick")
	Launcher.Callback.Remove("CutsceneStarted")
	Launcher.Callback.Remove("CutsceneStopped")
	Launcher.Callback.Remove("FaceoffStarted")
end
function CameraCreatedCallback()
	
	
	if Launcher.Camera.Type() == 5 then
		InitCamera()
	end
end
function OperateCamera(Instant)
	local TargetX, TargetY, TargetZ, XDistance, YDistance, ZDistance, Distance
	TargetX, TargetY, TargetZ = Launcher.Camera.Target()

	CameraAngleTarget = math.atan2(TargetX-CameraX,CameraZ-TargetZ)
	if CameraAngleTarget > CameraMaxTargetRotation then
		CameraAngleTarget = CameraMaxTargetRotation
	elseif CameraAngleTarget < CameraMinTargetRotation then
		CameraAngleTarget = CameraMinTargetRotation
	end
	
	if CameraAngleTarget > CameraAngle then
		CameraAngle = CameraAngle + CameraRotationSpeed * Launcher.Renderstate.FPSMultiplier(FPSTarget)
		if CameraAngle > CameraAngleTarget then
			CameraAngle = CameraAngleTarget
		end
	elseif CameraAngleTarget < CameraAngle then
		CameraAngle = CameraAngle - CameraRotationSpeed * Launcher.Renderstate.FPSMultiplier(FPSTarget)
		if CameraAngle < CameraAngleTarget then
			CameraAngle = CameraAngleTarget
		end
	end

	

	CameraZoomTarget = CameraTilt*0.8

	if CameraZoomTarget > CameraZoom then
		CameraZoom = CameraZoom + CameraZoomSpeed * Launcher.Renderstate.FPSMultiplier(FPSTarget)
		if CameraZoom > CameraZoomTarget then
			CameraZoom = CameraZoomTarget
		end
	elseif CameraZoomTarget < CameraAngle then
		CameraZoom = CameraZoom - CameraZoomSpeed * Launcher.Renderstate.FPSMultiplier(FPSTarget)
		if CameraZoom < CameraZoomTarget then
			CameraZoom = CameraZoomTarget
		end
	end



	XDistance = math.abs(TargetX-CameraX)
	YDistance = math.abs(CameraY-TargetY)
	ZDistance = math.abs(CameraZ-TargetZ)
	
	Distance = math.sqrt(XDistance * YDistance + ZDistance * ZDistance)
	CameraTiltTarget = math.atan2(YDistance, Distance)
	if CameraTiltTarget > CameraTilt then
		CameraTilt = CameraTilt + CameraTiltSpeed * Launcher.Renderstate.FPSMultiplier(FPSTarget)
		if CameraTilt > CameraTiltTarget then
			CameraTilt = CameraTiltTarget
		end
	elseif CameraTiltTarget < CameraTilt then
		CameraTilt = CameraTilt - CameraTiltSpeed * Launcher.Renderstate.FPSMultiplier(FPSTarget)
		if CameraTilt < CameraTiltTarget then
			CameraTilt = CameraTiltTarget
		end
	end
	if Instant == true then
		CameraTilt = CameraTiltTarget
		CameraAngle = CameraAngleTarget
		CameraZoom = CameraZoomTarget
	end
	Launcher.Camera.SetTilt(CameraTilt)
	Launcher.Camera.SetRotation(CameraAngle)
	Launcher.Camera.SetZoom(CameraZoom)
	
end
function TickCallback()

	OperateCamera(false)

end
function CutsceneStartedCallback()
	Launcher.Override.EnableCamera()
	
end
function CutsceneStoppedCallback()
	Launcher.Override.DisableCamera()
	Launcher.Camera.SetPosition(CameraX,CameraY,CameraZ)
	OperateCamera(true)
end
function CameraTypeChangedCallback()
	if Launcher.Camera.Type() == 5 then
		InitCamera()
		OperateCamera(true)
	else
		FreeCamera()
	end
end
function DeviceReleasedCallback()
	FreeCamera()
end
function FaceoffStartedCallback()
	OperateCamera(true)
end
Launcher.Callback.Register("CameraCreated",CameraCreatedCallback)
Launcher.Callback.Register("CameraTypeChanged",CameraTypeChangedCallback)
Launcher.Callback.Register("DeviceReleased",DeviceReleasedCallback)

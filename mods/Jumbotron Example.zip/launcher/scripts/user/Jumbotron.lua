--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]



Teams = {}
Teams[27] = {}
Teams[27].Frames = 720
Teams[27].AnimationFPS = 23.976
Teams[27].FshID = "VIDA"

BASS_DX8_I3DL2REVERB_lRoom = 0
BASS_DX8_I3DL2REVERB_lRoomHF = -100
BASS_DX8_I3DL2REVERB_flRoomRolloffFactor = 0
BASS_DX8_I3DL2REVERB_flDecayTime = 2.49
BASS_DX8_I3DL2REVERB_flDecayHFRatio = 0.83
BASS_DX8_I3DL2REVERB_lReflections = -2602
BASS_DX8_I3DL2REVERB_flReflectionsDelay = 0.007
BASS_DX8_I3DL2REVERB_lReverb = 250
BASS_DX8_I3DL2REVERB_flReverbDelay = 0.011
BASS_DX8_I3DL2REVERB_flDiffusion = 100
BASS_DX8_I3DL2REVERB_flDensity = 100
BASS_DX8_I3DL2REVERB_flHFReference = 5000



function DeviceCreatedCallback()
    local Path
	Team = Launcher.Game.HomeTeamID()
    HomeAbbreviation = Launcher.Game.HomeNameAbbreviation()
    Path = "launcher/media/textures/jumbotron/"..HomeAbbreviation.."/"
    if Launcher.Filesystem.DirectoryExists(Path) then
        Video = Launcher.VideoTexture.Load(Path,"jpg",Teams[Team].Frames,Teams[Team].AnimationFPS,Teams[Team].FshID )
        Launcher.Callback.Register("Tick",TickCallback)
    end
end
function TickCallback()
	if not Launcher.Game.InReplay() and Video ~= nil then 
        Launcher.VideoTexture.Stop(Video)
	else 
        if Launcher.Input.KeyPressed(VK_I) then
            Launcher.VideoTexture.Play(Video)
		end
        Launcher.VideoTexture.Tick(Video)
	end
end
function DeviceReleasedCallback()
	Launcher.Callback.Remove("Tick")
    Launcher.VideoTexture.ReleaseAll()
end
Launcher.Callback.Register("DeviceCreated",DeviceCreatedCallback)
Launcher.Callback.Register("DeviceReleased",DeviceReleasedCallback)

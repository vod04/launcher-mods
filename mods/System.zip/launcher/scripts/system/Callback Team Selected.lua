--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]



RetAddressHome = Launcher.Mem.Alloc(4)
RetAddressAway = Launcher.Mem.Alloc(4)
CallAddress = Launcher.Mem.Alloc(4)
Launcher.Mem.WriteLong(CallAddress,0x6AF520)
ASM = [[
    call dword []]..CallAddress..[[] 
    *HomeTeamChanged
    jmp dword []]..RetAddressHome..[[] 
]]
if Launcher.Callback.Create("HomeTeamChanged") then
    Launcher.Mem.WriteLong(RetAddressHome, 0x6a9f40)
    ASMPointer = Launcher.Mem.AssembleString(ASM)
    if ASMPointer ~= nil then
        Launcher.Mem.WriteJump(0x6a9f3b,ASMPointer)
    end
end

ASM = [[
    call dword []]..CallAddress..[[] 
    *AwayTeamChanged
    jmp dword []]..RetAddressAway..[[] 
]]
if Launcher.Callback.Create("AwayTeamChanged") then
    Launcher.Mem.WriteLong(RetAddressAway, 0x6a9f75)
    ASMPointer = Launcher.Mem.AssembleString(ASM)
    if ASMPointer ~= nil then
        Launcher.Mem.WriteJump(0x6a9f70,ASMPointer)
    end
end
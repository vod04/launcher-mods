--[[
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
--]]
TeamPointer = Launcher.Mem.Alloc(4)
LinePointer = Launcher.Mem.Alloc(4)
function LineChange()
	Launcher.Callback.Trigger("LineChanged",nil, nil,Launcher.Mem.Long(TeamPointer), Launcher.Mem.Long(LinePointer))
end
ASM = [[


	mov ecx, [esp+0x4] 
	mov []] .. tostring(TeamPointer) .. [[],ecx

	mov ecx, [esp+0x8] 
	mov []] .. tostring(LinePointer) .. [[],ecx
	

	**LineChange

	mov eax,[esp+0x0c] 
	push ebx
	
	mov ecx, 0x4a6b45
	jmp ecx
]]
if Launcher.Callback.Create("LineChanged") ~= nil then
	ASMPointer = Launcher.Mem.AssembleString(ASM)
    if ASMPointer ~= nil then
        Launcher.Mem.WriteJump(0x4A6B40,ASMPointer,0)
    end
end


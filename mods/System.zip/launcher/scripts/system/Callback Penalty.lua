IndexBuffer = Launcher.Mem.Alloc(4)
function Penalty()
    local Index = Launcher.Mem.Long(IndexBuffer)
    Launcher.Callback.Trigger("Penalty",nil,nil,Index)
end
ASM = [[ 
    **Penalty
    inc byte [0x79B9BD]
    ret 
]]
ASM2 = [[ 
    movzx eax, dl
    mov []]..IndexBuffer..[[],eax
    mov dl, byte [ecx+0x2]
    ret
]]
if Launcher.Callback.Create("Penalty") ~= nil then
    ASMPointer = Launcher.Mem.AssembleString(ASM)
    Launcher.Mem.WriteCall(0x4AB878,ASMPointer,1)
    
    ASMPointer2 = Launcher.Mem.AssembleString(ASM2)
    Launcher.Mem.WriteCall(0x4AB84f,ASMPointer2,1)
    
end